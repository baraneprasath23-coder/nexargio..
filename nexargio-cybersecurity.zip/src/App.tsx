import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AudienceCards } from './components/AudienceCards';
import { AnalystChecker } from './components/AnalystChecker';
import { TrustCrisis } from './components/TrustCrisis';
import { LegacyFailure } from './components/LegacyFailure';
import { PlatformStack } from './components/PlatformStack';
import { GatedRiskLadder } from './components/GatedRiskLadder';
import { ProvenInTheWild } from './components/ProvenInTheWild';
import { EnterpriseOutcomes } from './components/EnterpriseOutcomes';
import { DeveloperApiMcp } from './components/DeveloperApiMcp';
import { CompanySections } from './components/CompanySections';
import { Footer } from './components/Footer';
import { 
  BriefingModal, 
  BrandUnderAttackModal, 
  ApiKeyModal, 
  ReportPhishingModal,
  ClientPortalModal,
  BenchmarkPreviewModal
} from './components/Modals';
import { CookieBanner } from './components/CookieBanner';

// Sub Pages
import { PlatformPage } from './components/Pages/PlatformPage';
import { SolutionsPage } from './components/Pages/SolutionsPage';
import { ResearchPage } from './components/Pages/ResearchPage';
import { CompanyLeadershipPage } from './components/Pages/CompanyLeadershipPage';
import { LegalPage } from './components/Pages/LegalPage';

import { PageView, SolutionSector, CaseStudy } from './types';

export default function App() {
  const [currentView, setCurrentView] = useState<PageView>('home');
  const [selectedSector, setSelectedSector] = useState<SolutionSector>('banking');
  const [selectedCase, setSelectedCase] = useState<CaseStudy | null>(null);

  // Modal states
  const [briefingModalOpen, setBriefingModalOpen] = useState(false);
  const [briefingInterest, setBriefingInterest] = useState<string>('Enterprise & SOCs');
  const [brandAttackModalOpen, setBrandAttackModalOpen] = useState(false);
  const [apiKeyModalOpen, setApiKeyModalOpen] = useState(false);
  const [reportPhishingModalOpen, setReportPhishingModalOpen] = useState(false);
  const [clientPortalOpen, setClientPortalOpen] = useState(false);
  const [benchmarkModalOpen, setBenchmarkModalOpen] = useState(false);

  // Smooth scroll handler for anchor links
  const navigateTo = (view: PageView, sectionId?: string) => {
    setCurrentView(view);
    if (sectionId) {
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const openBriefingWithInterest = (interest?: string) => {
    if (interest) setBriefingInterest(interest);
    setBriefingModalOpen(true);
  };

  const handleSelectSector = (sector: SolutionSector) => {
    setSelectedSector(sector);
    setCurrentView('solutions');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCase = (caseItem: CaseStudy) => {
    setSelectedCase(caseItem);
    setCurrentView('research');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#060911] text-[#9CA3AF] flex flex-col font-sans selection:bg-[#3B82F6] selection:text-white">
      {/* Global Corporate Bitdefender-Style Header */}
      <Header
        currentView={currentView}
        onNavigate={navigateTo}
        onOpenBriefingModal={() => openBriefingWithInterest('Enterprise & SOCs')}
        onOpenBrandUnderAttackModal={() => setBrandAttackModalOpen(true)}
        onOpenApiKeyModal={() => setApiKeyModalOpen(true)}
        onOpenClientPortal={() => setClientPortalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* HOMEPAGE VIEW */}
        {currentView === 'home' && (
          <>
            {/* 6.1 Hero with Canvas Identity Graph */}
            <Hero
              onOpenBriefingModal={() => openBriefingWithInterest('Executive Briefing')}
              onOpenApiKeyModal={() => setApiKeyModalOpen(true)}
              onExplorePlatform={() => navigateTo('platform')}
              onLaunchChecker={() => {
                const el = document.getElementById('analyst-checker');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* 6.2 Audience Cards (Bitdefender 4 persona cards) */}
            <AudienceCards onSelectSolution={handleSelectSector} />

            {/* Live Interactive Alpha Mountain Bicolor Threat Scanner */}
            <AnalystChecker
              onOpenApiKeyModal={() => setApiKeyModalOpen(true)}
              onOpenBriefingModal={() => openBriefingWithInterest('Analyst Checker Evaluation')}
            />

            {/* 6.3 The Digital Trust Crisis */}
            <TrustCrisis />

            {/* 6.4 Why Legacy Security Fails */}
            <LegacyFailure
              onOpenChecker={() => {
                const el = document.getElementById('analyst-checker');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              onOpenBriefingModal={() => openBriefingWithInterest('Gap Analysis Request')}
            />

            {/* 6.5 The Unified Platform Stack & 6.6 Three Horizons Roadmap */}
            <PlatformStack
              onOpenBriefingModal={() => openBriefingWithInterest('Platform Early Access')}
              onExplorePiad={() => navigateTo('platform')}
            />

            {/* 6.7 How It Works — Gated Risk Ladder */}
            <GatedRiskLadder onInspectSpecs={() => navigateTo('platform')} />

            {/* 6.8 Proven in the Wild (Empirical Case Studies) */}
            <ProvenInTheWild
              onSelectCase={handleSelectCase}
              onViewAllResearch={() => navigateTo('research')}
            />

            {/* 6.9 Enterprise Outcomes & 6.10 Highlights Row */}
            <EnterpriseOutcomes
              onRequestReport={() => setBenchmarkModalOpen(true)}
              onOpenApiKeyModal={() => setApiKeyModalOpen(true)}
              onOpenBriefingModal={() => openBriefingWithInterest('Brand Dossier Request')}
            />

            {/* 6.11 Developers & AI Agents — Start Free */}
            <DeveloperApiMcp
              onOpenApiKeyModal={() => setApiKeyModalOpen(true)}
              onOpenBriefingModal={() => openBriefingWithInterest('High Volume & On-Prem Deployment')}
            />

            {/* 6.12 Credentials Strip, 6.13 Sectors, 6.14 Mission & 6.15 Four Action Tiles */}
            <CompanySections
              onSelectSolution={handleSelectSector}
              onOpenBriefingModal={openBriefingWithInterest}
              onOpenApiKeyModal={() => setApiKeyModalOpen(true)}
              onViewCompany={() => navigateTo('company')}
              onViewLeadership={() => navigateTo('leadership')}
            />
          </>
        )}

        {/* CHECKER DEDICATED VIEW */}
        {currentView === 'checker' && (
          <div className="pt-8">
            <AnalystChecker
              onOpenApiKeyModal={() => setApiKeyModalOpen(true)}
              onOpenBriefingModal={() => openBriefingWithInterest('SOC URL Checker Demo')}
            />
          </div>
        )}

        {/* PLATFORM DEEP DIVE VIEW */}
        {currentView === 'platform' && (
          <PlatformPage
            onOpenBriefingModal={() => openBriefingWithInterest('PIAD Technical Specs')}
            onOpenApiKeyModal={() => setApiKeyModalOpen(true)}
            onOpenChecker={() => navigateTo('home', 'analyst-checker')}
          />
        )}

        {/* SOLUTIONS VIEW */}
        {currentView === 'solutions' && (
          <SolutionsPage
            initialSector={selectedSector}
            onOpenBriefingModal={openBriefingWithInterest}
            onSelectCase={handleSelectCase}
          />
        )}

        {/* RESEARCH & CASE DOSSIERS VIEW */}
        {currentView === 'research' && (
          <ResearchPage
            selectedCaseStudy={selectedCase}
            onOpenBriefingModal={() => openBriefingWithInterest('Research & Benchmark Access')}
          />
        )}

        {/* COMPANY & LEADERSHIP VIEW */}
        {(currentView === 'company' || currentView === 'leadership') && (
          <CompanyLeadershipPage
            onOpenBriefingModal={() => openBriefingWithInterest('Company Introduction')}
          />
        )}

        {/* LEGAL & COMPLIANCE PAGES */}
        {(currentView === 'privacy' ||
          currentView === 'terms' ||
          currentView === 'cookies' ||
          currentView === 'responsible-disclosure' ||
          currentView === 'privacy-request' ||
          currentView === 'trademarks' ||
          currentView === 'dpa') && (
          <LegalPage
            initialTab={
              currentView === 'terms'
                ? 'terms'
                : currentView === 'responsible-disclosure'
                ? 'disclosure'
                : currentView === 'trademarks'
                ? 'trademarks'
                : currentView === 'privacy-request'
                ? 'request'
                : 'privacy'
            }
          />
        )}
      </main>

      {/* Global Comprehensive Footer */}
      <Footer
        onNavigate={navigateTo}
        onOpenReportPhishing={() => setReportPhishingModalOpen(true)}
        onOpenCookiesModal={() => navigateTo('cookies')}
      />

      {/* Conversion & Corporate Modals */}
      <BriefingModal
        isOpen={briefingModalOpen}
        onClose={() => setBriefingModalOpen(false)}
        defaultInterest={briefingInterest}
      />

      <BrandUnderAttackModal
        isOpen={brandAttackModalOpen}
        onClose={() => setBrandAttackModalOpen(false)}
      />

      <ApiKeyModal
        isOpen={apiKeyModalOpen}
        onClose={() => setApiKeyModalOpen(false)}
      />

      <ReportPhishingModal
        isOpen={reportPhishingModalOpen}
        onClose={() => setReportPhishingModalOpen(false)}
      />

      <ClientPortalModal
        isOpen={clientPortalOpen}
        onClose={() => setClientPortalOpen(false)}
        onOpenApiKeyModal={() => {
          setClientPortalOpen(false);
          setApiKeyModalOpen(true);
        }}
      />

      <BenchmarkPreviewModal
        isOpen={benchmarkModalOpen}
        onClose={() => setBenchmarkModalOpen(false)}
        onOpenBriefingModal={() => {
          setBenchmarkModalOpen(false);
          openBriefingWithInterest('Benchmark Report Download');
        }}
      />

      {/* Compliant Cookie Consent Banner */}
      <CookieBanner onOpenPrivacyPolicy={() => navigateTo('privacy')} />
    </div>
  );
}
