export type PageView = 
  | 'home'
  | 'platform'
  | 'solutions'
  | 'research'
  | 'company'
  | 'leadership'
  | 'checker'
  | 'privacy'
  | 'terms'
  | 'cookies'
  | 'responsible-disclosure'
  | 'privacy-request'
  | 'trademarks'
  | 'dpa';

export type SolutionSector = 
  | 'banking'
  | 'government'
  | 'crypto-web3'
  | 'enterprise-soc'
  | 'mssp';

export interface ThreatAnalysisResult {
  url: string;
  riskScore: number; // 0 to 100
  verdict: 'Permit' | 'Step-up / Isolate' | 'Remote Browser Isolation' | 'Hard Block';
  riskGrade: 'A+' | 'B' | 'D' | 'F';
  confidence: number;
  threatType: string;
  fastPathLatency: string;
  domAnalysisLatency: string;
  sandboxLatency: string;
  sha256Evidence: string;
  reasons: string[];
  lexicalSignals: {
    domainAge: string;
    entropyScore: number;
    certIssuer: string;
    ctLogStatus: string;
  };
  domSignals: {
    credentialTraps: number;
    hiddenIframes: boolean;
    turnstileBypassAttempt: boolean;
  };
  visualSignals: {
    brandImpersonated: string | null;
    visualSimilarity: number;
    logoHashMatch: boolean;
  };
}

export interface CaseStudy {
  id: string;
  title: string;
  targetSector: string;
  defangedUrl: string;
  riskScore: number;
  timeToFlag: string;
  publicScannersStatus: string;
  summary: string;
  evidenceNotes: string;
  status: 'Reported & Confirmed Takedown' | 'Contained in Isolation' | 'Active Threat Vector';
  indicators: {
    registrar: string;
    ip: string;
    certDate: string;
    attackVector: string;
  };
}
