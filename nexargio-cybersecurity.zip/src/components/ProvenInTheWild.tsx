import React from 'react';
import { ShieldAlert, ArrowRight, ExternalLink, FileText, CheckCircle2 } from 'lucide-react';
import { CASE_STUDIES } from '../data/content';
import { CaseStudy } from '../types';

interface ProvenInTheWildProps {
  onSelectCase: (caseItem: CaseStudy) => void;
  onViewAllResearch: () => void;
}

export const ProvenInTheWild: React.FC<ProvenInTheWildProps> = ({
  onSelectCase,
  onViewAllResearch,
}) => {
  return (
    <section id="proven-in-the-wild" className="py-20 bg-[#0B0F19]/50 border-y border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EF4444]/10 border border-[#EF4444]/20 text-[#EF4444] text-xs font-mono-data mb-4">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>EMPIRICAL FORENSIC DOSSIERS</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight mb-4">
              Real threats. Caught early. Reported with evidence.
            </h2>
            <p className="text-base sm:text-lg text-[#9CA3AF]">
              Investigate verified campaigns intercepted prior to victim distribution. Every detection record contains a cryptographically verified SHA-256 evidence trail.
            </p>
          </div>

          <button
            onClick={onViewAllResearch}
            className="text-xs sm:text-sm font-semibold text-[#3B82F6] hover:text-[#60A5FA] inline-flex items-center gap-2 transition-colors shrink-0"
          >
            <span>View All Research Dossiers</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Case Dossier Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {CASE_STUDIES.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectCase(item)}
              className="glass-panel glass-panel-hover rounded-2xl overflow-hidden cursor-pointer flex flex-col justify-between group border border-white/10"
            >
              {/* Card Header & Simulated Redacted Evidence View */}
              <div className="p-6">
                {/* Meta Header */}
                <div className="flex items-center justify-between gap-2 mb-4">
                  <span className="text-[11px] font-mono-data text-[#06B6D4] uppercase">
                    {item.targetSector}
                  </span>
                  <span className="px-2.5 py-0.5 rounded text-xs font-mono-data font-bold bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30">
                    RISK {item.riskScore}/100
                  </span>
                </div>

                {/* Defanged URL */}
                <div className="bg-[#060911] p-3 rounded-xl border border-white/5 font-mono-data text-xs text-[#F9FAFB] mb-4 flex items-center justify-between">
                  <span className="text-[#EF4444] font-semibold">{item.defangedUrl}</span>
                  <span className="text-[#6B7280] text-[10px]">{item.timeToFlag}</span>
                </div>

                {/* Title & Short Story */}
                <h3 className="text-base font-bold text-white mb-2 leading-snug group-hover:text-[#3B82F6] transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-[#9CA3AF] leading-relaxed mb-4">
                  {item.summary}
                </p>

                {/* Technical Evidence Forensics */}
                <div className="p-3 bg-[#111827]/70 rounded-lg border border-white/5 text-[11px] font-mono-data text-[#6B7280] space-y-1 mb-2">
                  <div className="flex justify-between">
                    <span>IP / ASN:</span>
                    <span className="text-[#9CA3AF]">{item.indicators.ip}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>VECTOR:</span>
                    <span className="text-[#9CA3AF] truncate max-w-[170px]">{item.indicators.attackVector}</span>
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="p-4 bg-[#111827]/50 border-t border-white/5 flex items-center justify-between text-xs">
                <span className="text-[#10B981] flex items-center gap-1 font-mono-data text-[11px]">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {item.status}
                </span>
                <span className="text-[#3B82F6] font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  <span>Read case</span>
                  <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Mandatory Footnote (Section 6.8 & 10.5) */}
        <div className="p-4 rounded-xl bg-[#060911] border border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-[#6B7280]">
          <p>
            <strong className="text-[#9CA3AF]">Notice:</strong> Nexargio detects and evidences fake domains; registrars and hosting providers carry out takedowns. Third-party brand names appear strictly as text in factual technical incident write-ups.
          </p>
          <span className="font-mono-data text-[11px] text-[#06B6D4] shrink-0">
            DISCLOSURE POLICY: TLP:CLEAR
          </span>
        </div>

      </div>
    </section>
  );
};
