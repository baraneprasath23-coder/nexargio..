import React, { useState, useEffect } from 'react';
import { ShieldCheck, Cookie, Settings, Check, X } from 'lucide-react';

interface CookieBannerProps {
  onOpenPrivacyPolicy: () => void;
}

export const CookieBanner: React.FC<CookieBannerProps> = ({ onOpenPrivacyPolicy }) => {
  const [consentGiven, setConsentGiven] = useState(true); // default true to avoid flash, check in useEffect
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState({
    essential: true, // always required
    analytics: false,
    securityTelemetry: true
  });

  useEffect(() => {
    const stored = localStorage.getItem('nexargio_cookie_consent');
    if (!stored) {
      setConsentGiven(false);
    }
  }, []);

  const handleAcceptAll = () => {
    const consentRecord = {
      essential: true,
      analytics: true,
      securityTelemetry: true,
      timestamp: new Date().toISOString(),
      decision: 'ACCEPT_ALL'
    };
    localStorage.setItem('nexargio_cookie_consent', JSON.stringify(consentRecord));
    setConsentGiven(true);
    setShowPreferences(false);
  };

  const handleRejectAll = () => {
    const consentRecord = {
      essential: true,
      analytics: false,
      securityTelemetry: true,
      timestamp: new Date().toISOString(),
      decision: 'REJECT_ALL'
    };
    localStorage.setItem('nexargio_cookie_consent', JSON.stringify(consentRecord));
    setConsentGiven(true);
    setShowPreferences(false);
  };

  const handleSavePreferences = () => {
    const consentRecord = {
      ...preferences,
      timestamp: new Date().toISOString(),
      decision: 'CUSTOM_PREFERENCES'
    };
    localStorage.setItem('nexargio_cookie_consent', JSON.stringify(consentRecord));
    setConsentGiven(true);
    setShowPreferences(false);
  };

  if (consentGiven && !showPreferences) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:max-w-lg z-50 animate-fade-in">
      <div className="glass-panel rounded-2xl p-5 border border-white/15 bg-[#0B0F19]/95 backdrop-blur-2xl shadow-2xl text-left">
        {!showPreferences ? (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Cookie className="w-4 h-4 text-[#3B82F6]" />
              <span className="text-xs font-mono-data text-white font-semibold">COOKIE & PRIVACY PREFERENCES</span>
            </div>
            <p className="text-xs text-[#9CA3AF] leading-relaxed mb-4">
              Nexargio respects your privacy and complies with India’s DPDP Act 2023, UK GDPR, and PECR. We use strictly necessary security tokens and ask your permission for anonymous performance analytics. No advertising cookies are ever set.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-2 pt-1 font-mono-data text-xs">
              <button
                onClick={handleAcceptAll}
                className="w-full sm:w-auto px-4 py-2 bg-[#3B82F6] hover:bg-[#2563EB] text-white font-semibold rounded-lg transition-colors flex-1"
              >
                Accept All
              </button>
              <button
                onClick={handleRejectAll}
                className="w-full sm:w-auto px-4 py-2 bg-[#111827] hover:bg-[#1F2937] text-white border border-white/10 font-semibold rounded-lg transition-colors flex-1"
              >
                Reject Non-Essential
              </button>
              <button
                onClick={() => setShowPreferences(true)}
                className="w-full sm:w-auto px-3 py-2 text-[#9CA3AF] hover:text-white transition-colors text-[11px]"
              >
                Manage
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-2">
              <span className="text-xs font-mono-data text-white font-semibold flex items-center gap-1.5">
                <Settings className="w-4 h-4 text-[#06B6D4]" />
                CUSTOMIZE COOKIE PERMISSIONS
              </span>
              <button
                onClick={() => setShowPreferences(false)}
                className="text-[#9CA3AF] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 mb-4 text-xs">
              <div className="flex items-start justify-between gap-3 p-2 bg-[#060911] rounded-lg">
                <div>
                  <div className="font-bold text-white">Strictly Necessary Cookies</div>
                  <div className="text-[11px] text-[#6B7280]">Session security, CSRF protection, API key authentication. Always active.</div>
                </div>
                <span className="text-[10px] font-mono-data px-2 py-0.5 rounded bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
                  REQUIRED
                </span>
              </div>

              <div className="flex items-start justify-between gap-3 p-2 bg-[#060911] rounded-lg">
                <div>
                  <div className="font-bold text-white">Anonymous Threat Telemetry</div>
                  <div className="text-[11px] text-[#6B7280]">Aggregate attack velocity stats and scanner performance counters.</div>
                </div>
                <input
                  type="checkbox"
                  checked={preferences.securityTelemetry}
                  onChange={(e) => setPreferences({ ...preferences, securityTelemetry: e.target.checked })}
                  className="mt-1"
                />
              </div>

              <div className="flex items-start justify-between gap-3 p-2 bg-[#060911] rounded-lg">
                <div>
                  <div className="font-bold text-white">Performance Analytics</div>
                  <div className="text-[11px] text-[#6B7280]">Privacy-friendly visitor metrics with IP anonymization enabled.</div>
                </div>
                <input
                  type="checkbox"
                  checked={preferences.analytics}
                  onChange={(e) => setPreferences({ ...preferences, analytics: e.target.checked })}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="flex items-center justify-between gap-2">
              <button
                onClick={onOpenPrivacyPolicy}
                className="text-[11px] text-[#3B82F6] hover:underline"
              >
                Read Cookie Policy
              </button>
              <button
                onClick={handleSavePreferences}
                className="px-4 py-2 bg-[#3B82F6] text-white text-xs font-semibold rounded-lg font-mono-data"
              >
                Save Preferences
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
