import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Cpu, 
  Network, 
  Bot, 
  ChevronRight, 
  Layers, 
  ArrowRight,
  Eye,
  Sliders,
  Share2,
  BrainCircuit,
  Lock
} from 'lucide-react';

interface PlatformStackProps {
  onOpenBriefingModal: () => void;
  onExplorePiad: () => void;
}

export const PlatformStack: React.FC<PlatformStackProps> = ({
  onOpenBriefingModal,
  onExplorePiad,
}) => {
  const [activeCard, setActiveCard] = useState<string>('piad');

  const platforms = [
    {
      id: 'piad',
      title: 'PIAD v4.0',
      subtitle: 'Pre-Issuance Attack Detection',
      status: 'LIVE',
      statusColor: 'bg-[#10B981]/15 text-[#10B981] border-[#10B981]/30',
      icon: ShieldCheck,
      description: 'Detects left-of-live phishing and impersonation: certificate-transparency monitoring, headless browser rendering, visual brand matching, SSL provenance, Gemini vision and local-LLM adjudication.',
      capabilities: [
        'Real-time streaming Certificate Transparency (CT) ingestion',
        'Headless Chromium rendering with Turnstile / CAPTCHA bypass emulation',
        'Visual brand similarity neural hashing against 1,200+ enterprise brands',
        'Gemini multimodal vision adjudication with zero-shot explainability'
      ],
      deployment: 'Cloud, On-Premises, or Air-Gapped'
    },
    {
      id: 'vigilance-x',
      title: 'Vigilance-X',
      subtitle: 'Autonomous AI Agent Governance',
      status: 'Roadmap',
      statusColor: 'bg-white/5 text-[#9CA3AF] border-white/10',
      icon: Cpu,
      description: 'Governs autonomous AI agents at runtime with eBPF kernel enforcement, cryptographically signed tool calls, and an immutable attestation ledger.',
      capabilities: [
        'Kernel-level eBPF probes monitoring autonomous tool executions',
        'Tamper-evident cryptographic tool attestation ledger',
        'Model Context Protocol (MCP) policy enforcement firewall',
        'Sub-millisecond runtime memory anomaly containment'
      ],
      deployment: 'Kubernetes DaemonSet & Linux Kernel 5.15+'
    },
    {
      id: 'vass-onyx',
      title: 'VASS-Onyx',
      subtitle: 'Identity Graph & SIEM Command Center',
      status: 'Roadmap',
      statusColor: 'bg-white/5 text-[#9CA3AF] border-white/10',
      icon: Network,
      description: 'Unified identity graph and SIEM/SOAR command centre that correlates human, machine, and autonomous agent identities to isolate incidents across micro-segments.',
      capabilities: [
        'Dynamic identity relationship graph covering OAuth, keys, and tokens',
        'Automated API and registrar takedown dossier generation',
        'Micro-segmentation quarantine triggers across edge firewalls',
        'Bi-directional Splunk, Sentinel, and CrowdStrike SOC pipelines'
      ],
      deployment: 'Enterprise Hybrid Multi-Cloud'
    },
    {
      id: 'nexa-ai',
      title: 'Nexa AI',
      subtitle: 'Air-Gapped Security Copilot',
      status: 'Roadmap',
      statusColor: 'bg-[#8B5CF6]/15 text-[#8B5CF6] border-[#8B5CF6]/30',
      icon: Bot,
      description: 'Air-gapped security copilot that transforms raw network packets, CT telemetry, and reverse-proxy payloads into plain-English analyst rationale and forensic reports.',
      capabilities: [
        'Local quantized LLM weights running strictly on sovereign hardware',
        'CERT-In and legal affidavit formatted evidence drafting',
        'Plain-English reverse engineering of obfuscated JavaScript payloads',
        'Zero telemetry exfiltration guarantee for classified enclaves'
      ],
      deployment: 'Sovereign On-Prem GPU Enclave'
    }
  ];

  return (
    <section id="platform-stack" className="py-20 bg-[#0B0F19]/40 border-b border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/10 border border-[#3B82F6]/20 text-[#3B82F6] text-xs font-mono-data mb-4">
            <Layers className="w-3.5 h-3.5" />
            <span>UNIFIED ARCHITECTURAL STACK</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight mb-4">
            One platform for identity intelligence, runtime enforcement, SOC command and AI-guided response.
          </h2>
          <p className="text-base sm:text-lg text-[#9CA3AF]">
            Engineered modularly to address the collapse of the static perimeter: start with live left-of-live detection (PIAD v4.0) and scale into full-stack sovereign identity defense.
          </p>
        </div>

        {/* 4 Interactive Modular Product Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {platforms.map((p) => {
            const Icon = p.icon;
            const isSelected = activeCard === p.id;
            return (
              <div
                key={p.id}
                onClick={() => setActiveCard(p.id)}
                className={`glass-panel rounded-2xl p-6 cursor-pointer transition-all duration-300 flex flex-col justify-between relative ${
                  isSelected
                    ? 'border-[#3B82F6] shadow-[0_0_30px_rgba(59,130,246,0.2)] bg-[#111827]'
                    : 'border-white/10 hover:border-white/20'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-[#060911] border border-white/10 flex items-center justify-center text-[#3B82F6]">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className={`text-[10px] font-mono-data px-2 py-0.5 rounded border uppercase tracking-wider ${p.statusColor}`}>
                      {p.status}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-1">{p.title}</h3>
                  <div className="text-xs font-mono-data text-[#06B6D4] mb-3">{p.subtitle}</div>
                  <p className="text-xs text-[#9CA3AF] leading-relaxed mb-6">
                    {p.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs font-semibold text-[#3B82F6]">
                  <span>{isSelected ? 'Viewing Architecture' : 'Click to inspect'}</span>
                  <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'rotate-90' : ''}`} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Active Platform Capability Deep Dive Drawer */}
        {activeCard && (
          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-[#3B82F6]/30 mb-16 bg-[#060911]/90">
            {platforms
              .filter((p) => p.id === activeCard)
              .map((p) => (
                <div key={p.id} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                  <div className="lg:col-span-7">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-mono-data text-[#06B6D4]">INSPECTION MODE</span>
                      <span className="text-white/20">·</span>
                      <span className="text-xs font-mono-data text-[#9CA3AF]">{p.deployment}</span>
                    </div>
                    <h4 className="text-2xl font-bold text-white mb-4">{p.title} Technical Architecture</h4>
                    <p className="text-sm text-[#9CA3AF] mb-6 leading-relaxed">
                      {p.description}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                      {p.capabilities.map((cap, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-[#F9FAFB] bg-[#111827] p-3 rounded-lg border border-white/5">
                          <span className="text-[#3B82F6] font-mono-data font-bold">0{i + 1}.</span>
                          <span>{cap}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      {p.id === 'piad' ? (
                        <button
                          onClick={onExplorePiad}
                          className="px-5 py-2.5 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shadow"
                        >
                          <span>Explore PIAD v4.0 Full Specs</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <button
                          onClick={onOpenBriefingModal}
                          className="px-5 py-2.5 bg-[#111827] hover:bg-[#1F2937] text-white text-xs font-semibold rounded-lg border border-white/10 transition-colors flex items-center gap-2"
                        >
                          <Lock className="w-3.5 h-3.5 text-[#06B6D4]" />
                          <span>Request Roadmap Early Access</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Right Diagram Graphic */}
                  <div className="lg:col-span-5 bg-[#0B0F19] p-6 rounded-xl border border-white/5 font-mono-data text-xs space-y-3">
                    <div className="text-[#6B7280] text-[10px] uppercase">ENFORCEMENT PIPELINE HOOKS</div>
                    <div className="p-3 bg-[#111827] rounded border-l-2 border-[#3B82F6] text-[#F9FAFB]">
                      <code>hook.pre_issuance_ct_ingest()</code>
                      <div className="text-[11px] text-[#6B7280] mt-1">Intercept certificate broadcast from Let's Encrypt, ZeroSSL, DigiCert</div>
                    </div>
                    <div className="p-3 bg-[#111827] rounded border-l-2 border-[#06B6D4] text-[#F9FAFB]">
                      <code>eval.headless_brand_hash(url)</code>
                      <div className="text-[11px] text-[#6B7280] mt-1">Render DOM, bypass anti-crawlers, compute visual cosine distance</div>
                    </div>
                    <div className="p-3 bg-[#111827] rounded border-l-2 border-[#10B981] text-[#F9FAFB]">
                      <code>verdict.push_siem_blocklist()</code>
                      <div className="text-[11px] text-[#6B7280] mt-1">Push cryptographically attested block rule to egress proxies in &lt;1.5s</div>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        )}

        {/* Continuous Loop Architecture: Discover -> Govern -> Correlate -> Reason -> Enforce */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 mb-16">
          <div className="text-center max-w-xl mx-auto mb-8">
            <span className="text-xs font-mono-data text-[#06B6D4] uppercase">CONTINUOUS TRUST LOOP</span>
            <h3 className="text-xl font-bold text-white mt-1">Autonomous Enforcement Lifecycle</h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
            <div className="p-4 bg-[#111827] rounded-xl border border-white/5 flex flex-col items-center">
              <Eye className="w-6 h-6 text-[#3B82F6] mb-2" />
              <div className="text-sm font-bold text-white mb-1">01. Discover</div>
              <div className="text-[11px] text-[#6B7280]">CT logs, DNS queries, and ephemeral agent calls</div>
            </div>
            <div className="p-4 bg-[#111827] rounded-xl border border-white/5 flex flex-col items-center">
              <Sliders className="w-6 h-6 text-[#06B6D4] mb-2" />
              <div className="text-sm font-bold text-white mb-1">02. Govern</div>
              <div className="text-[11px] text-[#6B7280]">Runtime policies, token scopes, and provenance</div>
            </div>
            <div className="p-4 bg-[#111827] rounded-xl border border-white/5 flex flex-col items-center">
              <Share2 className="w-6 h-6 text-[#3B82F6] mb-2" />
              <div className="text-sm font-bold text-white mb-1">03. Correlate</div>
              <div className="text-[11px] text-[#6B7280]">Graph identity relations & cross-tenant lures</div>
            </div>
            <div className="p-4 bg-[#111827] rounded-xl border border-white/5 flex flex-col items-center">
              <BrainCircuit className="w-6 h-6 text-[#8B5CF6] mb-2" />
              <div className="text-sm font-bold text-white mb-1">04. Reason</div>
              <div className="text-[11px] text-[#6B7280]">Multimodal LLM & vision similarity analysis</div>
            </div>
            <div className="p-4 bg-[#111827] rounded-xl border border-white/5 flex flex-col items-center col-span-2 md:col-span-1">
              <ShieldCheck className="w-6 h-6 text-[#10B981] mb-2" />
              <div className="text-sm font-bold text-white mb-1">05. Enforce</div>
              <div className="text-[11px] text-[#6B7280]">Millisecond isolation, SIEM sync & takedowns</div>
            </div>
          </div>
        </div>

        {/* 6.6 Three Horizons Roadmap (Three columns on a line, no dates) */}
        <div>
          <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-6">
            STRATEGIC EVOLUTION // THREE HORIZONS ROADMAP
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="glass-panel p-6 rounded-2xl border border-[#10B981]/30 bg-[#0B0F19]">
              <div className="inline-block px-2.5 py-0.5 rounded text-[10px] font-mono-data bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 uppercase mb-3">
                Horizon 1 — Now
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Flagship Defense (PIAD)</h4>
              <p className="text-xs text-[#9CA3AF] leading-relaxed">
                Zero-day left-of-live phishing and Adversary-in-the-Middle credential interception at certificate generation. Live in production with REST API & MCP.
              </p>
            </div>

            <div className="glass-panel p-6 rounded-2xl border border-[#3B82F6]/30 bg-[#0B0F19]">
              <div className="inline-block px-2.5 py-0.5 rounded text-[10px] font-mono-data bg-[#3B82F6]/15 text-[#3B82F6] border border-[#3B82F6]/30 uppercase mb-3">
                Horizon 2 — Next
              </div>
              <h4 className="text-lg font-bold text-white mb-2">AI Agent Governance (Vigilance-X)</h4>
              <p className="text-xs text-[#9CA3AF] leading-relaxed">
                Kernel-level eBPF monitoring, tool-call attestation ledgers, and runtime policy enforcement for autonomous LLM agents in enterprise environments.
              </p>
            </div>

            <div className="glass-panel p-6 rounded-2xl border border-white/10 bg-[#0B0F19]">
              <div className="inline-block px-2.5 py-0.5 rounded text-[10px] font-mono-data bg-white/5 text-[#9CA3AF] border border-white/10 uppercase mb-3">
                Horizon 3 — Later
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Global Sovereign Platform</h4>
              <p className="text-xs text-[#9CA3AF] leading-relaxed">
                Distributed national digital immune system for critical infrastructure, defense agencies, and financial rails with complete air-gapped sovereign control.
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
