import React from 'react';
import { FileBarChart, ArrowRight, Bot, Shield, FileSpreadsheet } from 'lucide-react';
import { BENCHMARK_STATS, COMPANY_DETAILS } from '../data/content';

interface EnterpriseOutcomesProps {
  onRequestReport: () => void;
  onOpenApiKeyModal: () => void;
  onOpenBriefingModal: () => void;
}

export const EnterpriseOutcomes: React.FC<EnterpriseOutcomesProps> = ({
  onRequestReport,
  onOpenApiKeyModal,
  onOpenBriefingModal,
}) => {
  return (
    <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* 6.9 Enterprise Outcomes */}
      <div className="mb-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/10 border border-[#3B82F6]/20 text-[#3B82F6] text-xs font-mono-data mb-4">
              <FileBarChart className="w-3.5 h-3.5" />
              <span>EMPIRICAL BENCHMARKS // SOURCE-VERIFIED</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight mb-4">
              Validated performance.
            </h2>
            <p className="text-base sm:text-lg text-[#9CA3AF]">
              Every metric below is backed by reproducible test sets, transparent methodologies, and continuous telemetry auditing.
            </p>
          </div>

          <button
            onClick={onRequestReport}
            className="px-5 py-2.5 bg-[#111827] hover:bg-[#1F2937] text-white border border-white/10 hover:border-white/20 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shrink-0"
          >
            <span>Request Technical Benchmark Report</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Large Stats Cards with Source Lines (Rule 3 & 4) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {BENCHMARK_STATS.map((stat, idx) => (
            <div
              key={idx}
              className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col justify-between"
            >
              <div>
                <div className="text-4xl sm:text-5xl font-extrabold font-outfit text-white mb-2 tracking-tight">
                  {stat.value}
                </div>
                <div className="text-sm font-semibold text-[#F9FAFB] mb-4">
                  {stat.label}
                </div>
              </div>

              {/* Source Line as explicitly requested by Rule 3 */}
              <div className="pt-4 border-t border-white/5 text-[11px] font-mono-data text-[#6B7280] leading-snug">
                <span className="text-[#3B82F6] block mb-0.5">DATASET SOURCE:</span>
                {stat.dataset}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6.10 Highlights Row (Bitdefender Banner Cards) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Highlight 1: MCP Server */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-6 border border-[#8B5CF6]/20 flex flex-col justify-between group">
          <div>
            <div className="w-10 h-10 rounded-xl bg-[#8B5CF6]/10 border border-[#8B5CF6]/30 flex items-center justify-center text-[#8B5CF6] mb-4">
              <Bot className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#8B5CF6] transition-colors">
              PIAD for AI Agents
            </h3>
            <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed mb-6">
              Scan URLs, domains and QR codes directly from Claude Desktop or Cursor with the official <code className="text-[#06B6D4] font-mono-data">nexargio-mcp</code> package.
            </p>
          </div>

          <button
            onClick={onOpenApiKeyModal}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8B5CF6] hover:text-white transition-colors"
          >
            <span>Get MCP Access & API Key</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Highlight 2: Patent Pending */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-6 border border-[#3B82F6]/20 flex flex-col justify-between group">
          <div>
            <div className="w-10 h-10 rounded-xl bg-[#3B82F6]/10 border border-[#3B82F6]/30 flex items-center justify-center text-[#3B82F6] mb-4">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#3B82F6] transition-colors">
              Patent Pending IP
            </h3>
            <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed mb-6">
              Application {COMPANY_DETAILS.patentAppNumber}: multi-layered recursive normalization and adversarial behavioural analysis for evasive web threats.
            </p>
          </div>

          <button
            onClick={onRequestReport}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#3B82F6] hover:text-white transition-colors"
          >
            <span>Read the Whitepaper</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Highlight 3: Brand Dossiers */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-6 border border-[#06B6D4]/20 flex flex-col justify-between group">
          <div>
            <div className="w-10 h-10 rounded-xl bg-[#06B6D4]/10 border border-[#06B6D4]/30 flex items-center justify-center text-[#06B6D4] mb-4">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#06B6D4] transition-colors">
              Brand Impersonation Dossiers
            </h3>
            <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed mb-6">
              Per-brand continuous monitoring reports of live lookalike domains, ASN hosting infrastructure, and evidence hashes ready for registrar takedowns.
            </p>
          </div>

          <button
            onClick={onOpenBriefingModal}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#06B6D4] hover:text-white transition-colors"
          >
            <span>Request a Sample Dossier</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

      </div>
    </section>
  );
};
