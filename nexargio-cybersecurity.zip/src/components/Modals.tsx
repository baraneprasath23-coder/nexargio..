import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  Key, 
  Send, 
  CheckCircle2, 
  AlertTriangle, 
  Copy, 
  Lock, 
  Clock, 
  ShieldCheck, 
  FileText,
  Activity,
  Download,
  Server,
  Terminal,
  Zap,
  Globe,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { COMPANY_DETAILS, BENCHMARK_STATS } from '../data/content';

// 1. EXECUTIVE BRIEFING MODAL
interface BriefingModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultInterest?: string;
}

export const BriefingModal: React.FC<BriefingModalProps> = ({ 
  isOpen, 
  onClose, 
  defaultInterest = 'Enterprise & SOCs' 
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    role: '',
    country: 'India',
    interest: defaultInterest,
    message: '',
    agreedPrivacy: false
  });
  const [submitted, setSubmitted] = useState(false);
  const [emailWarning, setEmailWarning] = useState('');

  if (!isOpen) return null;

  const handleEmailChange = (val: string) => {
    setFormData({ ...formData, email: val });
    if (val.includes('@gmail.com') || val.includes('@yahoo.com') || val.includes('@hotmail.com')) {
      setEmailWarning('Please use your corporate work email for priority scheduling with lead architects.');
    } else {
      setEmailWarning('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.company || !formData.agreedPrivacy) return;
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg glass-panel rounded-2xl p-6 sm:p-8 border border-white/15 bg-[#0B0F19] text-left">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X className="w-5 h-5" />
        </button>

        {!submitted ? (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#3B82F6]" />
              <span className="text-xs font-mono-data text-[#3B82F6]">TAG: [BRIEFING]</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Schedule Executive Briefing</h3>
            <p className="text-xs text-[#9CA3AF] mb-6">
              Connect with our architecture team for a 30-minute demonstration of PIAD left-of-live interception against your company’s attack surface.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs font-mono-data">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[#9CA3AF] block mb-1">YOUR FULL NAME *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Ramesh Sharma"
                    className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[#9CA3AF] block mb-1">WORK EMAIL *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => handleEmailChange(e.target.value)}
                    placeholder="name@company.com"
                    className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                  />
                </div>
              </div>

              {emailWarning && (
                <div className="p-2 rounded bg-[#F59E0B]/10 border border-[#F59E0B]/20 text-[#F59E0B] text-[11px]">
                  {emailWarning}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[#9CA3AF] block mb-1">ORGANIZATION / COMPANY *</label>
                  <input
                    type="text"
                    required
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    placeholder="e.g. ICICI Bank / HCL"
                    className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[#9CA3AF] block mb-1">PRIMARY INTEREST</label>
                  <select
                    value={formData.interest}
                    onChange={(e) => setFormData({ ...formData, interest: e.target.value })}
                    className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                  >
                    <option value="Enterprise & SOCs">Enterprise SOC (AiTM defense)</option>
                    <option value="MSSP & MDR Providers">MSSP / MDR Partner Pilot</option>
                    <option value="Government & Critical Infrastructure">Government / Sovereign Air-Gapped</option>
                    <option value="Crypto & Web3">Crypto / Web3 Brand Protection</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">SPECIFIC WORKLOAD OR THREAT CONCERN</label>
                <textarea
                  rows={3}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell us about your URL volume, active phishing campaigns, or air-gapped requirements..."
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                />
              </div>

              <div className="flex items-start gap-2 pt-2">
                <input
                  type="checkbox"
                  id="privacy-consent"
                  required
                  checked={formData.agreedPrivacy}
                  onChange={(e) => setFormData({ ...formData, agreedPrivacy: e.target.checked })}
                  className="mt-1"
                />
                <label htmlFor="privacy-consent" className="text-[11px] text-[#9CA3AF] leading-snug">
                  I consent to Nexargio Private Limited processing my information in accordance with the Privacy Policy. No marketing spam.
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#3B82F6] hover:bg-[#2563EB] text-white font-semibold rounded-xl transition-all shadow-[0_0_20px_rgba(59,130,246,0.3)] mt-2"
              >
                Confirm Executive Briefing Request
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="w-12 h-12 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center mx-auto mb-4 border border-[#10B981]/30">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-lg font-bold text-white mb-2">Briefing Request Received</h4>
            <p className="text-xs text-[#9CA3AF] max-w-sm mx-auto mb-6">
              Thank you, {formData.name}. Our technical architecture team has received your inquiry for <strong>{formData.company}</strong> and will reach out to <strong>{formData.email}</strong> within 1 business day.
            </p>
            <button
              onClick={() => {
                setSubmitted(false);
                onClose();
              }}
              className="px-6 py-2.5 bg-[#111827] text-white text-xs font-semibold rounded-lg border border-white/10 hover:bg-[#1F2937]"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// 2. BRAND UNDER ATTACK URGENT MODAL
interface BrandUnderAttackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BrandUnderAttackModal: React.FC<BrandUnderAttackModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    brand: '',
    suspectedDomains: '',
    contactName: '',
    email: '',
    phone: '',
    urgentNotes: ''
  });
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg glass-panel rounded-2xl p-6 sm:p-8 border border-[#EF4444]/40 bg-[#0B0F19] text-left">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X className="w-5 h-5" />
        </button>

        {!submitted ? (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <ShieldAlert className="w-4 h-4 text-[#EF4444] animate-pulse" />
              <span className="text-xs font-mono-data text-[#EF4444] font-bold">PRIORITY TRIAGE // [URGENT]</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Brand Under Active Attack</h3>
            <p className="text-xs text-[#9CA3AF] mb-6">
              Suspecting live spoofing domains, lookalikes, or executive impersonation? Submit immediately. Our team prioritizes live forensic verification within 1 business day and supplies a court-admissible evidence pack.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs font-mono-data">
              <div>
                <label className="text-[#9CA3AF] block mb-1">TARGET BRAND NAME *</label>
                <input
                  type="text"
                  required
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  placeholder="e.g. Your Company / Application Name"
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#EF4444] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">SUSPECTED DOMAINS OR URLS (ONE PER LINE) *</label>
                <textarea
                  rows={3}
                  required
                  value={formData.suspectedDomains}
                  onChange={(e) => setFormData({ ...formData, suspectedDomains: e.target.value })}
                  placeholder="e.g. yourbrand-support-login.com&#10;yourbrand-kyc.org"
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#EF4444] focus:outline-none font-mono-data"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[#9CA3AF] block mb-1">EMERGENCY CONTACT NAME *</label>
                  <input
                    type="text"
                    required
                    value={formData.contactName}
                    onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
                    placeholder="Security Lead Name"
                    className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#EF4444] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[#9CA3AF] block mb-1">DIRECT WORK EMAIL *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="ciso@yourbrand.com"
                    className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#EF4444] focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#EF4444] hover:bg-[#DC2626] text-white font-semibold rounded-xl transition-all shadow-[0_0_20px_rgba(239,68,68,0.4)] mt-2"
              >
                Submit for Rapid Incident Triage
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="w-12 h-12 rounded-full bg-[#EF4444]/15 text-[#EF4444] flex items-center justify-center mx-auto mb-4 border border-[#EF4444]/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h4 className="text-lg font-bold text-white mb-2">Priority Incident Dispatched</h4>
            <p className="text-xs text-[#9CA3AF] max-w-sm mx-auto mb-6">
              Our automated crawler is now sandboxing the submitted domains. We will deliver the initial forensic evidence package to <strong>{formData.email}</strong> within 1 business day.
            </p>
            <button
              onClick={() => {
                setSubmitted(false);
                onClose();
              }}
              className="px-6 py-2.5 bg-[#111827] text-white text-xs font-semibold rounded-lg border border-white/10 hover:bg-[#1F2937]"
            >
              Close
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// 3. FREE API KEY MODAL
interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    useCase: 'MCP Agent Integration (Claude / Cursor)',
    agreedTerms: false
  });
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState(false);

  if (!isOpen) return null;

  const handleGenerateKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.agreedTerms) return;

    const simulatedKey = `nx_live_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`;
    setApiKey(simulatedKey);
  };

  const handleCopy = () => {
    if (!apiKey) return;
    navigator.clipboard.writeText(apiKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg glass-panel rounded-2xl p-6 sm:p-8 border border-[#3B82F6]/30 bg-[#0B0F19] text-left">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X className="w-5 h-5" />
        </button>

        {!apiKey ? (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Key className="w-4 h-4 text-[#06B6D4]" />
              <span className="text-xs font-mono-data text-[#06B6D4]">FREE DEVELOPER TIER // 1,000 SCANS</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Get Free Nexargio API Key</h3>
            <p className="text-xs text-[#9CA3AF] mb-6">
              Instant key issued in under 1 minute. Works immediately with cURL, Python, Node.js and the official <code className="text-[#06B6D4]">nexargio-mcp</code> server.
            </p>

            <form onSubmit={handleGenerateKey} className="space-y-4 text-xs font-mono-data">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[#9CA3AF] block mb-1">DEVELOPER NAME *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Your Name"
                    className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[#9CA3AF] block mb-1">WORK OR GITHUB EMAIL *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="developer@domain.com"
                    className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">COMPANY OR RESEARCH LAB</label>
                <input
                  type="text"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  placeholder="Organization or Independent Researcher"
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">INTENDED USE CASE</label>
                <select
                  value={formData.useCase}
                  onChange={(e) => setFormData({ ...formData, useCase: e.target.value })}
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#3B82F6] focus:outline-none"
                >
                  <option value="MCP Agent Integration (Claude / Cursor)">MCP Server for Claude Desktop & Cursor</option>
                  <option value="REST API Pipeline">REST API in CI/CD & Security Ingestion</option>
                  <option value="Academic & Threat Research">Academic & Non-Profit Threat Research</option>
                  <option value="SOC Enrichment">SOC Alert Enrichment (Splunk / SOAR)</option>
                </select>
              </div>

              <div className="flex items-start gap-2 pt-2">
                <input
                  type="checkbox"
                  id="api-terms-consent"
                  required
                  checked={formData.agreedTerms}
                  onChange={(e) => setFormData({ ...formData, agreedTerms: e.target.checked })}
                  className="mt-1"
                />
                <label htmlFor="api-terms-consent" className="text-[11px] text-[#9CA3AF] leading-snug">
                  I agree to the API Terms of Service, Acceptable Use Policy, and 1,000 scan quota. I confirm I will not use PIAD for hostile scanning or unauthorized system probes.
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#3B82F6] hover:bg-[#2563EB] text-white font-semibold rounded-xl transition-all shadow-[0_0_20px_rgba(59,130,246,0.3)] mt-2"
              >
                Generate 1,000 Scan API Key
              </button>
            </form>
          </div>
        ) : (
          <div className="py-4">
            <div className="w-12 h-12 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center mx-auto mb-4 border border-[#10B981]/30">
              <Key className="w-6 h-6" />
            </div>
            <h4 className="text-xl font-bold text-white mb-1 text-center">Your Live API Key is Ready</h4>
            <p className="text-xs text-[#9CA3AF] text-center mb-6">
              Assigned to <strong>{formData.email}</strong> · Quota: 1,000 scans
            </p>

            <div className="p-3 bg-[#060911] rounded-xl border border-white/10 font-mono-data text-xs flex items-center justify-between mb-4">
              <span className="text-[#06B6D4] truncate mr-2">{apiKey}</span>
              <button
                onClick={handleCopy}
                className="px-3 py-1.5 bg-[#111827] hover:bg-[#1F2937] text-white rounded-md transition-colors flex items-center gap-1.5 shrink-0"
              >
                {copiedKey ? <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="p-3 bg-[#111827] rounded-xl border border-white/5 font-mono-data text-[11px] text-[#9CA3AF] mb-6 space-y-1">
              <div>// Quick test with cURL:</div>
              <div className="text-white select-all">
                curl -H "Authorization: Bearer {apiKey}" https://api.nexargio.com/v1/scan -d '{`{"url": "https://example.com"}`}'
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2.5 bg-[#3B82F6] text-white text-xs font-semibold rounded-xl"
            >
              Start Scanning
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// 4. REPORT PHISHING SITE MODAL
interface ReportPhishingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportPhishingModal: React.FC<ReportPhishingModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    suspiciousUrl: '',
    whereSeen: 'Phishing Email / SMS',
    reporterEmail: '',
    notes: ''
  });
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg glass-panel rounded-2xl p-6 sm:p-8 border border-white/15 bg-[#0B0F19] text-left">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X className="w-5 h-5" />
        </button>

        {!submitted ? (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#EF4444]" />
              <span className="text-xs font-mono-data text-[#EF4444]">COMMUNITY THREAT REPORT // [REPORT]</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Report a Phishing Site</h3>
            <p className="text-xs text-[#9CA3AF] mb-6">
              Help neutralize live malicious campaigns. Our PIAD engine will immediately sandbox the domain, generate a SHA-256 evidence package, and notify affected registrars.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs font-mono-data">
              <div>
                <label className="text-[#9CA3AF] block mb-1">SUSPICIOUS URL OR LINK *</label>
                <input
                  type="text"
                  required
                  value={formData.suspiciousUrl}
                  onChange={(e) => setFormData({ ...formData, suspiciousUrl: e.target.value })}
                  placeholder="https://malicious-login-example.com/..."
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#EF4444] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">WHERE DID YOU ENCOUNTER THIS?</label>
                <select
                  value={formData.whereSeen}
                  onChange={(e) => setFormData({ ...formData, whereSeen: e.target.value })}
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#EF4444] focus:outline-none"
                >
                  <option value="Phishing Email / SMS">Phishing Email / SMS</option>
                  <option value="WhatsApp / Telegram lure">WhatsApp / Telegram lure</option>
                  <option value="Adversary-in-the-Middle Redirect">Adversary-in-the-Middle Redirect</option>
                  <option value="QR Code on physical receipt">QR Code on physical receipt</option>
                  <option value="Fake Search Ad result">Fake Search Ad result</option>
                </select>
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">YOUR EMAIL (OPTIONAL FOR ACKNOWLEDGEMENT)</label>
                <input
                  type="email"
                  value={formData.reporterEmail}
                  onChange={(e) => setFormData({ ...formData, reporterEmail: e.target.value })}
                  placeholder="optional@domain.com"
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#EF4444] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#EF4444] hover:bg-[#DC2626] text-white font-semibold rounded-xl transition-all mt-2"
              >
                Submit Threat for Immediate Sandboxing
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="w-12 h-12 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center mx-auto mb-4 border border-[#10B981]/30">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-lg font-bold text-white mb-2">Threat Dispatched to PIAD Sandbox</h4>
            <p className="text-xs text-[#9CA3AF] max-w-sm mx-auto mb-6">
              Thank you for contributing to collective digital resilience. The URL is currently undergoing headless GPU adjudication.
            </p>
            <button
              onClick={() => {
                setSubmitted(false);
                onClose();
              }}
              className="px-6 py-2.5 bg-[#111827] text-white text-xs font-semibold rounded-lg border border-white/10 hover:bg-[#1F2937]"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// 5. CORPORATE CLIENT / SOC DASHBOARD PORTAL MODAL (GravityZone / Enterprise equivalent)
interface ClientPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenApiKeyModal: () => void;
}

export const ClientPortalModal: React.FC<ClientPortalModalProps> = ({ 
  isOpen, 
  onClose,
  onOpenApiKeyModal 
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-3xl glass-panel rounded-2xl p-6 sm:p-8 border border-[#3B82F6]/30 bg-[#0B0F19] text-left max-h-[90vh] overflow-y-auto">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Portal Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#3B82F6]/10 border border-[#3B82F6]/30 flex items-center justify-center text-[#3B82F6]">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">Nexargio Enterprise Customer Console</h3>
                <span className="text-[10px] font-mono-data px-2 py-0.5 rounded bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
                  TENANT: ACTIVE
                </span>
              </div>
              <div className="text-xs font-mono-data text-[#6B7280]">
                Workspace: demo.enterprise@nexargio.com · Node: Hyderabad Enclave-01
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
            <span className="text-xs font-mono-data text-[#10B981]">SOC PROBE CONNECTED</span>
          </div>
        </div>

        {/* Executive Metrics Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 font-mono-data text-xs">
          <div className="p-3.5 bg-[#060911] rounded-xl border border-white/5">
            <div className="text-[#6B7280] text-[10px] uppercase">CT LOG INGESTION</div>
            <div className="text-xl font-bold text-[#06B6D4] mt-1">2,410 /s</div>
            <div className="text-[10px] text-[#10B981] mt-0.5">● Global stream healthy</div>
          </div>

          <div className="p-3.5 bg-[#060911] rounded-xl border border-white/5">
            <div className="text-[#6B7280] text-[10px] uppercase">SCANS CONSUMED</div>
            <div className="text-xl font-bold text-white mt-1">438 <span className="text-xs text-[#6B7280]">/ 1,000</span></div>
            <div className="text-[10px] text-[#3B82F6] mt-0.5">Free Developer Tier</div>
          </div>

          <div className="p-3.5 bg-[#060911] rounded-xl border border-white/5">
            <div className="text-[#6B7280] text-[10px] uppercase">AVG ADJUDICATION</div>
            <div className="text-xl font-bold text-[#10B981] mt-1">0.14s</div>
            <div className="text-[10px] text-[#6B7280] mt-0.5">Microsecond fast path</div>
          </div>

          <div className="p-3.5 bg-[#060911] rounded-xl border border-white/5">
            <div className="text-[#6B7280] text-[10px] uppercase">EGRESS BLOCK SYNC</div>
            <div className="text-xl font-bold text-[#3B82F6] mt-1">0.82s</div>
            <div className="text-[10px] text-[#10B981] mt-0.5">Firewalls synchronized</div>
          </div>
        </div>

        {/* Live Detected Interception Stream */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs font-mono-data mb-3">
            <span className="text-white font-semibold flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-[#EF4444]" />
              RECENT PRE-ISSUANCE INTERCEPTIONS
            </span>
            <span className="text-[#6B7280]">AUDIT LOG: CERT-IN 180-DAY IMMUTABLE</span>
          </div>

          <div className="space-y-2 font-mono-data text-xs">
            <div className="p-3 bg-[#060911] rounded-xl border border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-2 py-0.5 rounded bg-[#EF4444]/15 text-[#EF4444] text-[10px] font-bold">
                  HARD BLOCK (95)
                </span>
                <span className="text-white">hdfc-kyc-update-portal[.]org</span>
              </div>
              <span className="text-[#6B7280] text-[11px]">Flagged at cert creation (+0.45s)</span>
            </div>

            <div className="p-3 bg-[#060911] rounded-xl border border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-2 py-0.5 rounded bg-[#EF4444]/15 text-[#EF4444] text-[10px] font-bold">
                  HARD BLOCK (92)
                </span>
                <span className="text-white">ucpaytm[.]store</span>
              </div>
              <span className="text-[#6B7280] text-[11px]">UPI Collect Spoof (+0.62s)</span>
            </div>

            <div className="p-3 bg-[#060911] rounded-xl border border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-2 py-0.5 rounded bg-[#10B981]/15 text-[#10B981] text-[10px] font-bold">
                  PERMIT (0)
                </span>
                <span className="text-white">hyd-artisancrafts.co.in</span>
              </div>
              <span className="text-[#10B981] text-[11px]">Fast-path cleared in 0.08s</span>
            </div>
          </div>
        </div>

        {/* Quick Enterprise Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10">
          <div className="text-xs text-[#9CA3AF]">
            Need more scan volume, dedicated SIEM connectors, or on-prem deployment?
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                onClose();
                onOpenApiKeyModal();
              }}
              className="px-4 py-2 bg-[#111827] hover:bg-[#1F2937] text-white text-xs font-semibold rounded-lg border border-white/10"
            >
              Rotate API Key
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-lg"
            >
              Close Console
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// 6. TECHNICAL BENCHMARK PDF PREVIEW MODAL
interface BenchmarkPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBriefingModal: () => void;
}

export const BenchmarkPreviewModal: React.FC<BenchmarkPreviewModalProps> = ({
  isOpen,
  onClose,
  onOpenBriefingModal
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl glass-panel rounded-2xl p-6 sm:p-8 border border-white/15 bg-[#0B0F19] text-left max-h-[90vh] overflow-y-auto">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <span className="px-2 py-0.5 rounded bg-[#3B82F6]/15 text-[#3B82F6] text-xs font-mono-data font-bold">
            RESEARCH REPORT V1.0.0 // PEER-VERIFIED
          </span>
        </div>

        <h3 className="text-2xl font-bold text-white mb-2">
          Technical Benchmark Report: Pre-Issuance Efficacy
        </h3>
        <p className="text-xs text-[#9CA3AF] mb-6 font-mono-data">
          Published by Nexargio Threat Research Lab, T-Hub Phase 2, Hyderabad · October 2026
        </p>

        {/* Executive Summary */}
        <div className="p-4 rounded-xl bg-[#060911] border border-white/5 space-y-3 text-xs text-[#9CA3AF] leading-relaxed mb-6">
          <div className="text-white font-bold font-mono-data">// EXECUTIVE SUMMARY:</div>
          <p>
            This empirical study evaluated 10,000 live phishing URLs collected from PhishTank, OpenPhish, and continuous Certificate Transparency logs. PIAD achieved a <strong>98.11% zero-day recall</strong> with a <strong>0.00% false positive rate</strong> across the top 500 global banking domains.
          </p>
          <p>
            Crucially, PIAD intercepted malicious domains at the point of certificate broadcast—averaging <strong>0.14 seconds</strong> in the fast path—delivering an operational head-start of 12 to 24 hours before traditional commercial scanning gateways updated their public reputation feeds.
          </p>
        </div>

        {/* Key Stats Table */}
        <div className="grid grid-cols-2 gap-3 mb-6 font-mono-data text-xs">
          {BENCHMARK_STATS.map((s, i) => (
            <div key={i} className="p-3 bg-[#111827] rounded-lg border border-white/5">
              <div className="text-lg font-bold text-white">{s.value}</div>
              <div className="text-[#3B82F6] font-semibold text-[11px]">{s.label}</div>
              <div className="text-[#6B7280] text-[10px] mt-1">{s.dataset}</div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between gap-3 pt-4 border-t border-white/10">
          <span className="text-xs text-[#6B7280] font-mono-data">
            Document SHA-256: 7a9e2f...c31b
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                onClose();
                onOpenBriefingModal();
              }}
              className="px-4 py-2 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Full PDF Report</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
