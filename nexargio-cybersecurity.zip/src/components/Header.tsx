import React, { useState, useRef, useEffect } from 'react';
import { 
  ShieldAlert, 
  ChevronDown, 
  Menu, 
  X, 
  ArrowRight, 
  Phone, 
  Globe, 
  UserCheck, 
  Search, 
  Shield, 
  Activity, 
  Lock, 
  ExternalLink,
  Building,
  Headphones,
  Sliders
} from 'lucide-react';
import { PageView } from '../types';

interface HeaderProps {
  currentView: PageView;
  onNavigate: (view: PageView, sectionId?: string) => void;
  onOpenBriefingModal: (interest?: string) => void;
  onOpenBrandUnderAttackModal: () => void;
  onOpenApiKeyModal: () => void;
  onOpenClientPortal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onOpenBriefingModal,
  onOpenBrandUnderAttackModal,
  onOpenApiKeyModal,
  onOpenClientPortal,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navRef = useRef<HTMLDivElement | null>(null);

  // Close mega menu on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) {
        setActiveMenu(null);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const handleLinkClick = (view: PageView, sectionId?: string) => {
    setActiveMenu(null);
    setMobileMenuOpen(false);
    onNavigate(view, sectionId);
  };

  return (
    <header ref={navRef} className="sticky top-0 z-50 w-full bg-[#060911]/95 backdrop-blur-md border-b border-white/[0.08]">
      
      {/* 1. TOP CORPORATE UTILITY BAR (Standard in Bitdefender, Palo Alto, CrowdStrike) */}
      <div className="hidden lg:block bg-[#04060B] border-b border-white/[0.05] text-[11px] font-mono-data py-1.5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-[#9CA3AF]">
          
          {/* Left: Audience Segments */}
          <div className="flex items-center gap-5">
            <button 
              onClick={() => handleLinkClick('home')} 
              className={`hover:text-white transition-colors ${currentView === 'home' ? 'text-[#3B82F6] font-semibold' : ''}`}
            >
              Enterprise & SOCs
            </button>
            <span className="text-white/20">|</span>
            <button 
              onClick={() => handleLinkClick('solutions', 'government')} 
              className="hover:text-white transition-colors"
            >
              Government & Defense
            </button>
            <span className="text-white/20">|</span>
            <button 
              onClick={() => handleLinkClick('solutions', 'mssp')} 
              className="hover:text-white transition-colors"
            >
              MSSP Partners
            </button>
            <span className="text-white/20">|</span>
            <button 
              onClick={() => handleLinkClick('home', 'developers-api')} 
              className="hover:text-white transition-colors text-[#06B6D4]"
            >
              Developer API & MCP
            </button>
          </div>

          {/* Right: Corporate Support, Phone & Region */}
          <div className="flex items-center gap-5">
            <div className="flex items-center gap-1.5 text-[#9CA3AF]">
              <Phone className="w-3 h-3 text-[#3B82F6]" />
              <span>SOC Desk: +91 40 6810 2026</span>
            </div>
            <span className="text-white/20">|</span>
            <div className="flex items-center gap-1 text-[#9CA3AF]">
              <Globe className="w-3 h-3" />
              <span>India · Global Enclaves</span>
            </div>
            <span className="text-white/20">|</span>
            <button 
              onClick={onOpenClientPortal}
              className="flex items-center gap-1 text-[#F9FAFB] hover:text-[#3B82F6] transition-colors font-semibold"
            >
              <UserCheck className="w-3 h-3 text-[#10B981]" />
              <span>Customer Portal Login</span>
            </button>
          </div>

        </div>
      </div>

      {/* 2. PRIMARY CORPORATE NAVIGATION ROW */}
      <div className="max-w-7xl mx-auto h-16 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-6">
        
        {/* Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <button 
            onClick={() => handleLinkClick('home')}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            {/* Nexargio Sovereign Cyber Shield Icon */}
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#3B82F6] to-[#06B6D4] p-0.5 flex items-center justify-center shadow-[0_0_20px_rgba(59,130,246,0.35)]">
              <div className="w-full h-full bg-[#060911] rounded-[10px] flex items-center justify-center">
                <div className="w-4 h-4 bg-gradient-to-tr from-[#3B82F6] to-[#06B6D4] rotate-45 group-hover:rotate-90 transition-transform duration-300" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="font-outfit font-extrabold text-xl tracking-tight text-[#F9FAFB] leading-none">
                NEXARGIO
              </span>
              <span className="text-[9px] font-mono-data tracking-widest text-[#06B6D4] uppercase leading-tight mt-0.5">
                ENTERPRISE ZERO-DAY DEFENSE
              </span>
            </div>
          </button>
        </div>

        {/* Center Mega Navigation (Desktop) */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          
          {/* Platform Mega Menu */}
          <div className="relative" onMouseEnter={() => setActiveMenu('platform')}>
            <button
              onClick={() => handleLinkClick('platform')}
              className={`px-3 py-2 text-sm font-medium transition-colors flex items-center gap-1.5 rounded-lg ${
                activeMenu === 'platform' || currentView === 'platform'
                  ? 'text-[#3B82F6] bg-white/5'
                  : 'text-[#9CA3AF] hover:text-[#F9FAFB]'
              }`}
            >
              <span>Platform</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeMenu === 'platform' ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Solutions Mega Menu */}
          <div className="relative" onMouseEnter={() => setActiveMenu('solutions')}>
            <button
              onClick={() => handleLinkClick('solutions')}
              className={`px-3 py-2 text-sm font-medium transition-colors flex items-center gap-1.5 rounded-lg ${
                activeMenu === 'solutions' || currentView === 'solutions'
                  ? 'text-[#3B82F6] bg-white/5'
                  : 'text-[#9CA3AF] hover:text-[#F9FAFB]'
              }`}
            >
              <span>Solutions</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeMenu === 'solutions' ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Threat Research Mega Menu */}
          <div className="relative" onMouseEnter={() => setActiveMenu('research')}>
            <button
              onClick={() => handleLinkClick('research')}
              className={`px-3 py-2 text-sm font-medium transition-colors flex items-center gap-1.5 rounded-lg ${
                activeMenu === 'research' || currentView === 'research'
                  ? 'text-[#3B82F6] bg-white/5'
                  : 'text-[#9CA3AF] hover:text-[#F9FAFB]'
              }`}
            >
              <span>Threat Research</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeMenu === 'research' ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Partners Mega Menu */}
          <div className="relative" onMouseEnter={() => setActiveMenu('partners')}>
            <button
              onClick={() => handleLinkClick('home', 'take-next-step')}
              className={`px-3 py-2 text-sm font-medium transition-colors flex items-center gap-1.5 rounded-lg ${
                activeMenu === 'partners'
                  ? 'text-[#3B82F6] bg-white/5'
                  : 'text-[#9CA3AF] hover:text-[#F9FAFB]'
              }`}
            >
              <span>Partners</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeMenu === 'partners' ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Company Mega Menu */}
          <div className="relative" onMouseEnter={() => setActiveMenu('company')}>
            <button
              onClick={() => handleLinkClick('company')}
              className={`px-3 py-2 text-sm font-medium transition-colors flex items-center gap-1.5 rounded-lg ${
                activeMenu === 'company' || currentView === 'company' || currentView === 'leadership'
                  ? 'text-[#3B82F6] bg-white/5'
                  : 'text-[#9CA3AF] hover:text-[#F9FAFB]'
              }`}
            >
              <span>Company</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeMenu === 'company' ? 'rotate-180' : ''}`} />
            </button>
          </div>
        </nav>

        {/* Right Corporate Actions Zone */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* Brand Under Attack? Urgent Path (Bitdefender's 'Experienced a Breach?' equivalent) */}
          <button
            onClick={onOpenBrandUnderAttackModal}
            className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-[#EF4444] hover:text-white transition-colors py-1.5 px-2.5 rounded-lg bg-[#EF4444]/10 hover:bg-[#EF4444] border border-[#EF4444]/25"
          >
            <ShieldAlert className="w-3.5 h-3.5 animate-pulse" />
            <span>Brand Under Attack?</span>
          </button>

          {/* URL Checker Direct Link */}
          <button
            onClick={() => handleLinkClick('checker', 'analyst-checker')}
            className="hidden md:inline-flex items-center gap-1.5 text-xs font-mono-data text-[#06B6D4] hover:text-white px-3 py-1.5 rounded-lg border border-[#06B6D4]/30 bg-[#06B6D4]/10 hover:bg-[#06B6D4]/20 transition-all"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Live URL Checker</span>
          </button>

          {/* Start Free (Secondary) */}
          <button
            onClick={onOpenApiKeyModal}
            className="hidden xl:inline-flex items-center justify-center px-3.5 py-1.5 text-xs font-medium text-[#F9FAFB] hover:text-white bg-[#111827] hover:bg-[#1F2937] border border-white/10 hover:border-white/20 rounded-lg transition-colors whitespace-nowrap"
          >
            Free API Key
          </button>

          {/* Primary CTA: Schedule Executive Briefing */}
          <button
            onClick={() => onOpenBriefingModal('Enterprise & SOCs')}
            className="inline-flex items-center justify-center px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-[#3B82F6] hover:bg-[#2563EB] rounded-lg shadow-[0_0_20px_rgba(59,130,246,0.35)] transition-all whitespace-nowrap"
          >
            Schedule Briefing
          </button>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 lg:hidden text-[#9CA3AF] hover:text-white rounded-lg focus:outline-none"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Desktop Full-Width Mega Menu Dropdown */}
      {activeMenu && (
        <div 
          className="hidden lg:block absolute top-full left-0 w-full bg-[#0B0F19]/98 backdrop-blur-2xl border-b border-white/10 shadow-2xl transition-all"
          onMouseLeave={() => setActiveMenu(null)}
        >
          <div className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
            
            {/* PLATFORM MEGA PANEL */}
            {activeMenu === 'platform' && (
              <div className="grid grid-cols-12 gap-8">
                {/* Col 1: Platform Capabilities */}
                <div className="col-span-4 border-r border-white/5 pr-6">
                  <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-4">
                    ENTERPRISE PLATFORM
                  </div>
                  <ul className="space-y-3.5">
                    <li>
                      <button 
                        onClick={() => handleLinkClick('platform')}
                        className="text-left w-full group"
                      >
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6] transition-colors">
                          Platform Overview
                        </div>
                        <div className="text-xs text-[#6B7280]">Continuous identity intelligence & zero-day prevention</div>
                      </button>
                    </li>
                    <li>
                      <button 
                        onClick={() => handleLinkClick('platform', 'piad-engine')}
                        className="text-left w-full group"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-white group-hover:text-[#3B82F6] transition-colors">
                            PIAD v4.0 Engine
                          </span>
                          <span className="text-[10px] font-mono-data px-1.5 py-0.5 rounded bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">LIVE</span>
                        </div>
                        <div className="text-xs text-[#6B7280]">Left-of-live certificate transparency interception & sandboxing</div>
                      </button>
                    </li>
                    <li>
                      <div className="text-left w-full opacity-80">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-[#9CA3AF]">Vigilance-X</span>
                          <span className="text-[10px] font-mono-data px-1.5 py-0.5 rounded bg-white/5 text-[#9CA3AF]">Roadmap</span>
                        </div>
                        <div className="text-xs text-[#6B7280]">eBPF kernel enforcement & autonomous AI agent governance</div>
                      </div>
                    </li>
                    <li>
                      <div className="text-left w-full opacity-80">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-[#9CA3AF]">VASS-Onyx</span>
                          <span className="text-[10px] font-mono-data px-1.5 py-0.5 rounded bg-white/5 text-[#9CA3AF]">Roadmap</span>
                        </div>
                        <div className="text-xs text-[#6B7280]">Dynamic identity graph & SIEM containment orchestrator</div>
                      </div>
                    </li>
                    <li>
                      <div className="text-left w-full opacity-80">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-[#9CA3AF]">Nexa AI Copilot</span>
                          <span className="text-[10px] font-mono-data px-1.5 py-0.5 rounded bg-[#8B5CF6]/15 text-[#8B5CF6]">Roadmap</span>
                        </div>
                        <div className="text-xs text-[#6B7280]">Air-gapped security copilot translating raw telemetry</div>
                      </div>
                    </li>
                  </ul>
                </div>

                {/* Col 2: Ingestion & Developer Tools */}
                <div className="col-span-4 border-r border-white/5 pr-6">
                  <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-4">
                    INGESTION & INTEGRATIONS
                  </div>
                  <ul className="space-y-3.5">
                    <li>
                      <button 
                        onClick={() => handleLinkClick('home', 'developers-api')}
                        className="text-left w-full group"
                      >
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6] transition-colors flex items-center justify-between">
                          <span>REST API Integration</span>
                          <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <div className="text-xs text-[#6B7280]">Sub-150ms automated URL inspection endpoints</div>
                      </button>
                    </li>
                    <li>
                      <button 
                        onClick={() => handleLinkClick('home', 'developers-api')}
                        className="text-left w-full group"
                      >
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6] transition-colors">
                          MCP Server (<code className="text-[#06B6D4]">nexargio-mcp</code>)
                        </div>
                        <div className="text-xs text-[#6B7280]">Official package for Claude Desktop & Cursor IDE</div>
                      </button>
                    </li>
                    <li>
                      <button 
                        onClick={() => handleLinkClick('platform', 'threat-feed')}
                        className="text-left w-full group"
                      >
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6] transition-colors">
                          Streaming Threat Intel Feeds
                        </div>
                        <div className="text-xs text-[#6B7280]">Continuous malicious infrastructure feed for Splunk & Sentinel</div>
                      </button>
                    </li>
                    <li>
                      <button 
                        onClick={() => handleLinkClick('platform', 'brand-dossiers')}
                        className="text-left w-full group"
                      >
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6] transition-colors">
                          Brand Impersonation Dossiers
                        </div>
                        <div className="text-xs text-[#6B7280]">Court-admissible SHA-256 evidence packages for takedowns</div>
                      </button>
                    </li>
                  </ul>
                </div>

                {/* Col 3: Corporate Spotlight */}
                <div className="col-span-4 bg-[#111827] rounded-xl p-5 border border-white/5 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-mono-data text-[#06B6D4] uppercase">TECHNICAL BENCHMARK REPORT</span>
                    <h4 className="text-base font-bold text-white mt-1 mb-2">99.67% Precision across 10,000 Live Phishing URLs</h4>
                    <p className="text-xs text-[#9CA3AF]">
                      Comparative laboratory analysis measuring pre-issuance interception recall against 90 commercial scanning gateways.
                    </p>
                  </div>
                  <button 
                    onClick={() => handleLinkClick('research')}
                    className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-[#3B82F6] hover:text-[#60A5FA]"
                  >
                    <span>Read the Benchmark Study</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* SOLUTIONS MEGA PANEL */}
            {activeMenu === 'solutions' && (
              <div className="grid grid-cols-12 gap-8">
                <div className="col-span-6 border-r border-white/5 pr-6">
                  <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-4">
                    SOLUTIONS BY INDUSTRY SECTOR
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      onClick={() => handleLinkClick('solutions', 'banking')}
                      className="text-left group p-3 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Banking & FinTech</div>
                      <div className="text-xs text-[#6B7280] mt-0.5">Stop UPI traps & fake net banking clones</div>
                    </button>
                    <button 
                      onClick={() => handleLinkClick('solutions', 'government')}
                      className="text-left group p-3 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Government & Defense</div>
                      <div className="text-xs text-[#6B7280] mt-0.5">Sovereign, air-gapped threat intelligence</div>
                    </button>
                    <button 
                      onClick={() => handleLinkClick('solutions', 'crypto-web3')}
                      className="text-left group p-3 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Crypto & Web3 Brands</div>
                      <div className="text-xs text-[#6B7280] mt-0.5">Prevent automated wallet drainer attacks</div>
                    </button>
                    <button 
                      onClick={() => handleLinkClick('solutions', 'enterprise-soc')}
                      className="text-left group p-3 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Enterprise SOCs</div>
                      <div className="text-xs text-[#6B7280] mt-0.5">Explainable AiTM triage for analysts</div>
                    </button>
                  </div>
                </div>

                <div className="col-span-6">
                  <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-4">
                    SOLUTIONS BY STAKEHOLDER ROLE
                  </div>
                  <div className="space-y-3">
                    <button 
                      onClick={() => handleLinkClick('solutions', 'mssp')}
                      className="text-left w-full group p-3 rounded-lg hover:bg-white/5 transition-colors flex items-center justify-between"
                    >
                      <div>
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">For MSSPs & MDRs</div>
                        <div className="text-xs text-[#6B7280]">Resell explainable phishing verdicts with white-label reports</div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-[#3B82F6] opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                    <button 
                      onClick={() => handleLinkClick('solutions', 'enterprise-soc')}
                      className="text-left w-full group p-3 rounded-lg hover:bg-white/5 transition-colors flex items-center justify-between"
                    >
                      <div>
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">For CISOs</div>
                        <div className="text-xs text-[#6B7280]">Eliminate AiTM session hijacking and corporate brand liability</div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-[#3B82F6] opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                    <button 
                      onClick={() => handleLinkClick('solutions', 'banking')}
                      className="text-left w-full group p-3 rounded-lg hover:bg-white/5 transition-colors flex items-center justify-between"
                    >
                      <div>
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">For Fraud & AML Teams</div>
                        <div className="text-xs text-[#6B7280]">Correlate bulletproof hosting networks and payment syndicates</div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-[#3B82F6] opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* THREAT RESEARCH MEGA PANEL */}
            {activeMenu === 'research' && (
              <div className="grid grid-cols-12 gap-8">
                <div className="col-span-8">
                  <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-4">
                    PROVEN IN THE WILD // LIVE THREAT DOSSIERS
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <button
                      onClick={() => handleLinkClick('research', 'openai-collab')}
                      className="text-left p-3.5 bg-[#111827] rounded-xl border border-white/5 hover:border-[#3B82F6]/50 transition-colors"
                    >
                      <div className="text-[10px] font-mono-data text-[#EF4444] mb-1">RISK 85/100 · AiTM</div>
                      <div className="text-sm font-semibold text-white">OpenAI Collab Clone</div>
                      <p className="text-xs text-[#6B7280] mt-1 line-clamp-2">Zero engines flagged upon issuance. Intercepted left-of-live.</p>
                    </button>
                    <button
                      onClick={() => handleLinkClick('research', 'paytm-gaming')}
                      className="text-left p-3.5 bg-[#111827] rounded-xl border border-white/5 hover:border-[#3B82F6]/50 transition-colors"
                    >
                      <div className="text-[10px] font-mono-data text-[#EF4444] mb-1">RISK 92/100 · UPI FRAUD</div>
                      <div className="text-sm font-semibold text-white">ucpaytm[.]store</div>
                      <p className="text-xs text-[#6B7280] mt-1 line-clamp-2">Mobile gaming lure harvesting banking sessions and merchant UPI collect intent.</p>
                    </button>
                    <button
                      onClick={() => handleLinkClick('research', 'indian-banking')}
                      className="text-left p-3.5 bg-[#111827] rounded-xl border border-white/5 hover:border-[#3B82F6]/50 transition-colors"
                    >
                      <div className="text-[10px] font-mono-data text-[#EF4444] mb-1">RISK 95/100 · BANKING</div>
                      <div className="text-sm font-semibold text-white">HDFC/SBI KYC Spoof</div>
                      <p className="text-xs text-[#6B7280] mt-1 line-clamp-2">Pre-issuance CT detection of net banking credential traps under 5 seconds.</p>
                    </button>
                  </div>
                </div>

                <div className="col-span-4 border-l border-white/5 pl-6">
                  <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-4">
                    INTELLECTUAL PROPERTY & BENCHMARKS
                  </div>
                  <ul className="space-y-3">
                    <li>
                      <button 
                        onClick={() => handleLinkClick('research', 'patent')}
                        className="text-left group"
                      >
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">
                          Patent Application 202641043441
                        </div>
                        <div className="text-xs text-[#6B7280]">Multi-layered recursive normalization and adversarial analysis</div>
                      </button>
                    </li>
                    <li>
                      <button 
                        onClick={() => handleLinkClick('research', 'benchmarks')}
                        className="text-left group"
                      >
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">
                          Technical Benchmark Report v1.0.0
                        </div>
                        <div className="text-xs text-[#6B7280]">Empirical methodology measuring 10,000 live phishing URLs</div>
                      </button>
                    </li>
                    <li>
                      <button 
                        onClick={() => handleLinkClick('research', 'bulletins')}
                        className="text-left group"
                      >
                        <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">
                          Weekly Threat Bulletins
                        </div>
                        <div className="text-xs text-[#6B7280]">Weekly emerging zero-day phishing infrastructure analyses</div>
                      </button>
                    </li>
                  </ul>
                </div>
              </div>
            )}

            {/* PARTNERS MEGA PANEL */}
            {activeMenu === 'partners' && (
              <div className="grid grid-cols-12 gap-8">
                <div className="col-span-4 p-5 rounded-xl bg-[#111827] border border-white/5">
                  <h4 className="text-base font-bold text-white mb-1">MSSP Partner Program</h4>
                  <p className="text-xs text-[#9CA3AF] mb-4">
                    Equip your SOC with left-of-live phishing defense. Includes 300–500 URL live trial pilot and white-label reporting.
                  </p>
                  <button 
                    onClick={() => handleLinkClick('home', 'take-next-step')}
                    className="text-xs font-semibold text-[#3B82F6] hover:underline"
                  >
                    Register as Partner &rarr;
                  </button>
                </div>
                <div className="col-span-4 p-5 rounded-xl bg-[#111827] border border-white/5">
                  <h4 className="text-base font-bold text-white mb-1">Technology Licensing & OEM</h4>
                  <p className="text-xs text-[#9CA3AF] mb-4">
                    Embed PIAD microsecond threat evaluation into enterprise secure web gateways, email security, and browser engines.
                  </p>
                  <button 
                    onClick={() => handleLinkClick('home', 'take-next-step')}
                    className="text-xs font-semibold text-[#3B82F6] hover:underline"
                  >
                    OEM Inquiries &rarr;
                  </button>
                </div>
                <div className="col-span-4 p-5 rounded-xl bg-[#111827] border border-white/5">
                  <h4 className="text-base font-bold text-white mb-1">Developer & Agent Access</h4>
                  <p className="text-xs text-[#9CA3AF] mb-4">
                    Deploy <code className="text-[#06B6D4]">nexargio-mcp</code> to grant autonomous AI agents live URL inspection permissions.
                  </p>
                  <button 
                    onClick={onOpenApiKeyModal}
                    className="text-xs font-semibold text-[#06B6D4] hover:underline"
                  >
                    Get Free API Key &rarr;
                  </button>
                </div>
              </div>
            )}

            {/* COMPANY MEGA PANEL */}
            {activeMenu === 'company' && (
              <div className="grid grid-cols-12 gap-8">
                <div className="col-span-4 space-y-3.5">
                  <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-2">ABOUT NEXARGIO</div>
                  <button 
                    onClick={() => handleLinkClick('company')}
                    className="text-left w-full group block"
                  >
                    <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">About the Company</div>
                    <div className="text-xs text-[#6B7280]">Born at T-Hub Hyderabad to rebuild continuous digital trust</div>
                  </button>
                  <button 
                    onClick={() => handleLinkClick('leadership')}
                    className="text-left w-full group block"
                  >
                    <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Leadership & Founders</div>
                    <div className="text-xs text-[#6B7280]">Manohar Nidamanuri (CEO) & Venkatesh Nutalapati (CTO)</div>
                  </button>
                  <button 
                    onClick={() => handleLinkClick('company', 'manifesto')}
                    className="text-left w-full group block"
                  >
                    <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Our Manifesto</div>
                    <div className="text-xs text-[#6B7280]">Why static perimeters died and continuous trust is non-negotiable</div>
                  </button>
                </div>

                <div className="col-span-4 space-y-3.5">
                  <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-2">GOVERNANCE & TRUST</div>
                  <button 
                    onClick={() => handleLinkClick('company', 'careers')}
                    className="text-left w-full group block"
                  >
                    <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Careers (16+ Team)</div>
                    <div className="text-xs text-[#6B7280]">Join engineers pioneering low-latency sovereign defense</div>
                  </button>
                  <button 
                    onClick={() => handleLinkClick('company', 'trust')}
                    className="text-left w-full group block"
                  >
                    <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Trust Center & Compliance</div>
                    <div className="text-xs text-[#6B7280]">India DPDP Act compliance, ISO 27001 & SOC 2 roadmap</div>
                  </button>
                  <button 
                    onClick={() => onOpenBriefingModal('Corporate Contact')}
                    className="text-left w-full group block"
                  >
                    <div className="text-sm font-semibold text-white group-hover:text-[#3B82F6]">Contact & Offices</div>
                    <div className="text-xs text-[#6B7280]">Inquire for enterprise pilots, POCs, and security reviews</div>
                  </button>
                </div>

                <div className="col-span-4 bg-[#111827] rounded-xl p-5 border border-white/5 text-xs">
                  <div className="font-mono-data text-[#06B6D4] text-[10px] uppercase mb-1">CORPORATE ENTITY INFO</div>
                  <div className="font-bold text-white mb-1">Nexargio Private Limited</div>
                  <div className="text-[#9CA3AF] mb-2 font-mono-data">CIN: U62099TS2026PTC215481 · DPIIT: DIPP262372</div>
                  <div className="text-[#9CA3AF] mb-2">UK Entity: Nexargio UK Ltd (Co. No. 17277722)</div>
                  <div className="text-[#6B7280]">Global HQ: T-Hub Phase 2, Madhapur, Hyderabad, India</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-16 bg-[#060911]/98 backdrop-blur-2xl border-b border-white/10 p-6 max-h-[calc(100vh-4rem)] overflow-y-auto">
          <div className="space-y-6">
            <div>
              <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-2">ENTERPRISE NAVIGATION</div>
              <div className="flex flex-col space-y-2.5">
                <button
                  onClick={() => handleLinkClick('home')}
                  className="text-left py-2 text-base font-semibold text-[#F9FAFB] hover:text-[#3B82F6]"
                >
                  Home
                </button>
                <button
                  onClick={() => handleLinkClick('platform')}
                  className="text-left py-2 text-base font-semibold text-[#F9FAFB] hover:text-[#3B82F6]"
                >
                  Platform & PIAD v4.0
                </button>
                <button
                  onClick={() => handleLinkClick('solutions')}
                  className="text-left py-2 text-base font-semibold text-[#F9FAFB] hover:text-[#3B82F6]"
                >
                  Enterprise Solutions
                </button>
                <button
                  onClick={() => handleLinkClick('research')}
                  className="text-left py-2 text-base font-semibold text-[#F9FAFB] hover:text-[#3B82F6]"
                >
                  Research & Case Dossiers
                </button>
                <button
                  onClick={() => handleLinkClick('leadership')}
                  className="text-left py-2 text-base font-semibold text-[#F9FAFB] hover:text-[#3B82F6]"
                >
                  Company & Leadership
                </button>
                <button
                  onClick={() => handleLinkClick('checker', 'analyst-checker')}
                  className="text-left py-2 text-base font-semibold text-[#06B6D4]"
                >
                  Live Threat Scanner (Alpha Mountain Model)
                </button>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBrandUnderAttackModal();
                }}
                className="w-full py-2.5 px-4 rounded-lg bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444] text-sm font-semibold flex items-center justify-center gap-2"
              >
                <ShieldAlert className="w-4 h-4" />
                <span>Brand Under Attack?</span>
              </button>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenClientPortal();
                }}
                className="w-full py-2.5 px-4 rounded-lg bg-[#111827] border border-white/10 text-white text-sm font-medium flex items-center justify-center gap-2"
              >
                <UserCheck className="w-4 h-4 text-[#10B981]" />
                <span>Customer Portal Login</span>
              </button>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenApiKeyModal();
                }}
                className="w-full py-2.5 px-4 rounded-lg bg-[#111827] border border-white/10 text-white text-sm font-medium"
              >
                Get Free API Key (1,000 Scans)
              </button>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBriefingModal('Enterprise Briefing');
                }}
                className="w-full py-2.5 px-4 rounded-lg bg-[#3B82F6] text-white text-sm font-semibold"
              >
                Schedule Executive Briefing
              </button>
            </div>
          </div>
        </div>
      )}

    </header>
  );
};
