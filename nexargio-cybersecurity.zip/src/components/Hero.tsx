import React from 'react';
import { ArrowRight, Shield, Award, Terminal, Lock, Activity, CheckCircle2, ChevronRight } from 'lucide-react';
import { HeroCanvas } from './HeroCanvas';

interface HeroProps {
  onOpenBriefingModal: () => void;
  onOpenApiKeyModal: () => void;
  onExplorePlatform: () => void;
  onLaunchChecker: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onOpenBriefingModal,
  onOpenApiKeyModal,
  onExplorePlatform,
  onLaunchChecker,
}) => {
  return (
    <section className="relative pt-8 pb-16 lg:pt-12 lg:pb-24 overflow-hidden border-b border-white/[0.06]">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[450px] bg-[#3B82F6]/10 blur-[150px] pointer-events-none rounded-full" />
      <div className="absolute bottom-10 right-10 w-[400px] h-[300px] bg-[#06B6D4]/10 blur-[130px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Corporate Status Ticker */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#111827] border border-white/10 text-xs font-mono-data mb-6 shadow-sm">
          <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
          <span className="text-[#F9FAFB] font-semibold">ENTERPRISE ZERO-DAY INTELLIGENCE</span>
          <span className="text-white/20">|</span>
          <span className="text-[#06B6D4]">PRE-ISSUANCE INTERCEPTION ACTIVE</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column 55%: Corporate Narrative & Actions */}
          <div className="lg:col-span-7 flex flex-col items-start text-left z-10">
            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-[54px] font-extrabold text-[#F9FAFB] tracking-tight leading-[1.08] mb-6 text-balance">
              Continuously validate trust across every identity, workload, API, and AI agent.
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-[#9CA3AF] leading-relaxed mb-8 max-w-2xl text-balance">
              Nexargio detects, adjudicates and enforces trust decisions across human, machine and autonomous environments in real time — and catches phishing infrastructure at certificate issuance, before the first link is sent.
            </p>

            {/* Action Row */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 mb-8 w-full sm:w-auto">
              <button
                onClick={onOpenBriefingModal}
                className="px-6 py-3.5 bg-[#3B82F6] hover:bg-[#2563EB] text-white font-semibold text-sm sm:text-base rounded-xl shadow-[0_0_25px_rgba(59,130,246,0.4)] transition-all flex items-center justify-center gap-2"
              >
                <span>Schedule Executive Briefing</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onLaunchChecker}
                className="px-5 py-3.5 bg-[#111827] hover:bg-[#1F2937] text-white border border-white/10 hover:border-white/20 font-medium text-sm sm:text-base rounded-xl transition-all flex items-center justify-center gap-2"
              >
                <Activity className="w-4 h-4 text-[#06B6D4]" />
                <span>Evaluate URL (Live Tool)</span>
              </button>

              <button
                onClick={onOpenApiKeyModal}
                className="px-4 py-3.5 bg-transparent hover:bg-white/5 text-[#9CA3AF] hover:text-white font-mono-data text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <Terminal className="w-3.5 h-3.5 text-[#3B82F6]" />
                <span>Start Free (1,000 Scans)</span>
              </button>
            </div>

            {/* Corporate Proof Badges Strip (Section 6.1 & Corporate Governance) */}
            <div className="pt-6 border-t border-white/10 w-full flex flex-wrap items-center gap-y-2 gap-x-4 text-xs font-mono-data text-[#9CA3AF]">
              <span className="flex items-center gap-1.5 text-[#F9FAFB]">
                <Award className="w-3.5 h-3.5 text-[#3B82F6]" />
                DPIIT Recognized
                <span className="text-[#6B7280]">· DIPP262372</span>
              </span>
              <span className="text-white/20 hidden sm:inline">|</span>
              <span className="flex items-center gap-1.5 text-[#F9FAFB]">
                <Shield className="w-3.5 h-3.5 text-[#06B6D4]" />
                Patent Pending
                <span className="text-[#6B7280]">· TEMP/E-1/47712/2026-CHE</span>
              </span>
              <span className="text-white/20 hidden sm:inline">|</span>
              <span className="flex items-center gap-1.5 text-[#10B981]">
                <Lock className="w-3.5 h-3.5" />
                Air-gapped deployment ready
              </span>
            </div>
          </div>

          {/* Right Column 45%: Animated Identity Graph Canvas */}
          <div className="lg:col-span-5 relative z-10 w-full">
            <HeroCanvas />
          </div>

        </div>

      </div>
    </section>
  );
};
