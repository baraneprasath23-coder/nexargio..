import React, { useState } from 'react';
import { Terminal, Copy, CheckCircle2, ArrowRight, Bot, Key, Sparkles } from 'lucide-react';

interface DeveloperApiMcpProps {
  onOpenApiKeyModal: () => void;
  onOpenBriefingModal: () => void;
}

export const DeveloperApiMcp: React.FC<DeveloperApiMcpProps> = ({
  onOpenApiKeyModal,
  onOpenBriefingModal,
}) => {
  const [activeTab, setActiveTab] = useState<'curl' | 'python' | 'mcp'>('curl');
  const [copiedCode, setCopiedCode] = useState(false);

  const codeSnippets = {
    curl: `curl -X POST https://api.nexargio.com/v1/scan \\
  -H "Authorization: Bearer $NEXARGIO_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "url": "https://suspicious-example.com",
    "mode": "pre_issuance_deep",
    "return_evidence_hash": true
  }'`,
    python: `import os
import requests

api_key = os.getenv("NEXARGIO_API_KEY")
response = requests.post(
    "https://api.nexargio.com/v1/scan",
    headers={"Authorization": f"Bearer {api_key}"},
    json={
        "url": "https://suspicious-example.com",
        "mode": "pre_issuance_deep"
    }
)
result = response.json()
print(f"Verdict: {result['verdict']} (Risk: {result['risk_score']}/100)")`,
    mcp: `# 1. Install official Nexargio MCP server
pip install nexargio-mcp

# 2. Add to claude_desktop_config.json or cursor.json:
{
  "mcpServers": {
    "nexargio": {
      "command": "python",
      "args": ["-m", "nexargio_mcp"],
      "env": {
        "NEXARGIO_API_KEY": "YOUR_NEXARGIO_KEY"
      }
    }
  }
}`
  };

  const sampleJsonOutput = `{
  "status": "success",
  "url": "https://suspicious-example[.]com",
  "risk_score": 92,
  "verdict": "Hard Block",
  "risk_grade": "F",
  "latency_ms": 182,
  "classification": "Adversary-in-the-Middle (AiTM)",
  "reasons": [
    "Domain registered 14h ago via Hostinger India",
    "Pre-issuance CT log anomaly detected",
    "Obfuscated OAuth credential harvester extracted"
  ],
  "sha256_evidence": "8f4a3c9e62b10499cfad60a2b53f86e344...",
  "air_gapped_compatible": true
}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(codeSnippets[activeTab]);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <section id="developers-api" className="py-20 bg-[#0B0F19]/40 border-y border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#06B6D4]/10 border border-[#06B6D4]/20 text-[#06B6D4] text-xs font-mono-data mb-4">
            <Terminal className="w-3.5 h-3.5" />
            <span>DEVELOPERS & AI AGENTS // START FREE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight mb-4">
            Scan any URL from your terminal, your app or your AI agent. First 1,000 scans free.
          </h2>
          <p className="text-base sm:text-lg text-[#9CA3AF]">
            PIAD is open to developers and autonomous AI agents through a REST API, plain curl, and the official <code className="text-[#06B6D4] font-mono-data">nexargio-mcp</code> server for Claude Desktop, Cursor, and custom agentic frameworks. No sales call needed to start.
          </p>
        </div>

        {/* Code & JSON Output Split Box */}
        <div className="glass-panel rounded-2xl overflow-hidden border border-white/10 mb-8 grid grid-cols-1 lg:grid-cols-12 bg-[#060911]">
          
          {/* Left: Interactive Tabbed Snippets */}
          <div className="lg:col-span-7 p-6 border-b lg:border-b-0 lg:border-r border-white/10 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-1.5 p-1 bg-[#111827] rounded-lg border border-white/5">
                  <button
                    onClick={() => setActiveTab('curl')}
                    className={`px-3 py-1 text-xs font-mono-data rounded-md transition-colors ${
                      activeTab === 'curl' ? 'bg-[#3B82F6] text-white' : 'text-[#9CA3AF] hover:text-white'
                    }`}
                  >
                    cURL
                  </button>
                  <button
                    onClick={() => setActiveTab('python')}
                    className={`px-3 py-1 text-xs font-mono-data rounded-md transition-colors ${
                      activeTab === 'python' ? 'bg-[#3B82F6] text-white' : 'text-[#9CA3AF] hover:text-white'
                    }`}
                  >
                    Python SDK
                  </button>
                  <button
                    onClick={() => setActiveTab('mcp')}
                    className={`px-3 py-1 text-xs font-mono-data rounded-md transition-colors ${
                      activeTab === 'mcp' ? 'bg-[#8B5CF6] text-white' : 'text-[#9CA3AF] hover:text-white'
                    }`}
                  >
                    MCP (Claude / Cursor)
                  </button>
                </div>

                <button
                  onClick={handleCopyCode}
                  className="p-1.5 hover:bg-[#111827] text-[#9CA3AF] hover:text-white rounded-md transition-colors flex items-center gap-1 text-xs font-mono-data"
                  title="Copy code"
                >
                  {copiedCode ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" />
                      <span className="text-[#10B981]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="p-4 bg-[#0B0F19] rounded-xl border border-white/5 font-mono-data text-xs text-[#06B6D4] overflow-x-auto leading-relaxed">
                <code>{codeSnippets[activeTab]}</code>
              </pre>
            </div>

            <div className="mt-4 pt-4 border-t border-white/5 text-[11px] font-mono-data text-[#6B7280]">
              ENDPOINTS: TLS 1.3 · SUB-SECOND GLOBAL EDGE · RATE-LIMITED FOR FAIR USE
            </div>
          </div>

          {/* Right: Sample JSON Response */}
          <div className="lg:col-span-5 p-6 bg-[#0B0F19]/90 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono-data text-[#6B7280] uppercase">
                  SAMPLE VERDICT JSON
                </span>
                <span className="text-[10px] font-mono-data px-2 py-0.5 rounded bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
                  HTTP 200 OK
                </span>
              </div>

              <pre className="p-4 bg-[#060911] rounded-xl border border-white/5 font-mono-data text-xs text-[#F9FAFB] overflow-x-auto leading-relaxed">
                <code>{sampleJsonOutput}</code>
              </pre>
            </div>

            <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-xs font-mono-data">
              <span className="text-[#6B7280]">COMPUTE LATENCY:</span>
              <span className="text-[#10B981] font-semibold">182ms (Fast Path)</span>
            </div>
          </div>

        </div>

        {/* Free Tier Info Box */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-6 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#10B981]" />
              <h3 className="text-lg font-bold text-white">Free Developer Tier Available Today</h3>
            </div>
            <p className="text-xs sm:text-sm text-[#9CA3AF] max-w-2xl">
              1,000 free scans per account · Instant API key · Works seamlessly with curl, Python, Node.js and MCP agents · Rate-limited for fair use.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenApiKeyModal}
              className="px-6 py-3 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs sm:text-sm font-semibold rounded-xl shadow-[0_0_20px_rgba(59,130,246,0.35)] transition-all flex items-center gap-2"
            >
              <Key className="w-4 h-4" />
              <span>Get Free API Key</span>
            </button>
            <button
              onClick={onOpenApiKeyModal}
              className="px-5 py-3 bg-[#111827] hover:bg-[#1F2937] text-white text-xs sm:text-sm font-medium rounded-xl border border-white/10 transition-colors"
            >
              Read the Docs
            </button>
          </div>
        </div>

        {/* Bottom Enterprise Upsell (Rule 2: No prices anywhere) */}
        <div className="text-center">
          <p className="text-xs sm:text-sm text-[#9CA3AF]">
            Need more than 1,000 scans or on-premises / air-gapped sovereign deployment?{' '}
            <button
              onClick={onOpenBriefingModal}
              className="text-[#3B82F6] hover:text-[#60A5FA] font-semibold underline underline-offset-4 ml-1"
            >
              Talk to our technical architecture team
            </button>
          </p>
        </div>

      </div>
    </section>
  );
};
