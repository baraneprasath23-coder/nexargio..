import React from 'react';
import { 
  Building2, 
  Linkedin, 
  ShieldCheck, 
  Award, 
  MapPin, 
  Users, 
  Briefcase, 
  CheckCircle2, 
  Lock,
  ArrowRight
} from 'lucide-react';
import { COMPANY_DETAILS, FOUNDERS } from '../../data/content';

interface CompanyLeadershipPageProps {
  onOpenBriefingModal: () => void;
}

export const CompanyLeadershipPage: React.FC<CompanyLeadershipPageProps> = ({ onOpenBriefingModal }) => {
  return (
    <div className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Company Hero */}
      <div className="max-w-4xl mb-16">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/10 border border-[#3B82F6]/20 text-[#3B82F6] text-xs font-mono-data mb-4">
          <Building2 className="w-3.5 h-3.5" />
          <span>ABOUT NEXARGIO // SOVEREIGN CYBERSECURITY</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight mb-6">
          Architecting continuous digital trust for nations and enterprises.
        </h1>
        <p className="text-base sm:text-lg text-[#9CA3AF] leading-relaxed">
          Founded and headquartered in Hyderabad at T-Hub Phase 2, with an international corporate presence in the United Kingdom, Nexargio is pioneering zero-day pre-issuance threat intelligence and sovereign identity validation.
        </p>
      </div>

      {/* Leadership Section */}
      <div className="mb-20">
        <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-8">
          FOUNDERS & EXECUTIVE ARCHITECTURE
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {FOUNDERS.map((founder, idx) => (
            <div
              key={idx}
              className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#0B0F19] flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-14 h-14 rounded-2xl bg-[#060911] border border-white/10 flex items-center justify-center font-bold text-lg text-[#3B82F6]">
                    {founder.name.split(' ').map((n) => n[0]).join('')}
                  </div>
                  <a
                    href={founder.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-[#111827] text-[#9CA3AF] hover:text-white transition-colors"
                    title="LinkedIn"
                  >
                    <Linkedin className="w-5 h-5" />
                  </a>
                </div>

                <h3 className="text-xl font-bold text-white mb-1">{founder.name}</h3>
                <div className="text-xs font-mono-data text-[#06B6D4] mb-4">{founder.role}</div>
                <p className="text-sm text-[#9CA3AF] leading-relaxed mb-6">
                  {founder.bio}
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center gap-2 text-xs font-mono-data text-[#6B7280]">
                <MapPin className="w-3.5 h-3.5 text-[#3B82F6]" />
                <span>Hyderabad HQ · T-Hub Phase 2</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Our Manifesto: The Collapse of the Static Perimeter */}
      <div id="manifesto" className="glass-panel rounded-2xl p-6 sm:p-10 border border-white/10 bg-[#060911] mb-20">
        <span className="text-xs font-mono-data text-[#06B6D4] uppercase tracking-wider block mb-2">
          THE NEXARGIO MANIFESTO
        </span>
        <h2 className="text-2xl sm:text-3xl font-bold text-white mb-6">
          Why the Perimeter Collapsed in the Age of Autonomous AI
        </h2>
        <div className="space-y-4 text-sm text-[#9CA3AF] leading-relaxed max-w-4xl">
          <p>
            For twenty-five years, enterprise cybersecurity was built upon an implicit geographical assumption: inside the perimeter was safe; outside was hostile. We built firewalls, VPN tunnels, and periodic reputation lists to enforce this boundary.
          </p>
          <p>
            Generative AI has shattered that foundation forever. An adversary no longer needs weeks of engineering to construct credential harvesting campaigns. Autonomous models can generate pixel-perfect corporate login clones, spoof NetBanking portals, and orchestrate Adversary-in-the-Middle reverse proxy gateways in minutes.
          </p>
          <p>
            When any identity can be convincingly forged at machine speed, static blocklists are completely obsolete. The only viable defense is continuous, left-of-live validation: catching malicious infrastructure at the exact moment SSL certificates are issued, before the first phishing link is ever transmitted.
          </p>
        </div>
      </div>

      {/* Trust Center & Compliance Roadmap */}
      <div id="trust" className="glass-panel rounded-2xl p-6 sm:p-10 border border-[#10B981]/30 bg-[#0B0F19] mb-20">
        <div className="flex items-center gap-2 text-xs font-mono-data text-[#10B981] mb-4">
          <ShieldCheck className="w-4 h-4" />
          <span>SOVEREIGN DATA RESIDENCY & ASSURANCE ROADMAP</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
          Trust, Security & Regulatory Compliance
        </h2>
        <p className="text-sm text-[#9CA3AF] max-w-3xl mb-8 leading-relaxed">
          Nexargio is engineered in line with India’s Digital Personal Data Protection (DPDP) Act 2023 / Rules 2025 and CERT-In Directions 2022. We never sell customer or scan data.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono-data text-xs">
          <div className="p-4 bg-[#111827] rounded-xl border border-white/5">
            <div className="text-[#10B981] font-bold mb-2">// 01. DPDP ACT 2023 READY</div>
            <p className="text-[#9CA3AF] text-[11px] leading-relaxed">
              Designed in full alignment with India’s DPDP Act: strict data fiduciary duties, purpose limitation, notice mechanisms, and dedicated Grievance Officer.
            </p>
          </div>

          <div className="p-4 bg-[#111827] rounded-xl border border-white/5">
            <div className="text-[#3B82F6] font-bold mb-2">// 02. CERT-IN 6-HOUR LOGS</div>
            <p className="text-[#9CA3AF] text-[11px] leading-relaxed">
              Maintains secure, tamper-evident system logs in India for at least 180 days with rapid incident notification playbooks under 6 hours.
            </p>
          </div>

          <div className="p-4 bg-[#111827] rounded-xl border border-white/5">
            <div className="text-[#8B5CF6] font-bold mb-2">// 03. ASSURANCE ROADMAP</div>
            <p className="text-[#9CA3AF] text-[11px] leading-relaxed">
              ISO/IEC 27001 and SOC 2 Type II certifications on active execution roadmap with independent third-party auditor evaluations.
            </p>
          </div>
        </div>
      </div>

      {/* Careers Section */}
      <div id="careers" className="glass-panel rounded-2xl p-6 sm:p-10 border border-white/10 bg-[#060911]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-data text-[#06B6D4] mb-1">
              <Users className="w-4 h-4" />
              <span>CAREERS // 16+ GROWING TEAM</span>
            </div>
            <h2 className="text-2xl font-bold text-white">Join the Nexargio Engineering Team</h2>
          </div>
          <button
            onClick={onOpenBriefingModal}
            className="px-5 py-2.5 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-lg self-start sm:self-auto transition-colors"
          >
            Apply for Roles
          </button>
        </div>

        <p className="text-sm text-[#9CA3AF] leading-relaxed mb-6 max-w-3xl">
          We are a team of 16+ systems architects, reverse-engineers, and kernel researchers working from T-Hub Hyderabad and London. We work on low-latency V8 sandboxes, eBPF telemetry, and multimodal neural brand hashing.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono-data text-xs">
          <div className="p-4 bg-[#111827] rounded-xl border border-white/5 flex items-center justify-between">
            <div>
              <div className="text-white font-bold">Systems Architect — eBPF & Kernel Telemetry</div>
              <div className="text-[#6B7280] text-[11px]">Hyderabad HQ · Full-time</div>
            </div>
            <span className="text-[#10B981] text-[11px]">OPEN</span>
          </div>

          <div className="p-4 bg-[#111827] rounded-xl border border-white/5 flex items-center justify-between">
            <div>
              <div className="text-white font-bold">Threat Intelligence Researcher — AiTM & Phishing</div>
              <div className="text-[#6B7280] text-[11px]">Hyderabad HQ · Full-time</div>
            </div>
            <span className="text-[#10B981] text-[11px]">OPEN</span>
          </div>
        </div>
      </div>

    </div>
  );
};
