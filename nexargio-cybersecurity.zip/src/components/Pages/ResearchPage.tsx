import React, { useState } from 'react';
import { 
  FileCheck2, 
  ShieldAlert, 
  Shield, 
  ArrowRight, 
  Download, 
  Copy, 
  CheckCircle2, 
  ExternalLink,
  Award,
  Hash
} from 'lucide-react';
import { CASE_STUDIES, BENCHMARK_STATS, COMPANY_DETAILS } from '../../data/content';
import { CaseStudy } from '../../types';

interface ResearchPageProps {
  onOpenBriefingModal: () => void;
  selectedCaseStudy?: CaseStudy | null;
}

export const ResearchPage: React.FC<ResearchPageProps> = ({
  onOpenBriefingModal,
  selectedCaseStudy: propCase,
}) => {
  const [activeCase, setActiveCase] = useState<CaseStudy>(propCase || CASE_STUDIES[0]);
  const [copiedHash, setCopiedHash] = useState(false);

  const handleCopyHash = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  return (
    <div className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Research Header */}
      <div className="max-w-4xl mb-16">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/10 border border-[#3B82F6]/20 text-[#3B82F6] text-xs font-mono-data mb-4">
          <FileCheck2 className="w-3.5 h-3.5" />
          <span>RESEARCH & THREAT INTELLIGENCE LAB</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight mb-6">
          Empirical Research, Threat Dossiers & Patent Filings
        </h1>
        <p className="text-base sm:text-lg text-[#9CA3AF] leading-relaxed">
          Nexargio operates an active pre-issuance observation lab at T-Hub, Hyderabad. Our researchers track live adversary campaigns, analyze evasive Adversary-in-the-Middle (AiTM) kits, and publish peer-verifiable benchmarks.
        </p>
      </div>

      {/* Active Case Study Spotlight */}
      <div className="mb-20">
        <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-6">
          FEATURED THREAT DOSSIER // TLP:CLEAR
        </div>

        {/* Case Selector Tabs */}
        <div className="flex flex-wrap items-center gap-2 mb-6">
          {CASE_STUDIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCase(c)}
              className={`px-4 py-2 text-xs font-mono-data rounded-xl border transition-colors ${
                activeCase.id === c.id
                  ? 'bg-[#111827] text-white border-[#3B82F6]'
                  : 'bg-[#0B0F19] text-[#9CA3AF] border-white/5 hover:border-white/20'
              }`}
            >
              {c.defangedUrl} (Risk: {c.riskScore})
            </button>
          ))}
        </div>

        {/* Detailed Case Dossier Box */}
        <div className="glass-panel rounded-2xl p-6 sm:p-10 border border-white/10 bg-[#0B0F19]">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/10 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-mono-data text-[#EF4444] font-bold">
                  DEFANGED URL: {activeCase.defangedUrl}
                </span>
                <span className="text-white/20">·</span>
                <span className="text-xs font-mono-data text-[#06B6D4]">{activeCase.timeToFlag}</span>
              </div>
              <h2 className="text-2xl font-bold text-white">{activeCase.title}</h2>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-lg text-sm font-bold font-mono-data bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30">
                RISK {activeCase.riskScore}/100
              </span>
              <span className="px-3 py-1 rounded-lg text-xs font-mono-data bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
                {activeCase.status}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
            <div className="lg:col-span-7 space-y-4 text-sm text-[#9CA3AF] leading-relaxed">
              <h3 className="text-base font-bold text-white">Executive Incident Summary</h3>
              <p>{activeCase.summary}</p>
              
              <h3 className="text-base font-bold text-white pt-2">Forensic Analysis & Vision Adjudication</h3>
              <p>{activeCase.evidenceNotes}</p>

              <div className="p-4 rounded-xl bg-[#060911] border border-white/5 text-xs font-mono-data text-[#6B7280]">
                <span className="text-[#F9FAFB] block mb-1">Legacy Commercial Gateways Telemetry:</span>
                {activeCase.publicScannersStatus}
              </div>
            </div>

            {/* Indicators Table (domain, IP, registrar, attack vector) */}
            <div className="lg:col-span-5 bg-[#060911] rounded-xl p-6 border border-white/5 font-mono-data text-xs space-y-3">
              <div className="text-[#6B7280] text-[10px] uppercase font-bold tracking-wider mb-2">
                CRYPTOGRAPHIC INDICATORS OF COMPROMISE (IOC)
              </div>

              <div className="space-y-2">
                <div className="p-2.5 bg-[#111827] rounded flex justify-between">
                  <span className="text-[#6B7280]">DEFANGED DOMAIN:</span>
                  <span className="text-[#EF4444] font-semibold">{activeCase.defangedUrl}</span>
                </div>
                <div className="p-2.5 bg-[#111827] rounded flex justify-between">
                  <span className="text-[#6B7280]">HOSTING ASN / IP:</span>
                  <span className="text-white">{activeCase.indicators.ip}</span>
                </div>
                <div className="p-2.5 bg-[#111827] rounded flex justify-between">
                  <span className="text-[#6B7280]">REGISTRAR:</span>
                  <span className="text-white">{activeCase.indicators.registrar}</span>
                </div>
                <div className="p-2.5 bg-[#111827] rounded flex justify-between">
                  <span className="text-[#6B7280]">CERTIFICATE CREATED:</span>
                  <span className="text-[#06B6D4]">{activeCase.indicators.certDate}</span>
                </div>
                <div className="p-2.5 bg-[#111827] rounded flex flex-col gap-1">
                  <span className="text-[#6B7280]">ATTACK VECTOR:</span>
                  <span className="text-[#F9FAFB] font-medium">{activeCase.indicators.attackVector}</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => handleCopyHash(activeCase.indicators.ip + ' ' + activeCase.defangedUrl)}
                  className="w-full py-2 bg-[#1F2937] hover:bg-[#374151] text-[#9CA3AF] hover:text-white rounded text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  {copiedHash ? <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedHash ? 'Indicators Copied' : 'Copy IOC Package'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Patent & IP Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-20">
        
        {/* Patent Filing Details */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#0B0F19]">
          <div className="flex items-center gap-2 text-xs font-mono-data text-[#06B6D4] mb-4">
            <Shield className="w-4 h-4" />
            <span>INDIAN PATENT OFFICE FILING</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">
            Patent Application {COMPANY_DETAILS.patentAppNumber}
          </h3>
          <div className="text-xs font-mono-data text-[#6B7280] mb-4">
            Filing Ref: {COMPANY_DETAILS.patentPending}
          </div>
          <p className="text-sm text-[#9CA3AF] leading-relaxed mb-6">
            <strong>Invention:</strong> “Systems and Methods for Multi-Layered Recursive Normalization and Adversarial Behavioural Analysis for Evasive Web Threat Adjudication.” Covers our tiered microsecond pipeline combining sub-second lexical entropy, headless DOM trapping, and perceptual neural vision hashing.
          </p>

          <div className="p-4 rounded-xl bg-[#111827] border border-white/5 text-xs text-[#F9FAFB] space-y-2">
            <div className="font-semibold text-[#06B6D4]">// CLAIMS HIGHLIGHT:</div>
            <div>• Zero-day pre-issuance certificate monitoring with sub-5s adjudication latency.</div>
            <div>• Adversary-in-the-Middle reverse proxy fingerprinting via V8 session analysis.</div>
          </div>
        </div>

        {/* Technical Benchmark Report v1.0.0 */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#0B0F19] flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-data text-[#3B82F6] mb-4">
              <Award className="w-4 h-4" />
              <span>EMPIRICAL BENCHMARK STUDY</span>
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">
              Technical Benchmark Report v1.0.0
            </h3>
            <p className="text-sm text-[#9CA3AF] leading-relaxed mb-6">
              A peer-reproducible evaluation of 10,000 live phishing URLs collected from PhishTank, OpenPhish, and proprietary pre-issuance honeypots. Evaluates detection recall against 90 commercial scanning gateways.
            </p>

            <div className="grid grid-cols-2 gap-3 mb-6 font-mono-data text-xs">
              <div className="p-3 bg-[#111827] rounded-lg">
                <div className="text-[#6B7280] text-[10px]">RECALL RATE</div>
                <div className="text-lg font-bold text-[#10B981]">98.11%</div>
              </div>
              <div className="p-3 bg-[#111827] rounded-lg">
                <div className="text-[#6B7280] text-[10px]">FALSE POSITIVES</div>
                <div className="text-lg font-bold text-white">0.00%</div>
              </div>
            </div>
          </div>

          <button
            onClick={onOpenBriefingModal}
            className="w-full py-3 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-all shadow"
          >
            <Download className="w-4 h-4" />
            <span>Request Full PDF Benchmark Report</span>
          </button>
        </div>

      </div>

    </div>
  );
};
