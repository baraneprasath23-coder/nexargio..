import React, { useState } from 'react';
import { ShieldCheck, Mail, CheckCircle2, Lock, FileText, AlertCircle } from 'lucide-react';
import { COMPANY_DETAILS } from '../../data/content';
import { PageView } from '../../types';

interface LegalPageProps {
  initialTab?: string;
}

export const LegalPage: React.FC<LegalPageProps> = ({ initialTab = 'privacy' }) => {
  const [activeTab, setActiveTab] = useState(initialTab);

  // Data Rights Request Form State
  const [dataRequest, setDataRequest] = useState({
    name: '',
    email: '',
    requestType: 'Access / Export personal data',
    details: '',
    submitted: false
  });

  const handleDataRequestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDataRequest({ ...dataRequest, submitted: true });
  };

  return (
    <div className="py-12 sm:py-16 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
      
      {/* Legal Section Nav Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-10 p-1.5 bg-[#0B0F19] rounded-xl border border-white/10 w-fit">
        <button
          onClick={() => setActiveTab('privacy')}
          className={`px-3.5 py-1.5 text-xs font-mono-data rounded-lg transition-colors ${
            activeTab === 'privacy' ? 'bg-[#3B82F6] text-white' : 'text-[#9CA3AF] hover:text-white'
          }`}
        >
          Privacy Policy
        </button>
        <button
          onClick={() => setActiveTab('terms')}
          className={`px-3.5 py-1.5 text-xs font-mono-data rounded-lg transition-colors ${
            activeTab === 'terms' ? 'bg-[#3B82F6] text-white' : 'text-[#9CA3AF] hover:text-white'
          }`}
        >
          Terms of Service & API
        </button>
        <button
          onClick={() => setActiveTab('disclosure')}
          className={`px-3.5 py-1.5 text-xs font-mono-data rounded-lg transition-colors ${
            activeTab === 'disclosure' ? 'bg-[#3B82F6] text-white' : 'text-[#9CA3AF] hover:text-white'
          }`}
        >
          Responsible Disclosure
        </button>
        <button
          onClick={() => setActiveTab('trademarks')}
          className={`px-3.5 py-1.5 text-xs font-mono-data rounded-lg transition-colors ${
            activeTab === 'trademarks' ? 'bg-[#3B82F6] text-white' : 'text-[#9CA3AF] hover:text-white'
          }`}
        >
          Trademarks & IP
        </button>
        <button
          onClick={() => setActiveTab('request')}
          className={`px-3.5 py-1.5 text-xs font-mono-data rounded-lg transition-colors ${
            activeTab === 'request' ? 'bg-[#06B6D4] text-white' : 'text-[#9CA3AF] hover:text-white'
          }`}
        >
          Data Rights Request (/privacy/request)
        </button>
      </div>

      {/* 1. PRIVACY POLICY */}
      {activeTab === 'privacy' && (
        <div className="glass-panel rounded-2xl p-6 sm:p-10 border border-white/10 bg-[#0B0F19] space-y-6 text-sm text-[#9CA3AF] leading-relaxed">
          <div className="border-b border-white/10 pb-4 mb-6">
            <span className="text-xs font-mono-data text-[#06B6D4] uppercase">LAST UPDATED: OCTOBER 2026</span>
            <h1 className="text-3xl font-bold text-white mt-1">Privacy Policy</h1>
            <p className="text-xs text-[#6B7280] font-mono-data mt-1">
              Compliant with India DPDP Act 2023 / DPDP Rules 2025, IT Act 2000, and UK GDPR.
            </p>
          </div>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">1. Who We Are (Data Fiduciary / Controller)</h2>
            <p>
              This Privacy Policy explains how <strong>{COMPANY_DETAILS.legalName}</strong> (CIN {COMPANY_DETAILS.cin}), with registered office at T-Hub Phase 2, Madhapur, Hyderabad, Telangana, India, acts as the primary Data Fiduciary and Controller for all scanning, API, and web services.
            </p>
            <p>
              Our affiliated group entity, <strong>{COMPANY_DETAILS.ukEntity.name}</strong> (Company No. {COMPANY_DETAILS.ukEntity.companyNumber}, registered in {COMPANY_DETAILS.ukEntity.jurisdiction}), represents our corporate presence in the United Kingdom.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">2. What Data We Collect & URL Privacy Minimization</h2>
            <p>
              We collect: (a) Form contact information (name, work email, organization, role); (b) Account and API key telemetry (scan volume and quota usage); (c) Submitted scan data (URLs, domains, and QR-code payloads fetched by our crawler); and (d) Technical log data (IP address, user-agent, timestamp).
            </p>
            <div className="p-4 rounded-xl bg-[#060911] border border-white/5 text-xs text-[#F9FAFB] space-y-1">
              <strong className="text-[#3B82F6] block">Personal Data in Submitted URLs:</strong>
              We recognize that submitted phishing URLs may occasionally contain encoded employee email addresses or session identifiers. We strictly minimize this data: query strings containing personal information are sanitized, screenshot evidence is redacted prior to public research publication, and access is restricted to verified security analysts.
            </div>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">3. Lawful Basis & Purposes of Processing</h2>
            <p>
              We process personal data under applicable Indian (DPDP Act) and UK GDPR lawful bases:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-xs">
              <li><strong>Inquiries & Briefings:</strong> Legitimate interest in responding to enterprise evaluation requests.</li>
              <li><strong>API & Platform Delivery:</strong> Performance of contract (terms of service).</li>
              <li><strong>Threat Research & Defanged Publications:</strong> Legitimate interest in collective cybersecurity resilience.</li>
              <li><strong>CERT-In Compliance & Log Preservation:</strong> Legal obligation under Indian CERT-In Directions 2022 (preserving system logs for 180 days in India).</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">4. Artificial Intelligence & Sub-Processors</h2>
            <p>
              Cloud deployments of PIAD may utilize Google Gemini multimodal models to perform layout and visual brand comparison. In sovereign and on-premises deployments, all reasoning runs on local, air-gapped models with zero telemetry leaving the enclave.
            </p>
            <p>
              We never sell or monetize your data. Data is shared only with verified technical sub-processors (Google Cloud Platform, transactional email infrastructure) or regulatory authorities (CERT-In) when legally compelled.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">5. Data Retention Schedule</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono-data text-xs border border-white/10">
                <thead className="bg-[#111827] text-white">
                  <tr>
                    <th className="p-2.5">Category</th>
                    <th className="p-2.5">Retention Duration</th>
                    <th className="p-2.5">Purpose / Legal Requirement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  <tr>
                    <td className="p-2.5">Executive Enquiries</td>
                    <td className="p-2.5">24 months</td>
                    <td className="p-2.5">Customer relationship management</td>
                  </tr>
                  <tr>
                    <td className="p-2.5">API Account Records</td>
                    <td className="p-2.5">Account Life + 12 months</td>
                    <td className="p-2.5">Audit trail and contractual compliance</td>
                  </tr>
                  <tr>
                    <td className="p-2.5">System & Security Logs</td>
                    <td className="p-2.5">Minimum 180 days</td>
                    <td className="p-2.5">Mandatory under CERT-In Directions 2022</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section id="grievance" className="p-5 rounded-xl bg-[#111827] border border-[#3B82F6]/30 space-y-2">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#3B82F6]" />
              <span>6. Grievance Officer & Data Protection Contact</span>
            </h2>
            <p className="text-xs">
              In accordance with the India DPDP Act 2023, IT Act 2000, and UK GDPR, you may submit data access, correction, erasure requests, or grievances directly to our designated Grievance Officer:
            </p>
            <div className="font-mono-data text-xs text-[#F9FAFB] space-y-0.5 pt-1">
              <div><strong>Officer:</strong> {COMPANY_DETAILS.grievanceOfficer.name}</div>
              <div><strong>Email:</strong> {COMPANY_DETAILS.grievanceOfficer.email}</div>
              <div><strong>Address:</strong> {COMPANY_DETAILS.grievanceOfficer.address}</div>
              <div className="text-[#10B981]"><strong>Response Timeline:</strong> Within 30 calendar days of receipt.</div>
            </div>
          </section>
        </div>
      )}

      {/* 2. TERMS OF SERVICE & API */}
      {activeTab === 'terms' && (
        <div className="glass-panel rounded-2xl p-6 sm:p-10 border border-white/10 bg-[#0B0F19] space-y-6 text-sm text-[#9CA3AF] leading-relaxed">
          <div className="border-b border-white/10 pb-4 mb-6">
            <span className="text-xs font-mono-data text-[#06B6D4] uppercase">LAST UPDATED: OCTOBER 2026</span>
            <h1 className="text-3xl font-bold text-white mt-1">Website & API Terms of Service</h1>
          </div>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">1. Contracting Entity</h2>
            <p>
              All customer relationships, API licenses, and subscriptions are contracted solely with <strong>{COMPANY_DETAILS.legalName}</strong> (India). Nexargio UK Ltd is presented for UK territorial representation and does not sign customer contracts or collect payments.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">2. Free Developer Tier & Quota Limits</h2>
            <p>
              Nexargio offers an exploratory developer tier consisting of 1,000 free scans per verified account. API keys must remain strictly confidential. One free tier account is permitted per organization. We reserve the right to revoke keys involved in abuse or load-testing attacks.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">3. Acceptable Use Policy</h2>
            <p>You agree not to:</p>
            <ul className="list-disc pl-5 space-y-1 text-xs">
              <li>Use PIAD to scan, probe, or launch hostile attacks against systems you do not own or hold explicit written authorization to assess.</li>
              <li>Conduct distributed denial of service (DDoS) testing or attempt to bypass API quota rate limits.</li>
              <li>Resell, sublicense, or white-label threat verdicts without an active commercial partner license agreement.</li>
              <li>Reverse engineer or scrape PIAD outputs to train competing neural detection datasets.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">4. Advisory Nature of Verdicts & Liability Cap</h2>
            <p>
              In cybersecurity, no threat detection platform can guarantee 100% detection of every future threat variant. PIAD verdicts and risk scores are advisory telemetry to aid security analysts. You remain responsible for your final operational containment and firewall policies.
            </p>
            <p>
              To the maximum extent permitted by applicable law, Nexargio Private Limited disclaims liability for indirect, special, or consequential damages.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-white">5. Governing Law & Jurisdiction</h2>
            <p>
              These Terms and any dispute arising out of or related to our platform shall be governed exclusively by the laws of India, with exclusive jurisdiction resting in the competent courts located at <strong>Hyderabad, Telangana, India</strong>.
            </p>
          </section>
        </div>
      )}

      {/* 3. RESPONSIBLE DISCLOSURE */}
      {activeTab === 'disclosure' && (
        <div className="glass-panel rounded-2xl p-6 sm:p-10 border border-white/10 bg-[#0B0F19] space-y-6 text-sm text-[#9CA3AF] leading-relaxed">
          <div className="border-b border-white/10 pb-4 mb-6">
            <span className="text-xs font-mono-data text-[#10B981] uppercase">SECURITY CONTACT & POLICY</span>
            <h1 className="text-3xl font-bold text-white mt-1">Responsible Disclosure Policy</h1>
          </div>

          <p>
            At Nexargio, security is our foundational conviction. If you believe you have identified a vulnerability within any Nexargio infrastructure or API endpoint, we encourage prompt and responsible disclosure.
          </p>

          <div className="p-4 rounded-xl bg-[#111827] border border-white/5 space-y-2 text-xs font-mono-data">
            <div className="text-white font-bold">// HOW TO REPORT:</div>
            <div>• Send your encrypted report to: <strong>security@nexargio.com</strong> or <strong>info@nexargio.com</strong></div>
            <div>• Include reproducible proof of concept steps, target URLs, and payload details.</div>
            <div>• Allow our engineering team at least 5 business days to validate and remediate before public discussion.</div>
          </div>
        </div>
      )}

      {/* 4. TRADEMARKS & IP */}
      {activeTab === 'trademarks' && (
        <div className="glass-panel rounded-2xl p-6 sm:p-10 border border-white/10 bg-[#0B0F19] space-y-6 text-sm text-[#9CA3AF] leading-relaxed">
          <div className="border-b border-white/10 pb-4 mb-6">
            <span className="text-xs font-mono-data text-[#8B5CF6] uppercase">INTELLECTUAL PROPERTY & THIRD-PARTY BRANDS</span>
            <h1 className="text-3xl font-bold text-white mt-1">Trademarks & Third-Party Brand Notice</h1>
          </div>

          <p>
            “Nexargio”, “PIAD”, “VASS-Onyx”, “Vigilance-X”, and “Trust, continuously validated” are trademarks or service marks of Nexargio Private Limited.
          </p>

          <div className="p-5 rounded-xl bg-[#060911] border border-white/5 text-xs text-[#9CA3AF] space-y-2">
            <strong className="text-white block">Third-Party Trademarks Mentioned in Incident Reports:</strong>
            <p>
              Brand names referenced across our research dossiers (such as OpenAI, Apple, State Bank of India, HDFC Bank, ICICI Bank, Paytm, Trezor, Cloudflare, etc.) are registered trademarks of their respective owners.
            </p>
            <p>
              These names are referenced strictly as plain text for factual technical incident identification and forensic reporting. No commercial affiliation, sponsorship, endorsement, or client partnership is implied.
            </p>
          </div>
        </div>
      )}

      {/* 5. DATA RIGHTS REQUEST FORM (/privacy/request) */}
      {activeTab === 'request' && (
        <div className="glass-panel rounded-2xl p-6 sm:p-10 border border-[#06B6D4]/30 bg-[#0B0F19] text-left">
          <div className="border-b border-white/10 pb-4 mb-6">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono-data text-[#06B6D4]">TAG: [PRIVACY]</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white">Exercise Your Data Rights</h1>
            <p className="text-xs text-[#9CA3AF] mt-1">
              Submit access, correction, erasure, or consent withdrawal requests under India’s DPDP Act 2023 or UK GDPR.
            </p>
          </div>

          {!dataRequest.submitted ? (
            <form onSubmit={handleDataRequestSubmit} className="space-y-4 text-xs font-mono-data">
              <div>
                <label className="text-[#9CA3AF] block mb-1">FULL LEGAL NAME *</label>
                <input
                  type="text"
                  required
                  value={dataRequest.name}
                  onChange={(e) => setDataRequest({ ...dataRequest, name: e.target.value })}
                  placeholder="Your Full Name"
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#06B6D4] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">ASSOCIATED WORK EMAIL *</label>
                <input
                  type="email"
                  required
                  value={dataRequest.email}
                  onChange={(e) => setDataRequest({ ...dataRequest, email: e.target.value })}
                  placeholder="your.email@domain.com"
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#06B6D4] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">REQUEST TYPE *</label>
                <select
                  value={dataRequest.requestType}
                  onChange={(e) => setDataRequest({ ...dataRequest, requestType: e.target.value })}
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#06B6D4] focus:outline-none"
                >
                  <option value="Access / Export personal data">Access & Export Personal Data (India DPDP / UK GDPR)</option>
                  <option value="Correction / Rectification">Correction / Rectification of Outdated Records</option>
                  <option value="Erasure / Deletion">Erasure & Account Deletion</option>
                  <option value="Nominate Representative">Nominate a Representative (India DPDP Act)</option>
                  <option value="Grievance Redressal">Submit Grievance to Grievance Officer</option>
                </select>
              </div>

              <div>
                <label className="text-[#9CA3AF] block mb-1">ADDITIONAL DETAILS</label>
                <textarea
                  rows={3}
                  value={dataRequest.details}
                  onChange={(e) => setDataRequest({ ...dataRequest, details: e.target.value })}
                  placeholder="Provide context regarding the specific API keys, email correspondence, or scan data involved..."
                  className="w-full p-2.5 bg-[#060911] border border-white/10 rounded-lg text-white focus:border-[#06B6D4] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#06B6D4] hover:bg-[#0891B2] text-white font-semibold rounded-xl transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)]"
              >
                Submit Formal Data Rights Request
              </button>
            </form>
          ) : (
            <div className="text-center py-8">
              <div className="w-12 h-12 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center mx-auto mb-4 border border-[#10B981]/30">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Request Logged with Grievance Office</h4>
              <p className="text-xs text-[#9CA3AF] max-w-sm mx-auto mb-6">
                Your request has been tagged as <strong>[PRIVACY]</strong> and routed to our Grievance Officer at <strong>{COMPANY_DETAILS.grievanceOfficer.email}</strong>. In accordance with the DPDP Act, we will verify your identity and fulfill your request within 30 days.
              </p>
              <button
                onClick={() => setDataRequest({ ...dataRequest, submitted: false })}
                className="px-6 py-2.5 bg-[#111827] text-white text-xs font-semibold rounded-lg border border-white/10 hover:bg-[#1F2937]"
              >
                Submit Another Request
              </button>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
