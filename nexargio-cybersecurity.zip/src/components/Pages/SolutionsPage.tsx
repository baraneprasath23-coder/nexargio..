import React, { useState } from 'react';
import { 
  Landmark, 
  ShieldCheck, 
  Coins, 
  Network, 
  Building2, 
  ArrowRight, 
  AlertTriangle, 
  CheckCircle2, 
  FileText 
} from 'lucide-react';
import { SolutionSector, CaseStudy } from '../../types';
import { CASE_STUDIES } from '../../data/content';

interface SolutionsPageProps {
  initialSector?: SolutionSector;
  onOpenBriefingModal: (interest?: string) => void;
  onSelectCase: (caseItem: CaseStudy) => void;
}

export const SolutionsPage: React.FC<SolutionsPageProps> = ({
  initialSector = 'banking',
  onOpenBriefingModal,
  onSelectCase,
}) => {
  const [selectedSector, setSelectedSector] = useState<SolutionSector>(initialSector);

  const sectorData: Record<
    SolutionSector,
    {
      title: string;
      heroEyebrow: string;
      headline: string;
      sub: string;
      problems: string[];
      nexargioSolution: string[];
      caseId: string;
    }
  > = {
    banking: {
      title: 'Banking & FinTech',
      heroEyebrow: 'FINANCIAL SECTOR RESILIENCE',
      headline: 'Neutralize UPI collect traps & fake net banking clones left-of-live.',
      sub: 'Fraud rings exploit instant messaging to blitz consumers with lookalike PAN/KYC expiration alerts. Traditional threat lists take up to 24 hours to flag domains, by which time thousands of net banking sessions and UPI PINs are compromised.',
      problems: [
        'Adversaries register typosquat domains (e.g. hdfc-kyc-verify[.]org) and launch bulk SMS blasts within 3 hours.',
        'Dynamic UPI collect intents and forged QR codes siphon funds directly past traditional transactional velocity checks.',
        'Legacy threat feeds miss newly registered domains during the golden 2-to-3 hour attack lifecycle.'
      ],
      nexargioSolution: [
        'PIAD monitors Certificate Transparency logs in real-time, catching banking lookalikes under 5 seconds from cert generation.',
        'Multimodal vision AI flags visual mimicry of official net banking login forms, RBI disclaimers, and payment portals.',
        'Generates SHA-256 hashed evidence packages ready for immediate CERT-In incident reporting and registrar suspension.'
      ],
      caseId: 'paytm-gaming'
    },
    government: {
      title: 'Government & Critical Infrastructure',
      heroEyebrow: 'NATIONAL SOVEREIGN CYBER IMMUNITY',
      headline: 'Air-gapped threat intelligence engineered for high-consequence national infrastructure.',
      sub: 'Ports, power grids, civil aviation, and defense command networks require threat detection that guarantees zero foreign cloud dependencies and complete sovereign data residency.',
      problems: [
        'State-sponsored spear-phishing campaigns target operational technology (OT) engineers and port logistics portals.',
        'Foreign cloud-based scanning services introduce critical data sovereignty and supply chain exposure risks.',
        'Legacy air-gapped enclaves suffer from stale threat signatures due to infrequent manual offline feed updates.'
      ],
      nexargioSolution: [
        'Full air-gapped deployment mode operating entirely on domestic sovereign GPU enclaves with local quantized LLMs.',
        'Continuous deterministic lexical and structural evaluation without leaking telemetry to foreign providers.',
        'Strictly designed to meet India DPDP Act and national CERT-In 6-hour mandatory cyber incident reporting timelines.'
      ],
      caseId: 'indian-banking'
    },
    'crypto-web3': {
      title: 'Crypto & Web3 Brands',
      heroEyebrow: 'DECENTRALIZED ASSET PROTECTION',
      headline: 'Uncover automated wallet drainers & fake dApp clones before token holders sign.',
      sub: 'Crypto protocols face industrial-scale typosquatting and fake swap frontends designed to drain wallets via malicious Permit2 approvals and compromised smart contract interactions.',
      problems: [
        'Malicious dApp frontends replicate authentic Web3 brands with pixel-perfect visual styling hosted on IPFS/Cloudflare Pages.',
        'Victim private keys and seed phrases are exfiltrated through disguised wallet-connect modals.',
        'Decentralized threat actors rotate through dozens of lookalike domains every week, evading static blocklists.'
      ],
      nexargioSolution: [
        'Visual hash similarity models identify unauthorized brand mimicry of prominent protocols and wallet providers.',
        'DOM analysis inspects wallet interaction scripts and flags unauthorized spender approval requests.',
        'Provides real-time API feeds for Web3 browser extensions and RPC nodes to block malicious domain resolution.'
      ],
      caseId: 'openai-collab'
    },
    'enterprise-soc': {
      title: 'Enterprise SOCs & CISOs',
      heroEyebrow: 'SOC ACCELERATION & AITM DEFENSE',
      headline: 'Stop Adversary-in-the-Middle credential theft with explainable verdicts analysts trust.',
      sub: 'Modern reverse-proxy kits (Evilginx, Muraena) proxy real corporate SSO sessions, stealing active authentication cookies and bypassing hardware MFA without generating SIEM alerts.',
      problems: [
        'Traditional email gateways pass AiTM links because the landing domain is fresh and unlisted on public blacklists.',
        'Security analysts waste hundreds of hours manually sandboxing suspicious URLs submitted by employees.',
        'Generic scanners return opaque "suspicious" ratings without explainable forensic artifacts for triage.'
      ],
      nexargioSolution: [
        'Pre-issuance CT log intelligence identifies reverse proxy certificates minutes after adversary provisioning.',
        'Detailed explainability traces explain exactly which form traps, reverse proxy headers, and DOM anomalies triggered the block.',
        'Automated webhook triggers push instantaneous block rules to Splunk, Microsoft Sentinel, and egress firewalls.'
      ],
      caseId: 'openai-collab'
    },
    mssp: {
      title: 'MSSPs & MDR Providers',
      heroEyebrow: 'MANAGED SECURITY SERVICE PROVIDERS',
      headline: 'Add evasive-URL investigation to your SOC and resell explainable phishing verdicts.',
      sub: 'MSSPs and MDR providers must protect thousands of distinct enterprise customer domains while keeping analyst overhead sustainable and margins predictable.',
      problems: [
        'Clients demand proactive brand impersonation monitoring, but manual domain investigations do not scale.',
        'False positives generated by crude heuristics damage client trust and trigger alert fatigue.',
        'Commercial threat feeds are expensive, opaque, and offer no white-label evidence reporting.'
      ],
      nexargioSolution: [
        'Multi-tenant API architecture allowing MSSPs to provision isolated customer workspaces with custom rate limits.',
        'Comprehensive white-label brand impersonation dossiers with client logos and cryptographically attested findings.',
        'Dedicated partner pilot programme offering 300–500 live URL evaluations across a 3–4 week onboarding window.'
      ],
      caseId: 'paytm-gaming'
    }
  };

  const current = sectorData[selectedSector];
  const relatedCase = CASE_STUDIES.find((c) => c.id === current.caseId) || CASE_STUDIES[0];

  return (
    <div className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Sector Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-12 p-1.5 bg-[#0B0F19] rounded-xl border border-white/10 w-fit">
        {(Object.keys(sectorData) as SolutionSector[]).map((key) => (
          <button
            key={key}
            onClick={() => setSelectedSector(key)}
            className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors ${
              selectedSector === key
                ? 'bg-[#3B82F6] text-white shadow'
                : 'text-[#9CA3AF] hover:text-white hover:bg-white/5'
            }`}
          >
            {sectorData[key].title}
          </button>
        ))}
      </div>

      {/* Sector Hero */}
      <div className="max-w-4xl mb-16">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/10 border border-[#3B82F6]/20 text-[#3B82F6] text-xs font-mono-data mb-4">
          <span className="w-2 h-2 rounded-full bg-[#06B6D4]" />
          <span>{current.heroEyebrow}</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-6">
          {current.headline}
        </h1>
        <p className="text-base sm:text-lg text-[#9CA3AF] leading-relaxed">
          {current.sub}
        </p>
      </div>

      {/* Problem vs. Nexargio Solution Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
        
        {/* The Sector Threat Reality */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-[#EF4444]/20 bg-[#060911]">
          <div className="flex items-center gap-2 text-xs font-mono-data text-[#EF4444] uppercase tracking-wider mb-6">
            <AlertTriangle className="w-4 h-4" />
            <span>THE CHALLENGE IN THIS SECTOR</span>
          </div>

          <div className="space-y-4">
            {current.problems.map((prob, i) => (
              <div key={i} className="flex items-start gap-3 p-3.5 bg-[#111827] rounded-xl border border-white/5">
                <span className="text-[#EF4444] font-mono-data font-bold text-xs">0{i + 1}.</span>
                <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed">{prob}</p>
              </div>
            ))}
          </div>
        </div>

        {/* How Nexargio Solves It */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-[#3B82F6]/30 bg-[#0B0F19]">
          <div className="flex items-center gap-2 text-xs font-mono-data text-[#10B981] uppercase tracking-wider mb-6">
            <CheckCircle2 className="w-4 h-4" />
            <span>HOW NEXARGIO FITS</span>
          </div>

          <div className="space-y-4">
            {current.nexargioSolution.map((sol, i) => (
              <div key={i} className="flex items-start gap-3 p-3.5 bg-[#111827] rounded-xl border border-white/5">
                <span className="text-[#3B82F6] font-mono-data font-bold text-xs">0{i + 1}.</span>
                <p className="text-xs sm:text-sm text-[#F9FAFB] leading-relaxed">{sol}</p>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Relevant Case Dossier Feature */}
      <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 mb-16 bg-[#060911]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <span className="text-xs font-mono-data text-[#06B6D4] uppercase">PROVEN SECTOR EVIDENCE</span>
            <h3 className="text-xl font-bold text-white mt-1">Real Threat Interception Dossier</h3>
          </div>
          <button
            onClick={() => onSelectCase(relatedCase)}
            className="text-xs font-semibold text-[#3B82F6] hover:underline flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Read full forensic case writeup</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="p-4 bg-[#111827] rounded-xl border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono-data text-[#EF4444] font-bold">
                DEFANGED: {relatedCase.defangedUrl}
              </span>
              <span className="text-xs font-mono-data px-2 py-0.5 rounded bg-[#EF4444]/15 text-[#EF4444]">
                RISK {relatedCase.riskScore}/100
              </span>
            </div>
            <h4 className="text-base font-bold text-white mb-1">{relatedCase.title}</h4>
            <p className="text-xs text-[#9CA3AF] max-w-2xl">{relatedCase.summary}</p>
          </div>
          <button
            onClick={() => onSelectCase(relatedCase)}
            className="px-4 py-2 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-lg shrink-0"
          >
            Inspect Evidence
          </button>
        </div>
      </div>

      {/* CTA Band */}
      <div className="p-8 rounded-2xl bg-gradient-to-r from-[#111827] to-[#0B0F19] border border-[#3B82F6]/30 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-xl font-bold text-white mb-1">Schedule a {current.title} Threat Briefing</h3>
          <p className="text-xs text-[#9CA3AF]">
            Evaluate live telemetry and review our custom sector deployment blueprint with our lead architects.
          </p>
        </div>
        <button
          onClick={() => onOpenBriefingModal(current.title)}
          className="px-6 py-3 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs sm:text-sm font-semibold rounded-xl shadow transition-all shrink-0"
        >
          Book Sector Briefing
        </button>
      </div>

    </div>
  );
};
