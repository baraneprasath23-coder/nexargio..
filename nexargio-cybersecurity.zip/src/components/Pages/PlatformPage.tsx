import React from 'react';
import { 
  ShieldCheck, 
  Cpu, 
  Layers, 
  Zap, 
  FileCheck2, 
  Lock, 
  Terminal, 
  ArrowRight,
  Database,
  Eye,
  Server
} from 'lucide-react';
import { COMPANY_DETAILS, BENCHMARK_STATS } from '../../data/content';

interface PlatformPageProps {
  onOpenBriefingModal: () => void;
  onOpenApiKeyModal: () => void;
  onOpenChecker: () => void;
}

export const PlatformPage: React.FC<PlatformPageProps> = ({
  onOpenBriefingModal,
  onOpenApiKeyModal,
  onOpenChecker,
}) => {
  return (
    <div className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Product Hero */}
      <div className="max-w-4xl mb-16">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#10B981]/10 border border-[#10B981]/20 text-[#10B981] text-xs font-mono-data mb-4">
          <span className="w-2 h-2 rounded-full bg-[#10B981]" />
          <span>PRODUCTION PLATFORM // PIAD v4.0 LIVE</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight mb-6">
          Pre-Issuance Attack Detection (PIAD v4.0)
        </h1>
        <p className="text-lg text-[#9CA3AF] leading-relaxed mb-8">
          The industry’s first left-of-live interception engine. By continuously monitoring global Certificate Transparency (CT) logs and analyzing newly minted SSL/TLS certificates under 5 seconds from broadcast, PIAD catches zero-day phishing infrastructure and AiTM proxy kits before victim campaigns are dispatched.
        </p>

        <div className="flex flex-wrap items-center gap-4">
          <button
            onClick={onOpenBriefingModal}
            className="px-6 py-3.5 bg-[#3B82F6] hover:bg-[#2563EB] text-white font-semibold text-sm rounded-xl shadow-[0_0_20px_rgba(59,130,246,0.35)] transition-all"
          >
            Schedule Technical Briefing
          </button>
          <button
            onClick={onOpenApiKeyModal}
            className="px-6 py-3.5 bg-[#111827] hover:bg-[#1F2937] text-white border border-white/10 text-sm font-medium rounded-xl transition-colors flex items-center gap-2"
          >
            <Terminal className="w-4 h-4 text-[#06B6D4]" />
            <span>Get Free API Key (1,000 Scans)</span>
          </button>
          <button
            onClick={onOpenChecker}
            className="px-6 py-3.5 bg-transparent hover:bg-white/5 text-[#06B6D4] border border-[#06B6D4]/30 text-sm font-semibold rounded-xl transition-colors"
          >
            Launch URL Checker
          </button>
        </div>
      </div>

      {/* 4 Core Architectural Capabilities */}
      <div className="mb-20">
        <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-6">
          CORE CAPABILITY MATRIX
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#0B0F19]">
            <div className="w-10 h-10 rounded-xl bg-[#3B82F6]/10 border border-[#3B82F6]/30 flex items-center justify-center text-[#3B82F6] mb-4">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">01. Left-of-Live CT Ingestion</h3>
            <p className="text-sm text-[#9CA3AF] leading-relaxed mb-4">
              Ingests over 2,400 certificate broadcasts per second directly from RFC 6962 Certificate Transparency append-only logs. Evaluates entropy, lookalike permutations, and wildcard SAN entries in sub-150ms CPU fast path.
            </p>
            <div className="text-xs font-mono-data text-[#06B6D4]">
              LATENCY: &lt; 0.15s · RECALL: 98.11%
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#0B0F19]">
            <div className="w-10 h-10 rounded-xl bg-[#06B6D4]/10 border border-[#06B6D4]/30 flex items-center justify-center text-[#06B6D4] mb-4">
              <Eye className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">02. Headless GPU Sandboxing</h3>
            <p className="text-sm text-[#9CA3AF] leading-relaxed mb-4">
              Emulates genuine browser interactions, successfully traversing Cloudflare Turnstile, CAPTCHA gates, and geofencing cloaks that blind 86 of 90 public scanning engines.
            </p>
            <div className="text-xs font-mono-data text-[#06B6D4]">
              FULL V8 EXECUTION · DE-OBFUSCATION READY
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#0B0F19]">
            <div className="w-10 h-10 rounded-xl bg-[#8B5CF6]/10 border border-[#8B5CF6]/30 flex items-center justify-center text-[#8B5CF6] mb-4">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">03. Multimodal Brand Adjudication</h3>
            <p className="text-sm text-[#9CA3AF] leading-relaxed mb-4">
              Combines perceptual visual hashing, OCR layout extraction, and Google Gemini vision models with localized LLMs to catch pixel-level corporate brand forgery and credential trap forms.
            </p>
            <div className="text-xs font-mono-data text-[#8B5CF6]">
              1,200+ ENTERPRISE BRANDS MONITORED
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#0B0F19]">
            <div className="w-10 h-10 rounded-xl bg-[#10B981]/10 border border-[#10B981]/30 flex items-center justify-center text-[#10B981] mb-4">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">04. Sovereign Air-Gapped Operation</h3>
            <p className="text-sm text-[#9CA3AF] leading-relaxed mb-4">
              Built in India with complete domestic data residency guarantees. Deployable entirely on-premises inside isolated military, defense, and high-security banking enclaves with zero external API calls.
            </p>
            <div className="text-xs font-mono-data text-[#10B981]">
              CERT-IN 6-HR COMPLIANT · DPDP READY
            </div>
          </div>
        </div>
      </div>

      {/* Integration Pathways: API, MCP, and SIEM */}
      <div className="glass-panel rounded-2xl p-6 sm:p-10 border border-white/10 bg-[#060911] mb-20">
        <h2 className="text-2xl font-bold text-white mb-4">Integrate PIAD into Your Existing SecOps Stack</h2>
        <p className="text-sm text-[#9CA3AF] max-w-3xl mb-8">
          Nexargio is designed to slide directly into your existing security operations center pipelines without ripping and replacing current perimeter tools.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono-data text-xs">
          <div className="p-4 bg-[#111827] rounded-xl border border-white/5">
            <div className="text-[#3B82F6] font-bold mb-2">// 01. SOAR & SIEM SYNC</div>
            <div className="text-white font-semibold mb-1">Splunk / Microsoft Sentinel / Cortex</div>
            <p className="text-[#9CA3AF] text-[11px] leading-relaxed">
              Stream pre-issuance threat alerts directly into analyst triage queues with pre-built event schemas and defanged indicators.
            </p>
          </div>

          <div className="p-4 bg-[#111827] rounded-xl border border-white/5">
            <div className="text-[#06B6D4] font-bold mb-2">// 02. MCP SERVER FOR AI AGENTS</div>
            <div className="text-white font-semibold mb-1">Claude Desktop & Cursor IDE</div>
            <p className="text-[#9CA3AF] text-[11px] leading-relaxed">
              Equip autonomous development agents with the <code className="text-white">nexargio-mcp</code> tool to audit suspicious URLs and domains before touching them.
            </p>
          </div>

          <div className="p-4 bg-[#111827] rounded-xl border border-white/5">
            <div className="text-[#10B981] font-bold mb-2">// 03. EDGE EGRESS FIREWALLS</div>
            <div className="text-white font-semibold mb-1">Cloudflare / Zscaler / Palo Alto</div>
            <p className="text-[#9CA3AF] text-[11px] leading-relaxed">
              Automatically populate outbound zero-trust proxy blocklists in sub-second latency via automated webhook callbacks.
            </p>
          </div>
        </div>
      </div>

      {/* CTA Band */}
      <div className="p-8 rounded-2xl bg-gradient-to-r from-[#111827] to-[#0B0F19] border border-[#3B82F6]/30 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-xl font-bold text-white mb-1">Ready to benchmark PIAD on your traffic?</h3>
          <p className="text-xs text-[#9CA3AF]">
            Request a 3-week proof-of-concept pilot with 500 hard zero-day test cases.
          </p>
        </div>
        <button
          onClick={onOpenBriefingModal}
          className="px-6 py-3 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs sm:text-sm font-semibold rounded-xl shadow transition-all shrink-0"
        >
          Request POC Pilot
        </button>
      </div>
    </div>
  );
};
