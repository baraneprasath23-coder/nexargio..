import React, { useEffect, useRef } from 'react';

interface Node {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: 'user' | 'device' | 'api' | 'agent';
  label: string;
  isThreat?: boolean;
  isolated?: boolean;
  isolationProgress?: number;
  radius: number;
}

export const HeroCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 540);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 580);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);

    // Initial node graph
    const nodeTypes: Array<{ type: Node['type']; label: string }> = [
      { type: 'user', label: 'CISO / Identity' },
      { type: 'agent', label: 'Autonomous Agent' },
      { type: 'api', label: 'PIAD v4.0 REST' },
      { type: 'device', label: 'Zero-Trust Enclave' },
      { type: 'agent', label: 'MCP Client' },
      { type: 'api', label: 'Auth Gateway' },
      { type: 'user', label: 'SOC Analyst' },
      { type: 'device', label: 'Cloudflare Edge' },
      { type: 'agent', label: 'eBPF Probe' },
    ];

    const nodes: Node[] = nodeTypes.map((item, i) => {
      const angle = (i / nodeTypes.length) * Math.PI * 2;
      const dist = Math.min(width, height) * 0.32;
      return {
        id: `node-${i}`,
        x: width / 2 + Math.cos(angle) * dist + (Math.random() - 0.5) * 40,
        y: height / 2 + Math.sin(angle) * dist + (Math.random() - 0.5) * 40,
        vx: (Math.random() - 0.5) * 0.45,
        vy: (Math.random() - 0.5) * 0.45,
        type: item.type,
        label: item.label,
        radius: item.type === 'agent' ? 9 : 8,
      };
    });

    // Threat cycle state
    let threatCycleTimer = 0;
    let activeThreatIndex = -1;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      threatCycleTimer++;
      // Every ~260 frames (~4.5s), pick or swap threat node
      if (threatCycleTimer % 280 === 0) {
        if (activeThreatIndex >= 0 && nodes[activeThreatIndex]) {
          nodes[activeThreatIndex].isThreat = false;
          nodes[activeThreatIndex].isolated = false;
          nodes[activeThreatIndex].isolationProgress = 0;
        }
        activeThreatIndex = Math.floor(Math.random() * nodes.length);
        if (nodes[activeThreatIndex]) {
          nodes[activeThreatIndex].isThreat = true;
          nodes[activeThreatIndex].isolated = false;
          nodes[activeThreatIndex].isolationProgress = 0;
        }
      }

      // Update positions with boundary damping
      nodes.forEach((node) => {
        node.x += node.vx;
        node.y += node.vy;

        const pad = 50;
        if (node.x < pad || node.x > width - pad) node.vx *= -1;
        if (node.y < pad || node.y > height - pad) node.vy *= -1;

        if (node.isThreat) {
          node.isolationProgress = Math.min(1, (node.isolationProgress || 0) + 0.015);
          if (node.isolationProgress >= 0.85) {
            node.isolated = true;
          }
        }
      });

      // Draw connection mesh
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 180) {
            const isSevered =
              (nodes[i].isolated && nodes[j].isThreat) ||
              (nodes[j].isolated && nodes[i].isThreat);

            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);

            if (isSevered) {
              // Severed / quarantined connection
              ctx.strokeStyle = `rgba(239, 68, 68, ${0.15 * (1 - dist / 180)})`;
              ctx.setLineDash([4, 6]);
            } else if (nodes[i].isThreat || nodes[j].isThreat) {
              // Active threat inspection
              ctx.strokeStyle = `rgba(245, 158, 11, ${0.35 * (1 - dist / 180)})`;
              ctx.setLineDash([]);
            } else {
              // Verified healthy trust link
              ctx.strokeStyle = `rgba(6, 182, 212, ${0.25 * (1 - dist / 180)})`;
              ctx.setLineDash([]);
            }

            ctx.lineWidth = 1;
            ctx.stroke();
            ctx.setLineDash([]);
          }
        }
      }

      // Draw Center PIAD Core Anchor
      const centerX = width / 2;
      const centerY = height / 2;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 36, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(11, 15, 25, 0.9)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.5)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Pulsing radar sweep from center
      const pulseRadius = (threatCycleTimer % 140) * 1.5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, pulseRadius, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(59, 130, 246, ${Math.max(0, 0.4 - pulseRadius / 210)})`;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Center label
      ctx.fillStyle = '#F9FAFB';
      ctx.font = '600 11px Outfit, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('PIAD v4.0', centerX, centerY - 2);
      ctx.fillStyle = '#06B6D4';
      ctx.font = '500 9px "JetBrains Mono", monospace';
      ctx.fillText('EVAL ENGINE', centerX, centerY + 12);

      // Draw Nodes
      nodes.forEach((node) => {
        const isTarget = node.isThreat;
        const color = isTarget
          ? '#EF4444' // Critical threat
          : node.type === 'agent'
          ? '#8B5CF6' // AI Agent
          : node.type === 'api'
          ? '#06B6D4' // API / Telemetry
          : '#3B82F6'; // User / Device

        // Threat isolation containment ring
        if (isTarget && node.isolationProgress) {
          ctx.beginPath();
          ctx.arc(node.x, node.y, node.radius + 14 * node.isolationProgress, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(239, 68, 68, ${0.8 - node.isolationProgress * 0.3})`;
          ctx.lineWidth = 2;
          ctx.setLineDash([4, 4]);
          ctx.stroke();
          ctx.setLineDash([]);

          // Quarantine badge
          if (node.isolated) {
            ctx.fillStyle = '#EF4444';
            ctx.font = '700 9px "JetBrains Mono", monospace';
            ctx.fillText('QUARANTINED', node.x, node.y - node.radius - 14);
          } else {
            ctx.fillStyle = '#F59E0B';
            ctx.font = '600 9px "JetBrains Mono", monospace';
            ctx.fillText('ANALYZING...', node.x, node.y - node.radius - 14);
          }
        }

        // Node circle
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();

        // Node glow
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius + 3, 0, Math.PI * 2);
        ctx.strokeStyle = `${color}44`;
        ctx.lineWidth = 2;
        ctx.stroke();

        // Node text label
        ctx.fillStyle = '#9CA3AF';
        ctx.font = '500 10px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(node.label, node.x, node.y + node.radius + 14);
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="relative w-full h-[380px] lg:h-[520px] rounded-2xl overflow-hidden glass-panel flex items-center justify-center">
      {/* Background radial gradient accent */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.12)_0%,transparent_70%)] pointer-events-none" />
      
      {/* Top status bar telemetry */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-xs font-mono-data text-[#9CA3AF] pointer-events-none z-10">
        <span className="flex items-center gap-1.5 text-[#06B6D4]">
          <span className="inline-block w-2 h-2 rounded-full bg-[#06B6D4]" />
          TELEMETRY // LIVE IDENTITY GRAPH
        </span>
        <span className="text-[#6B7280]">CT-LOGS: 2,410/s · ZERO-DAY DEFENSE</span>
      </div>

      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* Bottom legend */}
      <div className="absolute bottom-3 left-4 right-4 flex items-center justify-center gap-4 text-[11px] font-mono-data text-[#9CA3AF] bg-[#060911]/80 py-1.5 px-3 rounded-lg border border-white/5 pointer-events-none">
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#3B82F6]" /> Identities
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#8B5CF6]" /> AI Agents (MCP)
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#06B6D4]" /> APIs & Enclaves
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#EF4444]" /> Quarantined Threat
        </span>
      </div>
    </div>
  );
};
