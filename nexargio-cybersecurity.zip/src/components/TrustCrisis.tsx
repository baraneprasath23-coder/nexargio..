import React from 'react';
import { ShieldX, ShieldCheck, AlertTriangle, Cpu, Zap, Fingerprint } from 'lucide-react';

export const TrustCrisis: React.FC = () => {
  return (
    <section className="py-20 bg-[#0B0F19]/60 border-y border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EF4444]/10 border border-[#EF4444]/20 text-[#EF4444] text-xs font-mono-data mb-4">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>THE DIGITAL TRUST CRISIS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight mb-4">
            The perimeter collapsed. Identity-speed attacks demand continuous validation.
          </h2>
          <p className="text-base sm:text-lg text-[#9CA3AF] leading-relaxed">
            Generative AI produces pixel-perfect login clones, automated spear-phishing and Adversary-in-the-Middle proxy kits in seconds. When any identity can be forged on demand, static perimeters stop nothing.
          </p>
        </div>

        {/* Split Panel Architecture Comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Left Panel: Fading Legacy Perimeter */}
          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-[#EF4444]/20 relative overflow-hidden bg-[#060911]/80">
            <div className="flex items-center justify-between mb-6">
              <span className="text-xs font-mono-data text-[#EF4444] uppercase tracking-wider flex items-center gap-2">
                <ShieldX className="w-4 h-4" />
                LEGACY STATIC PERIMETER // OBSOLETE
              </span>
              <span className="text-[11px] font-mono-data text-[#6B7280]">FAILING MODEL</span>
            </div>

            <div className="space-y-4 mb-8">
              <div className="p-3.5 rounded-xl bg-[#111827]/60 border border-white/5 opacity-60">
                <div className="text-xs font-semibold text-[#9CA3AF] mb-1">Periodic Reputation Feed Check</div>
                <div className="text-xs text-[#6B7280]">Feeds refresh every 12–24 hours. Modern campaigns expire in under 3 hours.</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#111827]/60 border border-white/5 opacity-60">
                <div className="text-xs font-semibold text-[#9CA3AF] mb-1">Implicit Trust on Domain Age</div>
                <div className="text-xs text-[#6B7280]">Newly registered legitimate domains get blocked; aged expired domains weaponized as lures bypass filters.</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#111827]/60 border border-white/5 opacity-60">
                <div className="text-xs font-semibold text-[#9CA3AF] mb-1">Blind to AiTM Reverse Proxies</div>
                <div className="text-xs text-[#6B7280]">Evilginx and Muraena session proxies bypass traditional MFA without triggering signature alerts.</div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#EF4444]/10 border border-[#EF4444]/20 text-xs font-mono-data text-[#EF4444]">
              CRITICAL VULNERABILITY: Static defenses evaluate after the victim clicks. By then, enterprise session tokens are already harvested.
            </div>
          </div>

          {/* Right Panel: Nexargio Continuous Trust Graph */}
          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-[#3B82F6]/30 relative overflow-hidden bg-[#0B0F19]">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#3B82F6]/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center justify-between mb-6">
              <span className="text-xs font-mono-data text-[#06B6D4] uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#3B82F6]" />
                NEXARGIO CONTINUOUS VALIDATION // ACTIVE
              </span>
              <span className="text-[11px] font-mono-data text-[#10B981] px-2 py-0.5 rounded bg-[#10B981]/15 border border-[#10B981]/30">SUB-SECOND ENFORCEMENT</span>
            </div>

            <div className="space-y-4 mb-8">
              <div className="p-3.5 rounded-xl bg-[#111827] border border-white/10">
                <div className="text-xs font-semibold text-[#F9FAFB] flex items-center gap-1.5 mb-1">
                  <Zap className="w-3.5 h-3.5 text-[#06B6D4]" />
                  <span>Left-of-Live Pre-Issuance Interception</span>
                </div>
                <div className="text-xs text-[#9CA3AF]">Watches Certificate Transparency (CT) logs in real time. Flags weaponized domains under 5 seconds from cert issuance.</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#111827] border border-white/10">
                <div className="text-xs font-semibold text-[#F9FAFB] flex items-center gap-1.5 mb-1">
                  <Fingerprint className="w-3.5 h-3.5 text-[#3B82F6]" />
                  <span>Multimodal Brand Similarity Adjudication</span>
                </div>
                <div className="text-xs text-[#9CA3AF]">Executes headless GPU browser sandboxing to match DOM visual layouts, logos, and credential trap fields against brand corpus.</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#111827] border border-white/10">
                <div className="text-xs font-semibold text-[#F9FAFB] flex items-center gap-1.5 mb-1">
                  <Cpu className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  <span>Air-Gapped & Autonomous AI Enclave Ready</span>
                </div>
                <div className="text-xs text-[#9CA3AF]">Operates in cloud, on-premises, or classified air-gapped enclaves with local LLM verification and MCP agent support.</div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#3B82F6]/10 border border-[#3B82F6]/30 text-xs font-mono-data text-[#F9FAFB] flex items-center justify-between">
              <span>ZERO-DAY RECALL RATE:</span>
              <strong className="text-[#3B82F6]">98.11% (10,000 live test set)</strong>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
