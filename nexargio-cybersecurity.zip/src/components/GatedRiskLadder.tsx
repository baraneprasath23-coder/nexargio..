import React, { useState } from 'react';
import { 
  Zap, 
  Search, 
  Cpu, 
  FileCheck2, 
  CheckCircle, 
  AlertTriangle, 
  ShieldAlert, 
  Shield, 
  ArrowRight,
  Hash
} from 'lucide-react';

interface GatedRiskLadderProps {
  onInspectSpecs: () => void;
}

export const GatedRiskLadder: React.FC<GatedRiskLadderProps> = ({ onInspectSpecs }) => {
  const [activeStage, setActiveStage] = useState<number>(0);

  const stages = [
    {
      step: '0',
      title: 'Fast Path Filter',
      engine: 'CPU',
      latency: '~0.15s',
      efficiency: 'Clears 99.8% of clean URLs',
      description: 'Instant verification evaluating lexical patterns, high-entropy subdomains, RDAP/WHOIS registration dates, and SSL/TLS certificate transparency metadata.',
      subtext: 'Bypasses GPU compute entirely for established, legitimate infrastructure, dropping latency to near-zero.'
    },
    {
      step: '1',
      title: 'DOM Page Analysis',
      engine: 'Lightweight V8',
      latency: '~0.5s',
      efficiency: 'Parses DOM structures & forms',
      description: 'Scrutinizes HTML form inputs, hidden iframe redirectors, adversary token harvest scripts, and JavaScript password field mimics.',
      subtext: 'Detects stealth credential traps even before full visual assets or stylesheets load.'
    },
    {
      step: '2',
      title: 'Deep Sandbox & Vision AI',
      engine: 'GPU Headless Cluster',
      latency: '~1.2s',
      efficiency: 'Reserved for 0.2% suspicious URLs',
      description: 'Executes full headless Chromium rendering with CAPTCHA/Turnstile bypass emulation, perceptual visual brand hashing, OCR text extraction, and Gemini vision adjudication.',
      subtext: 'Identifies pixel-level brand mimicry, stolen logos, and deceptive favicon replacements.'
    },
    {
      step: '3',
      title: 'Explainable Adjudication',
      engine: 'Deterministic Rule Engine',
      latency: '< 0.1s',
      efficiency: 'SHA-256 Hashed Evidence Record',
      description: 'Issues four-tier verdict with plain-English reasoning trace, then pushes real-time blocks to enterprise firewalls, SOAR playbooks, and registrars.',
      subtext: 'Every screenshot and network packet trace is cryptographically hashed for CERT-In submission.'
    }
  ];

  return (
    <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Section Header */}
      <div className="max-w-3xl mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#10B981]/10 border border-[#10B981]/20 text-[#10B981] text-xs font-mono-data mb-4">
          <Zap className="w-3.5 h-3.5" />
          <span>GATED RISK LADDER // COMPUTE OPTIMIZATION</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight mb-4">
          Microsecond fast path. GPU-grade depth only where it matters.
        </h2>
        <p className="text-base sm:text-lg text-[#9CA3AF]">
          Traditional scanners waste massive GPU cycles brute-forcing every URL, or rely on shallow regexes. Nexargio’s patent-pending tiered pipeline isolates threats with extreme speed and ~90% lower compute overhead.
        </p>
      </div>

      {/* 4 Ladder Stages */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {stages.map((stage, idx) => {
          const isSelected = activeStage === idx;
          return (
            <div
              key={idx}
              onClick={() => setActiveStage(idx)}
              className={`glass-panel rounded-2xl p-6 cursor-pointer transition-all duration-300 border flex flex-col justify-between ${
                isSelected
                  ? 'border-[#3B82F6] bg-[#111827] shadow-[0_0_25px_rgba(59,130,246,0.25)]'
                  : 'border-white/10 hover:border-white/20'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-mono-data text-[#06B6D4] font-bold">
                    STAGE {stage.step}
                  </span>
                  <span className="text-xs font-mono-data px-2 py-0.5 rounded bg-white/5 text-[#F9FAFB]">
                    {stage.latency}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white mb-1">{stage.title}</h3>
                <div className="text-xs font-mono-data text-[#6B7280] mb-3">
                  Engine: <span className="text-[#3B82F6]">{stage.engine}</span>
                </div>

                <p className="text-xs text-[#9CA3AF] leading-relaxed mb-4">
                  {stage.description}
                </p>
              </div>

              <div className="pt-4 border-t border-white/5">
                <div className="text-[11px] font-mono-data text-[#10B981] font-semibold mb-1">
                  ✓ {stage.efficiency}
                </div>
                <div className="text-[11px] text-[#6B7280]">
                  {stage.subtext}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Stage 3 Four-Tier Verdict Ladder Chips */}
      <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 mb-8 bg-[#0B0F19]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-1">
              STAGE 3 DECISION MATRIX // ENFORCEMENT LADDER
            </div>
            <h4 className="text-xl font-bold text-white">Continuous Four-Tier Risk Ladder</h4>
          </div>
          <span className="text-xs font-mono-data text-[#06B6D4]">
            DETERMINISTIC VERDICT ENGINE
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[#10B981]/10 border border-[#10B981]/30 text-left">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-[#10B981]" />
              <span className="text-sm font-bold text-[#10B981]">Permit</span>
            </div>
            <p className="text-xs text-[#9CA3AF]">
              Risk Score 0–20. Verified benign infrastructure, matching MX records, and legitimate business provenance.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F59E0B]/10 border border-[#F59E0B]/30 text-left">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-[#F59E0B]" />
              <span className="text-sm font-bold text-[#F59E0B]">Step-up / Isolate</span>
            </div>
            <p className="text-xs text-[#9CA3AF]">
              Risk Score 21–55. Anomalous registration with non-standard redirectors. Prompts mandatory MFA re-authentication.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#8B5CF6]/10 border border-[#8B5CF6]/30 text-left">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-5 h-5 text-[#8B5CF6]" />
              <span className="text-sm font-bold text-[#8B5CF6]">Remote Browser Isolation</span>
            </div>
            <p className="text-xs text-[#9CA3AF]">
              Risk Score 56–74. Unconfirmed multi-stage lure. Rendered as disposable pixels in isolated zero-trust cloud browser.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#EF4444]/10 border border-[#EF4444]/30 text-left">
            <div className="flex items-center gap-2 mb-2">
              <ShieldAlert className="w-5 h-5 text-[#EF4444]" />
              <span className="text-sm font-bold text-[#EF4444]">Hard Block</span>
            </div>
            <p className="text-xs text-[#9CA3AF]">
              Risk Score 75–100. Confirmed AiTM proxy, brand impersonation, or credential trap. Immediate firewall drop & evidence push.
            </p>
          </div>
        </div>
      </div>

      {/* Side Note & CTA */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-6 p-6 rounded-xl bg-[#111827] border border-white/5">
        <div className="flex items-start gap-3">
          <Hash className="w-5 h-5 text-[#06B6D4] shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm text-[#9CA3AF]">
            <strong className="text-white">~90% lower compute cost</strong> than scanning every link with heavy GPU emulation. Every detection screenshot is SHA-256 hashed and timestamped — evidence-grade for takedown requests, CERT-In reports, and legal teams.
          </div>
        </div>
        <button
          onClick={onInspectSpecs}
          className="px-5 py-2.5 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shrink-0"
        >
          <span>Inspect Technical Specs</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </section>
  );
};
