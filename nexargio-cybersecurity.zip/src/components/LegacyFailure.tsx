import React from 'react';
import { Clock, CheckCircle2, XCircle, ArrowRight, ShieldCheck, Zap } from 'lucide-react';
import { TESTED_RESULTS_COMPARISON } from '../data/content';

interface LegacyFailureProps {
  onOpenChecker: () => void;
  onOpenBriefingModal: () => void;
}

export const LegacyFailure: React.FC<LegacyFailureProps> = ({
  onOpenChecker,
  onOpenBriefingModal,
}) => {
  return (
    <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="max-w-3xl mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/10 border border-[#3B82F6]/20 text-[#3B82F6] text-xs font-mono-data mb-4">
          <Clock className="w-3.5 h-3.5" />
          <span>ATTACK VELOCITY GAP</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight mb-4">
          Blocklists update in 12–24 hours. Attacks live for 2–3.
        </h2>
        <p className="text-base sm:text-lg text-[#9CA3AF]">
          By the time traditional threat feeds add a malicious domain, victim credentials have already been exfiltrated and the infrastructure dismantled.
        </p>
      </div>

      {/* Horizontal Lifecycle Timeline Graphic */}
      <div className="glass-panel rounded-2xl p-6 sm:p-8 mb-12 border border-white/10 relative overflow-hidden">
        <div className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider mb-8">
          INFRASTRUCTURE LIFECYCLE VS. DETECTION HORIZON
        </div>

        <div className="relative">
          {/* Timeline Bar Track */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-[#1F2937] -translate-y-1/2 z-0" />
          
          {/* Active Interception Glow on timeline */}
          <div className="hidden lg:block absolute top-1/2 left-[20%] w-[160px] h-1 bg-gradient-to-r from-[#10B981] to-[#3B82F6] -translate-y-1/2 shadow-[0_0_12px_rgba(59,130,246,0.8)] z-0" />

          {/* Timeline Steps */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6 relative z-10">
            
            {/* Step 1 */}
            <div className="flex flex-col items-center lg:items-start text-center lg:text-left bg-[#0B0F19] lg:bg-transparent p-4 lg:p-0 rounded-xl">
              <div className="w-8 h-8 rounded-full bg-[#111827] border border-white/10 flex items-center justify-center text-xs font-mono-data text-[#9CA3AF] mb-3">
                01
              </div>
              <div className="text-xs font-semibold text-white mb-1">Domain Registered</div>
              <div className="text-[11px] text-[#6B7280] font-mono-data">Adversary registers lookalike typosquat</div>
            </div>

            {/* Step 2 - NEXARGIO INTERCEPTION POINT */}
            <div className="flex flex-col items-center lg:items-start text-center lg:text-left bg-[#10B981]/10 lg:bg-[#10B981]/15 p-4 rounded-xl border border-[#10B981]/40 relative">
              <div className="absolute -top-3 left-1/2 lg:left-4 -translate-x-1/2 lg:translate-x-0 bg-[#10B981] text-black font-mono-data font-bold text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider shadow">
                Nexargio Flags Here
              </div>
              <div className="w-8 h-8 rounded-full bg-[#10B981] text-black font-bold flex items-center justify-center text-xs font-mono-data mb-3 shadow-[0_0_15px_rgba(16,185,129,0.5)]">
                <Zap className="w-4 h-4" />
              </div>
              <div className="text-xs font-bold text-[#10B981] mb-1">Cert Issued (&lt; 5s)</div>
              <div className="text-[11px] text-[#9CA3AF] font-mono-data">PIAD intercepts CT log & creates evidence hash</div>
            </div>

            {/* Step 3 */}
            <div className="flex flex-col items-center lg:items-start text-center lg:text-left bg-[#0B0F19] lg:bg-transparent p-4 lg:p-0 rounded-xl">
              <div className="w-8 h-8 rounded-full bg-[#111827] border border-white/10 flex items-center justify-center text-xs font-mono-data text-[#9CA3AF] mb-3">
                03
              </div>
              <div className="text-xs font-semibold text-white mb-1">First Email Dispatched</div>
              <div className="text-[11px] text-[#6B7280] font-mono-data">Phishing lure sent to victim executives</div>
            </div>

            {/* Step 4 */}
            <div className="flex flex-col items-center lg:items-start text-center lg:text-left bg-[#0B0F19] lg:bg-transparent p-4 lg:p-0 rounded-xl">
              <div className="w-8 h-8 rounded-full bg-[#EF4444]/20 border border-[#EF4444]/40 flex items-center justify-center text-xs font-mono-data text-[#EF4444] mb-3">
                04
              </div>
              <div className="text-xs font-semibold text-[#EF4444] mb-1">Credentials Stolen</div>
              <div className="text-[11px] text-[#6B7280] font-mono-data">MFA bypassed via reverse proxy session kit</div>
            </div>

            {/* Step 5 */}
            <div className="flex flex-col items-center lg:items-start text-center lg:text-left bg-[#0B0F19] lg:bg-transparent p-4 lg:p-0 rounded-xl">
              <div className="w-8 h-8 rounded-full bg-[#111827] border border-white/10 flex items-center justify-center text-xs font-mono-data text-[#9CA3AF] mb-3">
                05
              </div>
              <div className="text-xs font-semibold text-white mb-1">Domain Dropped</div>
              <div className="text-[11px] text-[#6B7280] font-mono-data">Host terminates or attacker tears down kit</div>
            </div>

            {/* Step 6 - TRADITIONAL FAILURE */}
            <div className="flex flex-col items-center lg:items-start text-center lg:text-left bg-[#EF4444]/10 p-4 rounded-xl border border-[#EF4444]/30">
              <div className="w-8 h-8 rounded-full bg-[#EF4444]/20 text-[#EF4444] flex items-center justify-center text-xs font-mono-data mb-3">
                06
              </div>
              <div className="text-xs font-semibold text-[#EF4444] mb-1">Blocklists Update</div>
              <div className="text-[11px] text-[#6B7280] font-mono-data">12–24 hours later (Stale alerts on dead sites)</div>
            </div>

          </div>
        </div>
      </div>

      {/* Empirical Tested Results Table (Rule 1: no 3rd-party logos as graphics) */}
      <div className="glass-panel rounded-2xl overflow-hidden border border-white/10 mb-8">
        <div className="p-6 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-lg font-bold text-white">Empirical Tested Results Comparison</h3>
            <p className="text-xs text-[#9CA3AF]">
              Comparative telemetry conducted across real attack campaigns under identical network conditions.
            </p>
          </div>
          <span className="text-xs font-mono-data text-[#06B6D4] self-start sm:self-auto">
            BENCHMARK V1.0.0
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="bg-[#111827]/80 text-[#6B7280] font-mono-data uppercase text-[11px] border-b border-white/5">
                <th className="p-4 sm:p-5 font-semibold">Test Case Scenario</th>
                <th className="p-4 sm:p-5 font-semibold text-[#EF4444]">Public / Legacy Commercial Scanners</th>
                <th className="p-4 sm:p-5 font-semibold text-[#10B981]">Nexargio PIAD Engine</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {TESTED_RESULTS_COMPARISON.map((row, idx) => (
                <tr key={idx} className="hover:bg-white/[0.02] transition-colors">
                  <td className="p-4 sm:p-5 font-semibold text-white align-top max-w-[240px]">
                    {row.testCase}
                  </td>
                  <td className="p-4 sm:p-5 text-[#9CA3AF] align-top max-w-[320px]">
                    <div className="flex items-start gap-2">
                      <XCircle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
                      <span>{row.publicScanners}</span>
                    </div>
                  </td>
                  <td className="p-4 sm:p-5 text-[#F9FAFB] align-top max-w-[320px]">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
                      <span className="font-medium text-[#10B981]">{row.nexargio}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CTA Action Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 glass-panel rounded-xl border border-white/5">
        <span className="text-xs sm:text-sm text-[#9CA3AF]">
          Want to evaluate your own suspicious URL queue against our pre-issuance engine?
        </span>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={onOpenChecker}
            className="w-full sm:w-auto px-4 py-2.5 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <span>View Gap Analysis in URL Checker</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onOpenBriefingModal}
            className="hidden sm:inline-flex px-4 py-2.5 bg-transparent hover:bg-white/5 text-[#9CA3AF] hover:text-white text-xs font-medium rounded-lg border border-white/10 transition-colors"
          >
            Request Full Report
          </button>
        </div>
      </div>
    </section>
  );
};
