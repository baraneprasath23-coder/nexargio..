import React, { useState } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  ShieldQuestion, 
  Search, 
  Sparkles, 
  ExternalLink, 
  FileCheck2, 
  Lock, 
  RefreshCw,
  Copy,
  CheckCircle2,
  Terminal
} from 'lucide-react';
import { ThreatAnalysisResult } from '../types';

interface AnalystCheckerProps {
  onOpenApiKeyModal: () => void;
  onOpenBriefingModal: () => void;
}

export const AnalystChecker: React.FC<AnalystCheckerProps> = ({ 
  onOpenApiKeyModal,
  onOpenBriefingModal 
}) => {
  const [inputUrl, setInputUrl] = useState('https://ucpaytm.store/claim-uc');
  const [isScanning, setIsScanning] = useState(false);
  const [currentStage, setCurrentStage] = useState<number>(0);
  const [scansCount, setScansCount] = useState(1);
  const [copiedEvidence, setCopiedEvidence] = useState(false);

  // Pre-configured results for realistic cybersecurity demo
  const sampleData: Record<string, ThreatAnalysisResult> = {
    'ucpaytm.store': {
      url: 'https://ucpaytm[.]store/claim-uc',
      riskScore: 92,
      verdict: 'Hard Block',
      riskGrade: 'F',
      confidence: 99.4,
      threatType: 'UPI Financial Fraud & BGMI Phishing Kit',
      fastPathLatency: '0.14s',
      domAnalysisLatency: '0.48s',
      sandboxLatency: '1.18s',
      sha256Evidence: '8f4a3c9e62b10499cfad60a2b53f86e3441999e28f3bb78018dc3e721590e8c1',
      reasons: [
        'Domain registered 14 hours ago via high-risk registrar (Hostinger India)',
        'Adversary-in-the-Middle JavaScript injects forged UPI VPA collect trigger',
        'Visual brand similarity score 94.2% against Paytm Payments Bank brand marks',
        'Obfuscated dynamic QR-code generator disguised as gaming incentive'
      ],
      lexicalSignals: {
        domainAge: '14 hours',
        entropyScore: 4.82,
        certIssuer: "Let's Encrypt Authority E6",
        ctLogStatus: 'Intercepted at Certificate Transparency ingestion'
      },
      domSignals: {
        credentialTraps: 4,
        hiddenIframes: true,
        turnstileBypassAttempt: false
      },
      visualSignals: {
        brandImpersonated: 'Paytm UPI & BGMI Krafton Assets',
        visualSimilarity: 94.2,
        logoHashMatch: true
      }
    },
    'chatgpt-enterprise': {
      url: 'https://chatgpt-enterprise-login[.]net/sso/auth',
      riskScore: 85,
      verdict: 'Hard Block',
      riskGrade: 'F',
      confidence: 98.7,
      threatType: 'Adversary-in-the-Middle (AiTM) OAuth Token Exfiltration',
      fastPathLatency: '0.12s',
      domAnalysisLatency: '0.41s',
      sandboxLatency: '1.05s',
      sha256Evidence: 'd1984c3e8092a188f6385a4918e77c59388ffc98a004ef517bb2cd48858a74e2',
      reasons: [
        'Pre-issuance CT log alert triggered 3 minutes post-certificate creation',
        'Adversary reverse-proxy (evilginx variant) proxying real OpenAI SAML session',
        'Zero of 90 public legacy scanners alerted at detection timestamp',
        'Targeting corporate single sign-on tokens for developer repositories'
      ],
      lexicalSignals: {
        domainAge: '3.2 hours',
        entropyScore: 4.21,
        certIssuer: 'ZeroSSL RSA Domain CA',
        ctLogStatus: 'Pre-issuance flagged via Nexargio CT monitor'
      },
      domSignals: {
        credentialTraps: 2,
        hiddenIframes: true,
        turnstileBypassAttempt: true
      },
      visualSignals: {
        brandImpersonated: 'OpenAI Enterprise SSO',
        visualSimilarity: 98.6,
        logoHashMatch: true
      }
    },
    'hdfc-kyc': {
      url: 'https://hdfc-kyc-update-portal[.]org/verify-pan',
      riskScore: 95,
      verdict: 'Hard Block',
      riskGrade: 'F',
      confidence: 99.8,
      threatType: 'PAN / Aadhaar Net Banking Credential Trap',
      fastPathLatency: '0.11s',
      domAnalysisLatency: '0.39s',
      sandboxLatency: '1.12s',
      sha256Evidence: '3c0a51be8c94e803567bfa3829dc7a18bb93489e224e7724a2f8b50257e84d41',
      reasons: [
        'High-entropy typosquat targeting HDFC Bank NetBanking customers',
        'Immediate harvest of Customer ID, IPIN, PAN, and OTP in unencrypted POST stream',
        'Zero-day campaign intercepted prior to bulk SMS/WhatsApp dissemination',
        'SHA-256 evidence package formatted for CERT-In / RBI reporting'
      ],
      lexicalSignals: {
        domainAge: '5.8 hours',
        entropyScore: 5.14,
        certIssuer: 'cPanel Inc. Certification Authority',
        ctLogStatus: 'Flagged under 5s from log announcement'
      },
      domSignals: {
        credentialTraps: 5,
        hiddenIframes: true,
        turnstileBypassAttempt: false
      },
      visualSignals: {
        brandImpersonated: 'HDFC Bank NetBanking UI',
        visualSimilarity: 96.1,
        logoHashMatch: true
      }
    },
    'hyd-artisan': {
      url: 'https://hyd-artisancrafts.co.in/store',
      riskScore: 0,
      verdict: 'Permit',
      riskGrade: 'A+',
      confidence: 99.9,
      threatType: 'Verified Legitimate Small Business',
      fastPathLatency: '0.08s',
      domAnalysisLatency: '0.22s',
      sandboxLatency: '0.00s (Fast Path Cleared)',
      sha256Evidence: '11e4f9b265908cf4421e499dca896e054ba98745c1103f568a52932c02998ae1',
      reasons: [
        'Cleared via Fast Path CPU rules in 0.08s (99.8% compute efficiency)',
        'Legitimate merchant gateway with valid PCI-DSS compliance header',
        'Valid Indian GSTIN identifier matched in structured business footer',
        'Zero malicious redirection or brand impersonation signals'
      ],
      lexicalSignals: {
        domainAge: '3 days (Newly registered, non-malicious)',
        entropyScore: 2.15,
        certIssuer: 'DigiCert Global TLS RSA',
        ctLogStatus: 'Normal corporate issuance profile'
      },
      domSignals: {
        credentialTraps: 0,
        hiddenIframes: false,
        turnstileBypassAttempt: false
      },
      visualSignals: {
        brandImpersonated: null,
        visualSimilarity: 0,
        logoHashMatch: false
      }
    }
  };

  const [activeResult, setActiveResult] = useState<ThreatAnalysisResult>(sampleData['ucpaytm.store']);

  const runScan = (overrideUrl?: string) => {
    const target = overrideUrl || inputUrl;
    setIsScanning(true);
    setCurrentStage(1);

    setTimeout(() => setCurrentStage(2), 350);
    setTimeout(() => setCurrentStage(3), 850);
    setTimeout(() => {
      setIsScanning(false);
      setScansCount((prev) => prev + 1);

      if (target.includes('chatgpt') || target.includes('openai')) {
        setActiveResult(sampleData['chatgpt-enterprise']);
      } else if (target.includes('hdfc') || target.includes('bank') || target.includes('sbi')) {
        setActiveResult(sampleData['hdfc-kyc']);
      } else if (target.includes('hyd') || target.includes('artisan') || target.includes('clean') || target.includes('google')) {
        setActiveResult(sampleData['hyd-artisan']);
      } else {
        // Dynamic custom URL evaluation
        setActiveResult({
          url: target,
          riskScore: target.length > 25 ? 88 : 12,
          verdict: target.length > 25 ? 'Hard Block' : 'Permit',
          riskGrade: target.length > 25 ? 'F' : 'A+',
          confidence: 97.8,
          threatType: target.length > 25 ? 'Suspected AiTM Credential Harvester' : 'Standard Web Property',
          fastPathLatency: '0.11s',
          domAnalysisLatency: '0.44s',
          sandboxLatency: target.length > 25 ? '1.10s' : '0.00s (Fast Path Cleared)',
          sha256Evidence: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
          reasons: target.length > 25
            ? [
                'Suspicious lexical anomaly: multi-subdomain structuring and credential parameter traps',
                'Pre-issuance CT log telemetry indicates newly generated wildcard certificate',
                'Visual elements attempt unauthorized mimicry of enterprise authentication interfaces'
              ]
            : ['Low risk lexical profile, clean RDAP record and standard HTTPS certificate'],
          lexicalSignals: {
            domainAge: '1.8 days',
            entropyScore: target.length > 25 ? 4.9 : 2.2,
            certIssuer: 'Let\'s Encrypt Authority E6',
            ctLogStatus: 'Verified against certificate transparency feeds'
          },
          domSignals: {
            credentialTraps: target.length > 25 ? 3 : 0,
            hiddenIframes: target.length > 25,
            turnstileBypassAttempt: false
          },
          visualSignals: {
            brandImpersonated: target.length > 25 ? 'Enterprise Login System' : null,
            visualSimilarity: target.length > 25 ? 89.2 : 0,
            logoHashMatch: target.length > 25
          }
        });
      }
    }, 1400);
  };

  const handleCopyEvidence = () => {
    navigator.clipboard.writeText(JSON.stringify(activeResult, null, 2));
    setCopiedEvidence(true);
    setTimeout(() => setCopiedEvidence(false), 2000);
  };

  const isCritical = activeResult.riskScore >= 75;
  const isSuspicious = activeResult.riskScore >= 40 && activeResult.riskScore < 75;
  const isClean = activeResult.riskScore < 40;

  return (
    <section id="analyst-checker" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/10 border border-[#3B82F6]/20 text-[#3B82F6] text-xs font-mono-data mb-4">
          <Terminal className="w-3.5 h-3.5" />
          <span>ANALYST URL CHECKER // BICOLOR RISK ENGINE</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#F9FAFB] mb-4">
          Alpha Mountain Bicolor Threat Assessment
        </h2>
        <p className="text-base sm:text-lg text-[#9CA3AF]">
          Inspect suspicious domains, AiTM reverse-proxy kits, and zero-day lures using PIAD’s 4-stage microsecond evaluation ladder. Test live benchmark cases below.
        </p>
      </div>

      {/* Main Checker Container */}
      <div className="glass-panel rounded-2xl p-6 lg:p-8 relative overflow-hidden border border-white/10 shadow-2xl">
        {/* Glow ambient background */}
        <div 
          className={`absolute top-0 right-0 w-96 h-96 rounded-full blur-[120px] pointer-events-none transition-colors duration-700 ${
            isCritical ? 'bg-[#EF4444]/15' : isSuspicious ? 'bg-[#F59E0B]/15' : 'bg-[#10B981]/15'
          }`} 
        />

        {/* Input Bar */}
        <div className="flex flex-col md:flex-row items-stretch gap-3 mb-6 relative z-10">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-[#6B7280]">
              <Search className="w-5 h-5" />
            </div>
            <input
              type="text"
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              placeholder="Paste suspicious URL or domain (e.g. hdfc-kyc-update-portal[.]org)..."
              className="w-full pl-12 pr-4 py-3.5 bg-[#0B0F19] text-[#F9FAFB] border border-white/10 rounded-xl focus:outline-none focus:border-[#3B82F6] font-mono-data text-sm transition-colors"
            />
          </div>
          <button
            onClick={() => runScan()}
            disabled={isScanning}
            className="px-6 py-3.5 bg-[#3B82F6] hover:bg-[#2563EB] text-white font-medium text-sm rounded-xl transition-all shadow-[0_0_20px_rgba(59,130,246,0.35)] flex items-center justify-center gap-2 disabled:opacity-50 shrink-0"
          >
            {isScanning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Adjudicating...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Evaluate Threat</span>
              </>
            )}
          </button>
        </div>

        {/* Quick Test Presets */}
        <div className="flex flex-wrap items-center gap-2 mb-8 text-xs font-mono-data text-[#9CA3AF] relative z-10">
          <span className="text-[#6B7280]">BENCHMARK PRESETS:</span>
          <button
            onClick={() => {
              setInputUrl('https://ucpaytm.store/claim-uc');
              runScan('https://ucpaytm.store/claim-uc');
            }}
            className="px-2.5 py-1 rounded-md bg-[#111827] border border-white/10 hover:border-[#EF4444]/60 text-[#EF4444] transition-colors"
          >
            Paytm UPI Scam (ucpaytm[.]store)
          </button>
          <button
            onClick={() => {
              setInputUrl('https://chatgpt-enterprise-login.net/sso/auth');
              runScan('https://chatgpt-enterprise-login.net/sso/auth');
            }}
            className="px-2.5 py-1 rounded-md bg-[#111827] border border-white/10 hover:border-[#EF4444]/60 text-[#EF4444] transition-colors"
          >
            OpenAI AiTM Proxy (chatgpt-login[.]net)
          </button>
          <button
            onClick={() => {
              setInputUrl('https://hdfc-kyc-update-portal.org/verify-pan');
              runScan('https://hdfc-kyc-update-portal.org/verify-pan');
            }}
            className="px-2.5 py-1 rounded-md bg-[#111827] border border-white/10 hover:border-[#EF4444]/60 text-[#EF4444] transition-colors"
          >
            HDFC/SBI KYC Spoof
          </button>
          <button
            onClick={() => {
              setInputUrl('https://hyd-artisancrafts.co.in/store');
              runScan('https://hyd-artisancrafts.co.in/store');
            }}
            className="px-2.5 py-1 rounded-md bg-[#111827] border border-white/10 hover:border-[#10B981]/60 text-[#10B981] transition-colors"
          >
            Legitimate Small Business (hyd-artisan)
          </button>
        </div>

        {/* Live Scan Pipeline Stage Progress */}
        {isScanning && (
          <div className="mb-8 p-4 bg-[#0B0F19] rounded-xl border border-[#3B82F6]/30 animate-pulse">
            <div className="flex items-center justify-between text-xs font-mono-data mb-2 text-[#9CA3AF]">
              <span>PIAD GATED LADDER EXECUTION</span>
              <span className="text-[#3B82F6]">STAGE {currentStage} OF 3</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className={`h-2 rounded-full transition-all ${currentStage >= 1 ? 'bg-[#3B82F6]' : 'bg-[#111827]'}`} />
              <div className={`h-2 rounded-full transition-all ${currentStage >= 2 ? 'bg-[#06B6D4]' : 'bg-[#111827]'}`} />
              <div className={`h-2 rounded-full transition-all ${currentStage >= 3 ? 'bg-[#8B5CF6]' : 'bg-[#111827]'}`} />
            </div>
            <div className="text-xs font-mono-data text-[#6B7280] mt-2 text-center">
              {currentStage === 1 && 'Stage 0 CPU Fast Path: Lexical RDAP, WHOIS & CT-Log verification...'}
              {currentStage === 2 && 'Stage 1 Page Analysis: Parsing DOM credential-traps & session interceptors...'}
              {currentStage === 3 && 'Stage 2 Deep Sandbox: Headless GPU rendering & vision-AI brand adjudication...'}
            </div>
          </div>
        )}

        {/* Bicolor Assessment Output Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10">
          {/* Left Column: Bicolor Risk Gauge & Core Verdict */}
          <div className="lg:col-span-5 bg-[#0B0F19] rounded-xl p-6 border border-white/5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono-data text-[#6B7280]">BICOLOR RISK INDEX</span>
                <span className={`px-2.5 py-0.5 rounded text-xs font-mono-data font-semibold ${
                  isCritical 
                    ? 'bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30' 
                    : isSuspicious 
                    ? 'bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30' 
                    : 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30'
                }`}>
                  GRADE {activeResult.riskGrade}
                </span>
              </div>

              {/* Large Bicolor Score Display */}
              <div className="flex items-baseline gap-3 my-4">
                <span className={`text-6xl font-extrabold tracking-tight font-outfit ${
                  isCritical ? 'text-[#EF4444]' : isSuspicious ? 'text-[#F59E0B]' : 'text-[#10B981]'
                }`}>
                  {activeResult.riskScore}
                </span>
                <span className="text-xl font-mono-data text-[#6B7280]">/ 100</span>
                <span className="ml-auto text-xs font-mono-data text-[#9CA3AF]">
                  CONFIDENCE: <strong className="text-white">{activeResult.confidence}%</strong>
                </span>
              </div>

              {/* Bicolor Spectrum Progress Bar */}
              <div className="w-full h-3 rounded-full bg-[#111827] overflow-hidden flex mb-6">
                <div 
                  className={`h-full transition-all duration-700 ${
                    isCritical ? 'bg-[#EF4444]' : isSuspicious ? 'bg-[#F59E0B]' : 'bg-[#10B981]'
                  }`}
                  style={{ width: `${Math.max(activeResult.riskScore, 4)}%` }}
                />
              </div>

              {/* Verdict Card */}
              <div className={`p-4 rounded-xl border flex items-center gap-3.5 mb-4 ${
                isCritical 
                  ? 'bg-[#EF4444]/10 border-[#EF4444]/30 text-[#EF4444]' 
                  : isSuspicious 
                  ? 'bg-[#F59E0B]/10 border-[#F59E0B]/30 text-[#F59E0B]' 
                  : 'bg-[#10B981]/10 border-[#10B981]/30 text-[#10B981]'
              }`}>
                {isCritical ? (
                  <ShieldAlert className="w-8 h-8 shrink-0" />
                ) : isSuspicious ? (
                  <ShieldQuestion className="w-8 h-8 shrink-0" />
                ) : (
                  <ShieldCheck className="w-8 h-8 shrink-0" />
                )}
                <div>
                  <div className="text-xs uppercase tracking-wider font-mono-data opacity-80">FINAL ADJUDICATION</div>
                  <div className="text-lg font-bold text-white">{activeResult.verdict}</div>
                </div>
              </div>

              {/* Threat Classification */}
              <div className="text-xs font-mono-data text-[#9CA3AF] mb-4">
                <span className="text-[#6B7280] block mb-1">CLASSIFICATION:</span>
                <span className="text-white bg-[#111827] px-2.5 py-1 rounded inline-block">
                  {activeResult.threatType}
                </span>
              </div>
            </div>

            {/* Microsecond Telemetry Latencies */}
            <div className="pt-4 border-t border-white/5 grid grid-cols-3 gap-2 text-center text-xs font-mono-data">
              <div className="p-2 bg-[#111827] rounded-lg">
                <div className="text-[#6B7280] text-[10px]">CPU FAST</div>
                <div className="text-[#06B6D4] font-semibold">{activeResult.fastPathLatency}</div>
              </div>
              <div className="p-2 bg-[#111827] rounded-lg">
                <div className="text-[#6B7280] text-[10px]">DOM TRAP</div>
                <div className="text-[#3B82F6] font-semibold">{activeResult.domAnalysisLatency}</div>
              </div>
              <div className="p-2 bg-[#111827] rounded-lg">
                <div className="text-[#6B7280] text-[10px]">GPU SANDBOX</div>
                <div className="text-[#8B5CF6] font-semibold">{activeResult.sandboxLatency}</div>
              </div>
            </div>
          </div>

          {/* Right Column: Explainability Trace & Signals */}
          <div className="lg:col-span-7 bg-[#0B0F19] rounded-xl p-6 border border-white/5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-[#F9FAFB] flex items-center gap-2">
                  <FileCheck2 className="w-4 h-4 text-[#3B82F6]" />
                  <span>Explainability Adjudication Trace</span>
                </h3>
                <span className="text-xs font-mono-data text-[#6B7280]">DEFANGED URL: {activeResult.url}</span>
              </div>

              {/* Reasons List */}
              <div className="space-y-2 mb-6">
                {activeResult.reasons.map((reason, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-[#F9FAFB] bg-[#111827]/70 p-3 rounded-lg border border-white/5">
                    <span className="text-[#3B82F6] font-mono-data font-bold">0{idx + 1}.</span>
                    <span>{reason}</span>
                  </div>
                ))}
              </div>

              {/* Multimodal Signals Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                <div className="p-3 bg-[#111827] rounded-lg text-xs font-mono-data">
                  <div className="text-[#6B7280] mb-1">CERTIFICATE / CT MONITOR</div>
                  <div className="text-[#F9FAFB] truncate">{activeResult.lexicalSignals.certIssuer}</div>
                  <div className="text-[#06B6D4] text-[11px] mt-1">{activeResult.lexicalSignals.ctLogStatus}</div>
                </div>
                <div className="p-3 bg-[#111827] rounded-lg text-xs font-mono-data">
                  <div className="text-[#6B7280] mb-1">VISUAL BRAND MATCH</div>
                  <div className="text-[#F9FAFB]">
                    {activeResult.visualSignals.brandImpersonated || 'No Brand Impersonation Detected'}
                  </div>
                  <div className="text-[#8B5CF6] text-[11px] mt-1">
                    Similarity: {activeResult.visualSignals.visualSimilarity}%
                  </div>
                </div>
              </div>

              {/* Cryptographic SHA-256 Evidence Hash */}
              <div className="bg-[#060911] p-3 rounded-lg border border-white/10 font-mono-data text-xs flex items-center justify-between gap-3">
                <div className="truncate">
                  <span className="text-[#6B7280] block text-[10px]">EVIDENCE HASH (CERT-IN & LEGAL AUDIT GRADE)</span>
                  <span className="text-[#9CA3AF] select-all">{activeResult.sha256Evidence}</span>
                </div>
                <button
                  onClick={handleCopyEvidence}
                  className="p-2 hover:bg-[#111827] rounded text-[#9CA3AF] hover:text-white transition-colors shrink-0"
                  title="Copy full JSON evidence package"
                >
                  {copiedEvidence ? (
                    <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Bottom Actions & Usage Cap */}
            <div className="mt-6 pt-4 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs font-mono-data text-[#6B7280]">
                Analyst Check {scansCount} of 3 used · Unlock 1,000 free scans via API
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={onOpenApiKeyModal}
                  className="px-4 py-2 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Get 1,000 Free Scans</span>
                </button>
                <button
                  onClick={onOpenBriefingModal}
                  className="px-4 py-2 bg-transparent hover:bg-white/5 text-[#9CA3AF] hover:text-white text-xs font-medium rounded-lg border border-white/10 transition-colors"
                >
                  Book SOC Briefing
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
