import React from 'react';
import { 
  Award, 
  Shield, 
  Building2, 
  ArrowRight, 
  Landmark, 
  Anchor, 
  Coins, 
  Network, 
  Search,
  ExternalLink,
  Linkedin
} from 'lucide-react';
import { SECTORS_LIST, FOUNDERS, COMPANY_DETAILS } from '../data/content';
import { SolutionSector } from '../types';

interface CompanySectionsProps {
  onSelectSolution: (sector: SolutionSector) => void;
  onOpenBriefingModal: (defaultInterest?: string) => void;
  onOpenApiKeyModal: () => void;
  onViewCompany: () => void;
  onViewLeadership: () => void;
}

export const CompanySections: React.FC<CompanySectionsProps> = ({
  onSelectSolution,
  onOpenBriefingModal,
  onOpenApiKeyModal,
  onViewCompany,
  onViewLeadership,
}) => {
  return (
    <>
      {/* 6.12 Credentials Strip (Bitdefender's Industry Recognition equivalent) */}
      <section className="py-12 border-y border-white/[0.06] bg-[#060911]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-xs font-mono-data text-[#6B7280] uppercase tracking-widest mb-6">
            RECOGNISED AND SUPPORTED BY
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 rounded-xl bg-[#0B0F19] border border-white/5 flex items-center justify-center gap-3">
              <Award className="w-5 h-5 text-[#3B82F6]" />
              <div className="text-left">
                <div className="text-sm font-semibold text-white">DPIIT Startup India</div>
                <div className="text-[11px] font-mono-data text-[#6B7280]">Recognition No. {COMPANY_DETAILS.dpiit}</div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#0B0F19] border border-white/5 flex items-center justify-center gap-3">
              <Shield className="w-5 h-5 text-[#06B6D4]" />
              <div className="text-left">
                <div className="text-sm font-semibold text-white">Indian Patent Office</div>
                <div className="text-[11px] font-mono-data text-[#6B7280]">Patent Pending: {COMPANY_DETAILS.patentPending}</div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#0B0F19] border border-white/5 flex items-center justify-center gap-3">
              <Building2 className="w-5 h-5 text-[#10B981]" />
              <div className="text-left">
                <div className="text-sm font-semibold text-white">T-Hub Ecosystem</div>
                <div className="text-[11px] font-mono-data text-[#6B7280]">Resident & Registered, T-Hub Phase 2, Hyderabad</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6.13 Built For (Sectors) and National Impact */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/10 border border-[#3B82F6]/20 text-[#3B82F6] text-xs font-mono-data mb-4">
            <Shield className="w-3.5 h-3.5" />
            <span>SECTOR PLAYBOOKS // HIGH-CONSEQUENCE RESILIENCE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight mb-4">
            Built for the sectors that can’t afford a breach.
          </h2>
          <p className="text-base sm:text-lg text-[#9CA3AF]">
            From high-velocity UPI transaction gateways to air-gapped sovereign defense networks, our architecture enforces zero-trust continuous validation.
          </p>
        </div>

        {/* 6 Sector Tiles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {SECTORS_LIST.map((sector, idx) => (
            <div
              key={idx}
              className="glass-panel glass-panel-hover rounded-2xl p-6 border border-white/10 flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] font-mono-data text-[#06B6D4] uppercase block mb-2">
                  BUILT FOR
                </span>
                <h3 className="text-lg font-bold text-white mb-2">{sector.name}</h3>
                <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed mb-6">
                  {sector.desc}
                </p>
              </div>

              <button
                onClick={() => onSelectSolution(
                  idx === 0 ? 'banking' :
                  idx === 1 ? 'government' :
                  idx === 2 ? 'government' :
                  idx === 3 ? 'crypto-web3' :
                  idx === 4 ? 'enterprise-soc' : 'mssp'
                )}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#3B82F6] hover:text-[#60A5FA] transition-colors"
              >
                <span>Read sector architecture</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* National Impact Sovereign Band */}
        <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0B0F19] via-[#111827] to-[#0B0F19] border border-[#3B82F6]/30 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <span className="text-xs font-mono-data text-[#10B981] font-semibold uppercase tracking-wider block mb-1">
              NATIONAL CYBER RESILIENCE IMPACT
            </span>
            <h3 className="text-xl font-bold text-white mb-2">
              Sovereign, air-gapped-ready, built in India.
            </h3>
            <p className="text-xs sm:text-sm text-[#9CA3AF]">
              Architected to guarantee complete domestic data residency, zero foreign intelligence exposure, and sub-millisecond automated threat containment for Indian banking, ports, energy grids, airports, and defense communications.
            </p>
          </div>

          <button
            onClick={() => onOpenBriefingModal('Government & Critical Infrastructure')}
            className="px-6 py-3 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs sm:text-sm font-semibold rounded-xl shadow transition-all shrink-0"
          >
            Sovereign Defense Briefing
          </button>
        </div>
      </section>

      {/* 6.14 Mission, Vision and Story */}
      <section className="py-20 bg-[#0B0F19]/60 border-y border-white/[0.06]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-mono-data text-[#06B6D4] uppercase tracking-wider">
                OUR PURPOSE & CORE CONVICTION
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#F9FAFB] tracking-tight">
                Rebuild digital trust in the age of machine-speed deception.
              </h2>
              <p className="text-sm sm:text-base text-[#9CA3AF] leading-relaxed">
                When generative models produce flawless phishing clones and weaponized infrastructure in seconds, static security lists fail catastrophically. Our vision is to serve as the sovereign digital immune system for nations, enterprises and autonomous AI.
              </p>
              <div className="pt-2">
                <button
                  onClick={onViewCompany}
                  className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#3B82F6] hover:text-[#60A5FA] transition-colors"
                >
                  <span>Read the full Nexargio genesis story</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-6 glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#060911]">
              <div className="text-xs font-mono-data text-[#6B7280] uppercase mb-4">THE HYDERABAD GENESIS</div>
              <blockquote className="text-base sm:text-lg text-white font-medium italic mb-4 leading-relaxed">
                “Blocklists update in 12–24 hours while attacks live for 2–3. We realized the only way to stop zero-day phishing is to catch infrastructure at certificate issuance, before the first link is ever sent.”
              </blockquote>
              <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                <div className="w-9 h-9 rounded-full bg-[#111827] border border-white/10 flex items-center justify-center font-bold text-xs text-[#3B82F6]">
                  MN
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Manohar Nidamanuri</div>
                  <div className="text-[11px] text-[#6B7280]">CEO, Nexargio Private Limited</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 6.15 Take the Next Step (Bitdefender's Four Tiles + Founders Strip) */}
      <section id="take-next-step" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-mono-data text-[#3B82F6] uppercase tracking-wider">
            TAKE THE NEXT STEP
          </span>
          <h2 className="text-3xl font-extrabold text-white mt-1 mb-3">
            Choose your deployment engagement
          </h2>
          <p className="text-sm text-[#9CA3AF]">
            Whether you manage an enterprise SOC, build autonomous agents, or govern critical infrastructure.
          </p>
        </div>

        {/* 4 Persona Tiles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          
          <div className="glass-panel glass-panel-hover rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono-data text-[#06B6D4] uppercase mb-2">RUNNING A SOC OR MSSP?</div>
              <h3 className="text-lg font-bold text-white mb-2">Book an Executive Briefing</h3>
              <p className="text-xs text-[#9CA3AF] mb-6 leading-relaxed">
                Live demonstration of PIAD left-of-live interception against your active suspicious queue.
              </p>
            </div>
            <button
              onClick={() => onOpenBriefingModal('Enterprise & SOCs')}
              className="w-full py-2.5 px-4 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded-xl transition-colors text-center"
            >
              Book a Briefing
            </button>
          </div>

          <div className="glass-panel glass-panel-hover rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono-data text-[#10B981] uppercase mb-2">GOVERNMENT OR INFRASTRUCTURE?</div>
              <h3 className="text-lg font-bold text-white mb-2">Start an Air-Gapped Pilot</h3>
              <p className="text-xs text-[#9CA3AF] mb-6 leading-relaxed">
                Deploy in sovereign classified enclaves with on-premise LLM weights and strict data residency.
              </p>
            </div>
            <button
              onClick={() => onOpenBriefingModal('Government & Critical Infrastructure')}
              className="w-full py-2.5 px-4 bg-[#111827] hover:bg-[#1F2937] text-white border border-white/10 text-xs font-semibold rounded-xl transition-colors text-center"
            >
              Start a Pilot
            </button>
          </div>

          <div className="glass-panel glass-panel-hover rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono-data text-[#8B5CF6] uppercase mb-2">BUILDING WITH AI AGENTS?</div>
              <h3 className="text-lg font-bold text-white mb-2">Get API & MCP Access</h3>
              <p className="text-xs text-[#9CA3AF] mb-6 leading-relaxed">
                Connect Claude Desktop, Cursor, or your backend pipeline with 1,000 free scans immediately.
              </p>
            </div>
            <button
              onClick={onOpenApiKeyModal}
              className="w-full py-2.5 px-4 bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold rounded-xl transition-colors text-center"
            >
              Get Free API Key
            </button>
          </div>

          <div className="glass-panel glass-panel-hover rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono-data text-[#F59E0B] uppercase mb-2">WANT TO RESELL OR INTEGRATE?</div>
              <h3 className="text-lg font-bold text-white mb-2">Partner With Us</h3>
              <p className="text-xs text-[#9CA3AF] mb-6 leading-relaxed">
                Join our MSSP & OEM licensing programmes with dedicated technical support and deal registration.
              </p>
            </div>
            <button
              onClick={() => onOpenBriefingModal('MSSP & MDR Providers')}
              className="w-full py-2.5 px-4 bg-[#111827] hover:bg-[#1F2937] text-white border border-white/10 text-xs font-semibold rounded-xl transition-colors text-center"
            >
              Partner With Us
            </button>
          </div>

        </div>

        {/* Founders Strip (Rule 5: Manohar Nidamanuri & Venkatesh Nutalapati with LinkedIn links) */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 bg-[#0B0F19]">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <span className="text-xs font-mono-data text-[#6B7280] uppercase tracking-wider">
                EXECUTIVE LEADERSHIP
              </span>
              <h3 className="text-xl font-bold text-white">Founded by Cybersecurity & Systems Architects</h3>
            </div>
            <button
              onClick={onViewLeadership}
              className="text-xs font-semibold text-[#3B82F6] hover:underline flex items-center gap-1 self-start sm:self-auto"
            >
              <span>View Leadership Profiles</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {FOUNDERS.map((founder, idx) => (
              <div key={idx} className="p-4 bg-[#111827] rounded-xl border border-white/5 flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#060911] border border-white/10 flex items-center justify-center font-bold text-sm text-[#3B82F6] shrink-0">
                  {founder.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-white">{founder.name}</h4>
                    <a
                      href={founder.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#6B7280] hover:text-[#3B82F6] transition-colors"
                      title="LinkedIn profile"
                    >
                      <Linkedin className="w-4 h-4" />
                    </a>
                  </div>
                  <div className="text-xs font-mono-data text-[#06B6D4] mb-1">{founder.role}</div>
                  <p className="text-xs text-[#9CA3AF] leading-relaxed">{founder.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};
