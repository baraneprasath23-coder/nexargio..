import React from 'react';
import { Linkedin, Shield, MapPin, Mail, ArrowUpRight } from 'lucide-react';
import { COMPANY_DETAILS } from '../data/content';
import { PageView } from '../types';

interface FooterProps {
  onNavigate: (view: PageView, sectionId?: string) => void;
  onOpenReportPhishing: () => void;
  onOpenCookiesModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenReportPhishing,
  onOpenCookiesModal,
}) => {
  return (
    <footer className="bg-[#04060B] border-t border-white/[0.08] pt-16 pb-12 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 4-Column Navigation & Company Block */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-12 gap-8 mb-12">
          
          {/* Company Brand & Legal Entity Block (4 cols on lg) */}
          <div className="col-span-2 md:col-span-4 lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#3B82F6] to-[#06B6D4] p-0.5 flex items-center justify-center">
                <div className="w-full h-full bg-[#060911] rounded-[5px] flex items-center justify-center">
                  <div className="w-3 h-3 bg-gradient-to-tr from-[#3B82F6] to-[#06B6D4] rotate-45" />
                </div>
              </div>
              <span className="font-outfit font-extrabold text-lg text-white tracking-tight">
                NEXARGIO
              </span>
            </div>

            <p className="text-xs text-[#9CA3AF] italic">
              “{COMPANY_DETAILS.tagline}”
            </p>

            <div className="space-y-1.5 text-[11px] text-[#6B7280] font-mono-data">
              <div className="text-[#9CA3AF] font-bold">Nexargio Private Limited</div>
              <div>CIN: {COMPANY_DETAILS.cin} · DPIIT: {COMPANY_DETAILS.dpiit}</div>
              <div>Office: {COMPANY_DETAILS.office}</div>
              <div className="pt-1 text-[#9CA3AF] font-bold">Nexargio UK Ltd</div>
              <div>Company No. {COMPANY_DETAILS.ukEntity.companyNumber} ({COMPANY_DETAILS.ukEntity.jurisdiction})</div>
              <div className="pt-1 flex items-center gap-1.5 text-[#3B82F6]">
                <Mail className="w-3 h-3" />
                <a href={`mailto:${COMPANY_DETAILS.email}`} className="hover:underline">
                  {COMPANY_DETAILS.email}
                </a>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <a
                href="https://linkedin.com/company/nexargio"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-[#111827] border border-white/10 flex items-center justify-center text-[#9CA3AF] hover:text-white hover:border-[#3B82F6] transition-colors"
                title="Nexargio LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <div className="px-2.5 py-1 rounded-md bg-[#111827] border border-white/5 text-[10px] font-mono-data text-[#10B981]">
                ● GLOBAL EDGE ONLINE
              </div>
            </div>
          </div>

          {/* Column: Platform */}
          <div className="col-span-1 md:col-span-2 lg:col-span-2 space-y-3">
            <div className="text-xs font-mono-data text-white font-semibold uppercase tracking-wider">
              PLATFORM
            </div>
            <ul className="space-y-2 text-[#9CA3AF]">
              <li>
                <button onClick={() => onNavigate('platform')} className="hover:text-white transition-colors">
                  Overview
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('platform', 'piad-engine')} className="hover:text-white transition-colors flex items-center gap-1.5">
                  <span>PIAD v4.0</span>
                  <span className="text-[9px] px-1 bg-[#10B981]/20 text-[#10B981] rounded">LIVE</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('home', 'developers-api')} className="hover:text-white transition-colors">
                  REST API
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('home', 'developers-api')} className="hover:text-white transition-colors">
                  MCP Server
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('platform', 'threat-feed')} className="hover:text-white transition-colors">
                  Threat Feed
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('platform', 'brand-dossiers')} className="hover:text-white transition-colors">
                  Brand Dossiers
                </button>
              </li>
            </ul>
          </div>

          {/* Column: Solutions */}
          <div className="col-span-1 md:col-span-2 lg:col-span-2 space-y-3">
            <div className="text-xs font-mono-data text-white font-semibold uppercase tracking-wider">
              SOLUTIONS
            </div>
            <ul className="space-y-2 text-[#9CA3AF]">
              <li>
                <button onClick={() => onNavigate('solutions', 'banking')} className="hover:text-white transition-colors">
                  Banking & FinTech
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('solutions', 'government')} className="hover:text-white transition-colors">
                  Government & Defense
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('solutions', 'crypto-web3')} className="hover:text-white transition-colors">
                  Crypto & Web3
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('solutions', 'enterprise-soc')} className="hover:text-white transition-colors">
                  Enterprise SOCs
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('solutions', 'mssp')} className="hover:text-white transition-colors">
                  MSSPs & MDRs
                </button>
              </li>
            </ul>
          </div>

          {/* Column: Research */}
          <div className="col-span-1 md:col-span-2 lg:col-span-2 space-y-3">
            <div className="text-xs font-mono-data text-white font-semibold uppercase tracking-wider">
              RESEARCH
            </div>
            <ul className="space-y-2 text-[#9CA3AF]">
              <li>
                <button onClick={() => onNavigate('research')} className="hover:text-white transition-colors">
                  Proven in the Wild
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('research', 'bulletins')} className="hover:text-white transition-colors">
                  Threat Bulletins
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('research', 'whitepapers')} className="hover:text-white transition-colors">
                  Whitepapers
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('research', 'benchmarks')} className="hover:text-white transition-colors">
                  Benchmark Report
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('research', 'patent')} className="hover:text-white transition-colors">
                  Patent & IP
                </button>
              </li>
            </ul>
          </div>

          {/* Column: Company & Reporting */}
          <div className="col-span-1 md:col-span-2 lg:col-span-2 space-y-3">
            <div className="text-xs font-mono-data text-white font-semibold uppercase tracking-wider">
              COMPANY
            </div>
            <ul className="space-y-2 text-[#9CA3AF]">
              <li>
                <button onClick={() => onNavigate('company')} className="hover:text-white transition-colors">
                  About Nexargio
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('leadership')} className="hover:text-white transition-colors">
                  Leadership
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('company', 'manifesto')} className="hover:text-white transition-colors">
                  Manifesto
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('company', 'careers')} className="hover:text-white transition-colors">
                  Careers (16+ Team)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('company', 'contact')} className="hover:text-white transition-colors">
                  Contact
                </button>
              </li>
              <li>
                <button 
                  onClick={onOpenReportPhishing} 
                  className="text-[#EF4444] hover:underline font-semibold flex items-center gap-1"
                >
                  <span>Report Phishing Site</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* Legal Row (Section 7 & 15.2) */}
        <div className="pt-8 border-t border-white/[0.08] flex flex-col md:flex-row items-center justify-between gap-4 text-[#6B7280] text-[11px] font-mono-data">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-x-4 gap-y-2">
            <button onClick={() => onNavigate('privacy')} className="hover:text-white transition-colors">
              Privacy Policy
            </button>
            <span>·</span>
            <button onClick={onOpenCookiesModal} className="hover:text-white transition-colors">
              Cookie Policy
            </button>
            <span>·</span>
            <button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors">
              Website Terms
            </button>
            <span>·</span>
            <button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors">
              API Terms
            </button>
            <span>·</span>
            <button onClick={() => onNavigate('dpa')} className="hover:text-white transition-colors">
              Data Processing Addendum (DPA)
            </button>
            <span>·</span>
            <button onClick={() => onNavigate('responsible-disclosure')} className="hover:text-white transition-colors">
              Responsible Disclosure
            </button>
            <span>·</span>
            <button onClick={() => onNavigate('trademarks')} className="hover:text-white transition-colors">
              Trademarks
            </button>
            <span>·</span>
            <button onClick={() => onNavigate('privacy', 'grievance')} className="hover:text-white transition-colors text-[#9CA3AF]">
              Grievance Officer: {COMPANY_DETAILS.grievanceOfficer.email}
            </button>
          </div>

          <div className="shrink-0 text-[#6B7280]">
            © 2026 {COMPANY_DETAILS.legalName}. All rights reserved.
          </div>
        </div>

      </div>
    </footer>
  );
};
