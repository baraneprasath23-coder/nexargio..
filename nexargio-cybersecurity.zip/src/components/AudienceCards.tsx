import React from 'react';
import { ArrowRight, ShieldCheck, Network, Landmark, Coins } from 'lucide-react';
import { SolutionSector } from '../types';

interface AudienceCardsProps {
  onSelectSolution: (sector: SolutionSector) => void;
}

export const AudienceCards: React.FC<AudienceCardsProps> = ({ onSelectSolution }) => {
  const cards = [
    {
      id: 'mssp' as SolutionSector,
      icon: Network,
      title: 'For MSSPs & MDR Providers',
      copy: 'Add evasive-URL investigation to your SOC and resell explainable phishing verdicts to every client.',
      accent: 'from-[#3B82F6]/20 to-transparent'
    },
    {
      id: 'enterprise-soc' as SolutionSector,
      icon: ShieldCheck,
      title: 'For Enterprise & SOCs',
      copy: 'Stop zero-day phishing and AiTM session theft with explainable verdicts your analysts can trust.',
      accent: 'from-[#06B6D4]/20 to-transparent'
    },
    {
      id: 'government' as SolutionSector,
      icon: Landmark,
      title: 'For Government & Critical Infrastructure',
      copy: 'Sovereign, air-gapped-ready threat intelligence built in India for national-scale resilience.',
      accent: 'from-[#10B981]/20 to-transparent'
    },
    {
      id: 'crypto-web3' as SolutionSector,
      icon: Coins,
      title: 'For Crypto & Web3 Brands',
      copy: 'Find wallet drainers and fake exchange sites impersonating your brand, with evidence ready for takedown.',
      accent: 'from-[#8B5CF6]/20 to-transparent'
    }
  ];

  return (
    <section className="relative -mt-6 sm:-mt-10 mb-16 z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.id}
              onClick={() => onSelectSolution(card.id)}
              className="glass-panel glass-panel-hover rounded-2xl p-6 cursor-pointer flex flex-col justify-between group relative overflow-hidden"
            >
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl ${card.accent} rounded-full blur-2xl pointer-events-none group-hover:scale-125 transition-transform duration-500`} />

              <div>
                <div className="w-10 h-10 rounded-xl bg-[#111827] border border-white/10 flex items-center justify-center text-[#3B82F6] group-hover:text-[#60A5FA] group-hover:border-[#3B82F6]/40 transition-colors mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-[#F9FAFB] mb-2 leading-snug group-hover:text-[#3B82F6] transition-colors">
                  {card.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed mb-6">
                  {card.copy}
                </p>
              </div>

              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#06B6D4] group-hover:text-white transition-colors">
                <span>View sector playbook</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
