import { CaseStudy } from '../types';

export const COMPANY_DETAILS = {
  legalName: 'Nexargio Private Limited',
  cin: 'U62099TS2026PTC215481',
  dpiit: 'DIPP262372',
  patentPending: 'TEMP/E-1/47712/2026-CHE',
  patentAppNumber: '202641043441',
  tagline: 'Trust, continuously validated.',
  email: 'info@nexargio.com',
  office: 'T-Hub, Hyderabad, India',
  ukEntity: {
    name: 'Nexargio UK Ltd',
    companyNumber: '17277722',
    jurisdiction: 'England & Wales'
  },
  grievanceOfficer: {
    name: 'Grievance Officer (Legal & Compliance)',
    email: 'info@nexargio.com',
    address: 'Nexargio Private Limited, T-Hub Phase 2, Madhapur, Hyderabad, Telangana 500081, India',
    responseWindow: 'Within 30 calendar days'
  }
};

export const BENCHMARK_STATS = [
  {
    value: '98.11%',
    label: 'Zero-day phishing recall',
    dataset: '10,000 live phishing URLs (PhishTank, OpenPhish dataset)'
  },
  {
    value: '0.00%',
    label: 'False positive rate',
    dataset: 'Top 500 global commercial and retail banking URLs'
  },
  {
    value: '99.67%',
    label: 'Overall detection precision',
    dataset: 'Technical Benchmark Report v1.0.0 (Pre-issuance test harness)'
  },
  {
    value: '~90%',
    label: 'Compute cost reduction',
    dataset: 'Gated fast/slow path risk ladder architectural cost model'
  }
];

export const TESTED_RESULTS_COMPARISON = [
  {
    testCase: 'New, legitimate Hyderabad small-business site',
    publicScanners: 'Four scanners flagged it as suspicious or risky solely because domain was under 7 days old',
    nexargio: 'Grade A+, risk 0, allowed (no false alarm; structural brand, MX, and business entity verified)'
  },
  {
    testCase: 'Phishing lure hidden behind a Google share link',
    publicScanners: 'One scanner refused to scan; four rated it safe due to Google parent domain reputation',
    nexargio: 'Contained in an isolated browser sandbox as an uncertain multi-stage credential lure'
  },
  {
    testCase: 'Phishing kit behind a Cloudflare Turnstile CAPTCHA gate',
    publicScanners: '86 of 90 commercial scanning engines missed it (blocked by anti-crawler challenge)',
    nexargio: 'Flagged critical, hard block (headless browser emulation solved and extracted DOM payload)'
  },
  {
    testCase: 'Phishing domain already taken offline',
    publicScanners: 'One scanner crashed; multi-engine aggregator continued to show stale critical alerts for 48h',
    nexargio: 'Confirmed takedown, DNS NXDOMAIN corroborated, zero false alerts generated'
  }
];

export const AUDIENCE_CARDS = [
  {
    id: 'mssp',
    title: 'For MSSPs & MDR Providers',
    copy: 'Add evasive-URL investigation to your SOC and resell explainable phishing verdicts to every client.',
    cta: 'Explore MSSP Solutions'
  },
  {
    id: 'enterprise-soc',
    title: 'For Enterprise & SOCs',
    copy: 'Stop zero-day phishing and AiTM session theft with explainable verdicts your analysts can trust.',
    cta: 'Explore Enterprise SOC'
  },
  {
    id: 'government',
    title: 'For Government & Critical Infrastructure',
    copy: 'Sovereign, air-gapped-ready threat intelligence built in India for national-scale resilience.',
    cta: 'Explore Sovereign Defense'
  },
  {
    id: 'crypto-web3',
    title: 'For Crypto & Web3 Brands',
    copy: 'Find wallet drainers and fake exchange sites impersonating your brand, with evidence ready for takedown.',
    cta: 'Explore Web3 Protection'
  }
];

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'openai-collab',
    title: 'Fake OpenAI Collaboration Workspace Impersonation',
    targetSector: 'AI & Developer Platforms',
    defangedUrl: 'chatgpt-enterprise-login[.]net',
    riskScore: 85,
    timeToFlag: '0.84 seconds',
    publicScannersStatus: '0 of 90 commercial engines flagged at time of detection',
    summary: 'A sophisticated AiTM proxy kit replicating OpenAI enterprise SSO was intercepted immediately at Certificate Transparency (CT) log submission. Nexargio flagged the domain in under 1 second, compiled the cryptographic SHA-256 evidence package, and notified the affected vendor security team.',
    evidenceNotes: 'Visual hash match against OpenAI brand styling detected via Gemini vision adjudication; backend session relay to known adversary infrastructure identified.',
    status: 'Reported & Confirmed Takedown',
    indicators: {
      registrar: 'NameCheap / Cloudflare Proxy',
      ip: '194.169.175[.]42 (AS204957)',
      certDate: '2026-09-18 03:14 UTC',
      attackVector: 'Adversary-in-the-Middle (AiTM) OAuth Token Exfiltration'
    }
  },
  {
    id: 'paytm-gaming',
    title: 'Paytm UPI + BGMI Mobile Gaming Fraud Campaign',
    targetSector: 'FinTech & Consumer Payments',
    defangedUrl: 'ucpaytm[.]store',
    riskScore: 92,
    timeToFlag: '0.62 seconds',
    publicScannersStatus: '0 of 90 commercial scanning engines flagged upon issuance',
    summary: 'Targeted campaign harvesting UPI credentials and mobile banking sessions under the guise of free in-game UC currency top-ups. Intercepted left-of-live prior to campaign deployment across messaging networks.',
    evidenceNotes: 'Obfuscated JavaScript QR code generator mimicking official Paytm merchant payment gateway with hardcoded adversary UPI VPA destination.',
    status: 'Reported & Confirmed Takedown',
    indicators: {
      registrar: 'Hostinger India',
      ip: '185.193.127[.]88',
      certDate: '2026-10-02 11:28 UTC',
      attackVector: 'Dynamic UPI Collect Intent Spoofing'
    }
  },
  {
    id: 'indian-banking',
    title: 'Multi-Bank Impersonation Cluster (SBI, HDFC, ICICI)',
    targetSector: 'Commercial Banking & Wealth',
    defangedUrl: 'hdfc-kyc-update-portal[.]org',
    riskScore: 95,
    timeToFlag: '0.45 seconds',
    publicScannersStatus: 'All static blocklists rated domain as benign/unseen for 18 hours',
    summary: 'A coordinated typosquatting campaign targeting net banking customers with urgent PAN/KYC expiration alerts. Intercepted at certificate generation through automated CT log ingestion before phishing SMS blasts commenced.',
    evidenceNotes: 'Lexical analysis caught high-entropy subdomain structure; OCR extraction identified official Indian bank disclaimers duplicated verbatim.',
    status: 'Reported & Confirmed Takedown',
    indicators: {
      registrar: 'Porkbun LLC',
      ip: '104.21.34[.]112',
      certDate: '2026-10-11 08:04 UTC',
      attackVector: 'PAN-Aadhaar Net Banking Credential Trap'
    }
  }
];

export const FOUNDERS = [
  {
    name: 'Manohar Nidamanuri',
    role: 'Chief Executive Officer',
    bio: 'Pioneering sovereign cybersecurity resilience and enterprise identity trust architectures. Leading Nexargio strategy from T-Hub, Hyderabad.',
    linkedin: 'https://linkedin.com/company/nexargio'
  },
  {
    name: 'Venkatesh Nutalapati',
    role: 'Chief Technology Officer & Lead Architect',
    bio: 'Architect of PIAD recursive normalization and low-latency adversarial threat analysis engine. Specializes in eBPF runtime telemetry and sovereign defense.',
    linkedin: 'https://linkedin.com/company/nexargio'
  }
];

export const SECTORS_LIST = [
  {
    name: 'Banking & FinTech',
    desc: 'Neutralize fake netbanking, UPI collect fraud, and payment gateway impersonation before customer SMS campaigns launch.'
  },
  {
    name: 'Government & Defence',
    desc: 'Sovereign, air-gapped threat detection engineered for national critical data infrastructure, citizen portals, and defense agencies.'
  },
  {
    name: 'Ports, Energy & Airports',
    desc: 'Protect operational technology access gateways and logistics command portals from spear-phishing credential theft.'
  },
  {
    name: 'Crypto & Web3',
    desc: 'Instantly uncover automated wallet drainers, fake exchange sites, and malicious dApp clones targeting liquidity and token holders.'
  },
  {
    name: 'Enterprise SOCs & MSSPs',
    desc: 'Augment Tier-1 security analysts with millisecond explainability traces, defanged forensics, and zero false-positive precision.'
  },
  {
    name: 'Fraud & AML Teams',
    desc: 'Correlate domain infrastructure syndicates, bulletproof hosting clusters, and merchant account impersonation rings.'
  }
];
